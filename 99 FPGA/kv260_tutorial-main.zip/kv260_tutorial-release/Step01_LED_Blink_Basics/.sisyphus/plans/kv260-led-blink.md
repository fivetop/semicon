# KV260 LED Blink Project

## TL;DR

> **Quick Summary**: Create a Vivado 2021.2 project for the KV260 that blinks an external LED connected to PMOD1 once per second.
>
> **Deliverables**:
> - `README.md` - hardware setup, prerequisites, and build instructions
> - `src/led_blink.v` - LED blink RTL module
> - `sim/tb_led_blink.v` - self-checking testbench
> - `constraints/kv260_pmod.xdc` - PMOD1 pin constraints
> - `scripts/create_project.tcl` - batch Vivado project creation script
> - `build.sh` - build wrapper script
>
> **Estimated Effort**: Medium
> **Execution Model**: Strictly sequential; no parallel work
> **Critical Path**: README -> testbench -> RTL -> XDC -> Tcl -> build wrapper -> batch build -> simulation rerun

---

## Context

### Original Request
- Create a Vivado 2021.2 project for the KV260
- Use Verilog
- Blink an LED once per second
- Generate the project under the local `out/` directory

### Confirmed Facts
- The KV260 does not provide a user-controlled on-board LED for this exercise; use an external LED on PMOD1
- PMOD1 Pin 1 maps to FPGA pin `H12`
- The output I/O standard must be `LVCMOS33`
- PL logic on KV260 must be clocked from the PS; use `pl_clk0` at 100 MHz
- The Vivado environment file is `/tools/Xilinx/Vivado/2021.2/settings64.sh`

### TDD Intent
Write the self-checking testbench first, then implement RTL until the simulation passes. Only after the logic is green should the plan move on to project automation, constraints, and hardware build verification.

---

## Work Objectives

### Core Objective
Produce a reproducible Vivado project that drives an LED connected to KV260 PMOD1 and toggles it every 0.5 seconds, resulting in a 1 Hz blink rate.

### Concrete Deliverables
- `README.md`
- `src/led_blink.v`
- `sim/tb_led_blink.v`
- `constraints/kv260_pmod.xdc`
- `scripts/create_project.tcl`
- `build.sh`

### Definition of Done
- [ ] `./build.sh` completes successfully from the repository root
- [ ] Vivado synthesis completes without errors
- [ ] Vivado implementation completes without errors and with non-negative WNS
- [ ] A `.bit` file is generated under `out/`
- [ ] The simulation flow compiles both RTL and testbench from a clean checkout and prints `PASS`

### Must Have
- Zynq PS present in a Block Design to provide `pl_clk0`
- A 27-bit counter for the 100 MHz to 1 Hz blink behavior
- LED output mapped to PMOD1 Pin 1 (`H12`)
- Batch-mode project creation through `scripts/create_project.tcl`
- A self-checking testbench with explicit `PASS`/`FAIL` output

### Must Not Have
- Vitis or SDK software project generation
- AXI GPIO or other unnecessary bus infrastructure
- Extra PS peripheral configuration unrelated to clocking
- ILA or VIO debug cores
- A parameterized blink frequency; keep the target fixed at 1 second

---

## Ultrawork Execution Rules

- Work on exactly one task at a time.
- Finish the QA scenario for the current task before starting the next one.
- Create the task's atomic commit immediately after its QA scenario passes.
- Do not commit generated artifacts such as `out/`, `xsim.dir/`, `*.log`, `*.jou`, or `*.pb`.
- Tasks 7 and 8 are verification-only tasks and must not create commits.

---

## Verification Conventions

- Run all commands from the repository root: `Step01_LED_Blink_Basics/`
- Assume `bash` as the shell for every QA command
- Before any `vivado`, `xvlog`, `xelab`, or `xsim` command, run:

```bash
source /tools/Xilinx/Vivado/2021.2/settings64.sh
```

- A QA scenario is only complete when its command exits with status `0` and the expected file, stdout text, or artifact is present

---

## Execution Strategy

### Strict Sequence
```text
Task 1: Create/update README.md
  -> Task 2: Create self-checking testbench first (TDD red/specification)
  -> Task 3: Implement RTL until simulation passes (TDD green)
  -> Task 4: Add XDC constraints
  -> Task 5: Add batch Tcl project script with PS/block-design clocking
  -> Task 6: Add build wrapper script
  -> Task 7: Run hardware build verification
  -> Task 8: Re-run simulation from clean checkout
```

### Why This Order Works
- Task 2 defines the expected behavior before RTL exists
- Task 3 closes the TDD loop by making the testbench pass
- Tasks 4-6 package the validated logic into a reproducible hardware build flow
- Tasks 7-8 are final verification passes and should not change source files

---

## TODOs

- [ ] 1. Create or refresh `README.md` with hardware setup and prerequisites

  **What to do**:
  - Document the project goal and board context
  - Describe the external LED wiring for PMOD1 Pin 1 (`H12`) and GND
  - Call out the need for a current-limiting resistor (330 ohm)
  - Document the Vivado 2021.2 prerequisite and the build command

  **Must NOT do**:
  - Do not add software-development steps or Vitis workflow notes

  **Recommended Agent Profile**:
  - **Category**: `writing`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: None
  - **Blocks**: Task 2

  **Acceptance Criteria**:
  - [ ] `README.md` exists
  - [ ] PMOD1 wiring and resistor guidance are documented
  - [ ] Vivado 2021.2 prerequisite is documented
  - [ ] A repository-root build command is documented

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f README.md && \
    grep -q "PMOD1" README.md && \
    grep -q "H12" README.md && \
    grep -q "330" README.md && \
    grep -q "Vivado 2021.2" README.md && \
    grep -qi "build" README.md
    ```
  - **Expected Result**: Exit code `0`. `README.md` explicitly mentions PMOD1/H12 wiring, the 330 ohm resistor, Vivado 2021.2, and a build instruction.

  **Commit**: YES
  - **Message**: `docs: add README with hardware setup`
  - **Files**: `README.md`

---

- [ ] 2. Create the Verilog testbench first (TDD specification)

  **What to do**:
  - Create a self-checking testbench in `sim/tb_led_blink.v`
  - Model a 100 MHz clock
  - Encode the expected first LED toggle at 50,000,000 cycles
  - Encode the expected second toggle / return-to-original-state at 100,000,000 cycles
  - Print explicit `PASS` or `FAIL` to stdout and end the simulation automatically

  **Must NOT do**:
  - Do not require manual waveform inspection

  **Recommended Agent Profile**:
  - **Category**: `ultrabrain`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 1
  - **Blocks**: Task 3

  **Acceptance Criteria**:
  - [ ] `sim/tb_led_blink.v` exists
  - [ ] The testbench encodes both 50,000,000-cycle and 100,000,000-cycle expectations
  - [ ] The testbench prints explicit `PASS` or `FAIL`

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f sim/tb_led_blink.v && \
    grep -q "module tb_led_blink" sim/tb_led_blink.v && \
    grep -Eq "50_?000_?000" sim/tb_led_blink.v && \
    grep -Eq "100_?000_?000" sim/tb_led_blink.v && \
    grep -q "PASS" sim/tb_led_blink.v && \
    grep -q "FAIL" sim/tb_led_blink.v
    ```
  - **Expected Result**: Exit code `0`. The testbench exists and contains explicit checks for both half-period and full-period timing plus `PASS`/`FAIL` output.

  **Commit**: YES
  - **Message**: `test: add LED blink testbench`
  - **Files**: `sim/tb_led_blink.v`

---

- [ ] 3. Create the LED blink RTL module and make the testbench pass

  **What to do**:
  - Implement `src/led_blink.v`
  - Use a 27-bit counter suitable for 100 MHz timing
  - Toggle the LED every 50,000,000 clock cycles
  - Keep the module interface minimal: one clock input and one LED output
  - Iterate until the Task 2 testbench passes

  **Must NOT do**:
  - Do not add a frequency parameter or extra interfaces

  **Recommended Agent Profile**:
  - **Category**: `ultrabrain`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 2
  - **Blocks**: Tasks 4 and 5

  **Acceptance Criteria**:
  - [ ] `src/led_blink.v` exists
  - [ ] The counter width is 27 bits
  - [ ] The LED toggles every 50,000,000 cycles
  - [ ] The simulation passes using the Task 2 testbench

  **QA Scenario**:
  - **Tool**: `bash` + Vivado simulator CLI
  - **Command**:
    ```bash
    set -euo pipefail
    source /tools/Xilinx/Vivado/2021.2/settings64.sh
    mkdir -p out
    xvlog -sv src/led_blink.v sim/tb_led_blink.v
    xelab -debug typical tb_led_blink -s tb_led_blink
    xsim tb_led_blink -run all | tee out/task3_tb.log
    grep -q "^PASS$" out/task3_tb.log
    ! grep -q "^FAIL$" out/task3_tb.log
    ```
  - **Expected Result**: Every command exits with code `0`. `out/task3_tb.log` contains a standalone `PASS` line and does not contain a standalone `FAIL` line.

  **Commit**: YES
  - **Message**: `feat: add LED blink RTL module`
  - **Files**: `src/led_blink.v`

---

- [ ] 4. Create XDC constraints for PMOD1

  **What to do**:
  - Create `constraints/kv260_pmod.xdc`
  - Constrain the LED output to PMOD1 Pin 1 (`H12`)
  - Set `IOSTANDARD` to `LVCMOS33`
  - Set `SLEW` to `SLOW`
  - Set `DRIVE` to `4`

  **Must NOT do**:
  - Do not assign the LED to any other user pin

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 3
  - **Blocks**: Task 5

  **Acceptance Criteria**:
  - [ ] `constraints/kv260_pmod.xdc` exists
  - [ ] `H12` is assigned to the LED output
  - [ ] `LVCMOS33`, `SLEW SLOW`, and `DRIVE 4` are present

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f constraints/kv260_pmod.xdc && \
    grep -q "PACKAGE_PIN H12" constraints/kv260_pmod.xdc && \
    grep -q "IOSTANDARD LVCMOS33" constraints/kv260_pmod.xdc && \
    grep -q "SLEW SLOW" constraints/kv260_pmod.xdc && \
    grep -q "DRIVE 4" constraints/kv260_pmod.xdc
    ```
  - **Expected Result**: Exit code `0`. The XDC file exists and contains the exact PMOD1/H12 electrical constraints needed for the LED output.

  **Commit**: YES
  - **Message**: `feat: add XDC constraints`
  - **Files**: `constraints/kv260_pmod.xdc`

---

- [ ] 5. Create the batch Tcl project script with PS clocking

  **What to do**:
  - Create `scripts/create_project.tcl`
  - Create the Vivado project for the KV260 target part/board
  - Create a Block Design
  - Instantiate the Zynq PS IP
  - Enable and export `pl_clk0` at 100 MHz for the RTL module
  - Add `src/led_blink.v` and `constraints/kv260_pmod.xdc`
  - Launch synthesis, implementation, and bitstream generation in batch mode

  **Must NOT do**:
  - Do not export Vitis platforms
  - Do not add AXI GPIO or unrelated IP

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 4
  - **Blocks**: Task 6

  **Acceptance Criteria**:
  - [ ] `scripts/create_project.tcl` exists
  - [ ] The script creates a Block Design and Zynq PS instance
  - [ ] The script enables `pl_clk0`
  - [ ] The script adds RTL and XDC files and runs through bitstream generation

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f scripts/create_project.tcl && \
    grep -q "create_project" scripts/create_project.tcl && \
    grep -q "create_bd_design" scripts/create_project.tcl && \
    grep -q "zynq_ultra_ps_e" scripts/create_project.tcl && \
    grep -q "pl_clk0" scripts/create_project.tcl && \
    grep -q "add_files -fileset sources_1" scripts/create_project.tcl && \
    grep -q "add_files -fileset constrs_1" scripts/create_project.tcl && \
    grep -q "launch_runs synth_1" scripts/create_project.tcl && \
    grep -q "write_bitstream" scripts/create_project.tcl
    ```
  - **Expected Result**: Exit code `0`. The Tcl script contains the required Block Design, Zynq PS, `pl_clk0`, source inclusion, and batch build steps.

  **Commit**: YES
  - **Message**: `feat: add Tcl project script`
  - **Files**: `scripts/create_project.tcl`

---

- [ ] 6. Create the build wrapper script

  **What to do**:
  - Create `build.sh`
  - Source `/tools/Xilinx/Vivado/2021.2/settings64.sh`
  - Invoke `scripts/create_project.tcl` in batch mode
  - Ensure the output directory is created under the local project root
  - Print a clear success/failure summary

  **Must NOT do**:
  - Do not launch the Vivado GUI

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 5
  - **Blocks**: Task 7

  **Acceptance Criteria**:
  - [ ] `build.sh` exists
  - [ ] `build.sh` is executable
  - [ ] `build.sh` sources the Vivado environment and calls `scripts/create_project.tcl`

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f build.sh && \
    test -x build.sh && \
    bash -n build.sh && \
    grep -q "settings64.sh" build.sh && \
    grep -q "scripts/create_project.tcl" build.sh
    ```
  - **Expected Result**: Exit code `0`. `build.sh` exists, is executable, passes shell syntax check, and clearly invokes the Vivado environment plus the project Tcl script.

  **Commit**: YES
  - **Message**: `build: add batch build wrapper`
  - **Files**: `build.sh`

---

- [ ] 7. Run the batch build and verify bitstream generation

  **What to do**:
  - Execute `./build.sh` from the repository root
  - Confirm synthesis and implementation complete successfully
  - Confirm a `.bit` file is produced under `out/`
  - Capture any failure details before moving on

  **Must NOT do**:
  - Do not run the Vivado GUI
  - Do not commit generated artifacts from `out/`

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 6
  - **Blocks**: Task 8

  **Acceptance Criteria**:
  - [ ] `./build.sh` exits successfully
  - [ ] At least one `.bit` file exists under `out/`
  - [ ] The build can be reproduced from a clean repository root invocation

  **QA Scenario**:
  - **Tool**: `bash`
  - **Command**:
    ```bash
    set -euo pipefail
    ./build.sh
    BITFILE="$(find out -type f -name '*.bit' -print -quit)"
    test -n "$BITFILE"
    printf '%s\n' "$BITFILE"
    ```
  - **Expected Result**: Every command exits with code `0`. The final line prints a non-empty path to a `.bit` file under `out/`.

  **Commit**: NO
  - **Reason**: This task only verifies generated artifacts and should not create a source commit.

---

- [ ] 8. Re-run the simulation from a clean checkout flow

  **What to do**:
  - Re-run the full simulator flow after the build flow is in place
  - Compile both RTL and testbench from the repository root
  - Elaborate and run the simulation
  - Record the log and confirm `PASS`

  **Must NOT do**:
  - Do not rely on manual waveform inspection
  - Do not compile only the testbench; the clean-checkout flow must compile both `src/led_blink.v` and `sim/tb_led_blink.v`

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Blocked By**: Task 7
  - **Blocks**: None

  **Acceptance Criteria**:
  - [ ] The simulation compiles RTL and testbench from scratch
  - [ ] The simulation output contains `PASS`
  - [ ] The simulation output does not contain `FAIL`

  **QA Scenario**:
  - **Tool**: `bash` + Vivado simulator CLI
  - **Command**:
    ```bash
    set -euo pipefail
    source /tools/Xilinx/Vivado/2021.2/settings64.sh
    mkdir -p out
    xvlog -sv src/led_blink.v sim/tb_led_blink.v
    xelab -debug typical tb_led_blink -s tb_led_blink
    xsim tb_led_blink -run all | tee out/tb_led_blink.log
    grep -q "^PASS$" out/tb_led_blink.log
    ! grep -q "^FAIL$" out/tb_led_blink.log
    ```
  - **Expected Result**: Every command exits with code `0`. `out/tb_led_blink.log` contains a standalone `PASS` line and no standalone `FAIL` line.

  **Commit**: NO
  - **Reason**: This task is a final regression check and should not create a source commit.

---

## Final Verification Wave

- [ ] F1. **Plan Compliance Audit** — `oracle`
  - **Tool**: `bash`
  - **Command**:
    ```bash
    test -f README.md && \
    test -f src/led_blink.v && \
    test -f sim/tb_led_blink.v && \
    test -f constraints/kv260_pmod.xdc && \
    test -f scripts/create_project.tcl && \
    test -f build.sh && \
    grep -Eq "\[26:0\]|27-bit|27 bit" src/led_blink.v && \
    grep -q "50_000_000" src/led_blink.v && \
    grep -q "PACKAGE_PIN H12" constraints/kv260_pmod.xdc && \
    grep -q "pl_clk0" scripts/create_project.tcl && \
    grep -q "zynq_ultra_ps_e" scripts/create_project.tcl
    ```
  - **Expected Result**: Exit code `0`. All required source files exist and the must-have implementation markers are present.
  - **Output Format**: `Must Have PASS | Files PASS | VERDICT: APPROVE`

- [ ] F2. **Build Verification** — `unspecified-high`
  - **Tool**: `bash`
  - **Command**:
    ```bash
    set -euo pipefail
    ./build.sh
    BITFILE="$(find out -type f -name '*.bit' -print -quit)"
    test -n "$BITFILE"
    printf 'TCL PASS | Bitstream %s | VERDICT: APPROVE\n' "$BITFILE"
    ```
  - **Expected Result**: Exit code `0`. The command prints a verdict line with a real `.bit` path.

- [ ] F3. **Testbench Verification** — `unspecified-high`
  - **Tool**: `bash` + Vivado simulator CLI
  - **Command**:
    ```bash
    set -euo pipefail
    source /tools/Xilinx/Vivado/2021.2/settings64.sh
    mkdir -p out
    xvlog -sv src/led_blink.v sim/tb_led_blink.v
    xelab -debug typical tb_led_blink -s tb_led_blink
    xsim tb_led_blink -run all | tee out/final_tb.log
    grep -q "^PASS$" out/final_tb.log
    ! grep -q "^FAIL$" out/final_tb.log
    printf 'Simulation PASS | VERDICT: APPROVE\n'
    ```
  - **Expected Result**: Exit code `0`. The verdict line is printed only after a clean RTL+testbench simulation pass.

- [ ] F4. **Scope Fidelity Check** — `deep`
  - **Tool**: `bash`
  - **Command**:
    ```bash
    ! grep -RqiE "axi(_| )gpio|ila|vio|export_hardware|vitis|sdk" src sim constraints scripts build.sh
    ```
  - **Expected Result**: Exit code `0`. None of the forbidden implementation elements appear in the source files.
  - **Output Format**: `Forbidden Features ABSENT | VERDICT: APPROVE`

---

## Atomic Commit Strategy

1. `docs: add README with hardware setup`
   - Scope: `README.md`
   - Gate: Task 1 QA must pass first

2. `test: add LED blink testbench`
   - Scope: `sim/tb_led_blink.v`
   - Gate: Task 2 QA must pass first

3. `feat: add LED blink RTL module`
   - Scope: `src/led_blink.v`
   - Gate: Task 3 simulation must print `PASS`

4. `feat: add XDC constraints`
   - Scope: `constraints/kv260_pmod.xdc`
   - Gate: Task 4 QA must pass first

5. `feat: add Tcl project script`
   - Scope: `scripts/create_project.tcl`
   - Gate: Task 5 QA must pass first

6. `build: add batch build wrapper`
   - Scope: `build.sh`
   - Gate: Task 6 QA must pass first

7. No commit for Task 7
   - Reason: `out/` and other build products are generated verification artifacts

8. No commit for Task 8
   - Reason: simulation logs are verification artifacts, not source changes

---

## Success Criteria

### Verification Commands
```bash
# Hardware build from the repository root
./build.sh

# Clean-checkout simulation from the repository root
source /tools/Xilinx/Vivado/2021.2/settings64.sh
xvlog -sv src/led_blink.v sim/tb_led_blink.v
xelab -debug typical tb_led_blink -s tb_led_blink
xsim tb_led_blink -run all
```

### Expected Results
- `./build.sh` exits with status `0`
- At least one `.bit` file exists under `out/`
- The simulation flow prints `PASS`
- The simulation flow does not print `FAIL`

### Final Checklist
- [ ] All Must Have items are present
- [ ] All Must Not Have items are absent
- [ ] The batch Tcl flow succeeds through bitstream generation
- [ ] A `.bit` file is produced under `out/`
- [ ] The clean-checkout simulation compiles both RTL and testbench and prints `PASS`
