# Draft: KV260 LED Blink Project

## Requirements (confirmed)
- **Tool**: Vivado 2021.2 (설치되어 있음)
- **Language**: Verilog
- **功能**: LED를 1초에 1번씩 깜빡이기
- **Project Location**: 현재 디렉토리의 out 폴더
- **Creation Method**: TCL 스크립트로 자동화
- **Hardware**: KV260 (Xilinx Zynq UltraScale+ MPSoC)
- **LED Connection**: PMOD 커넥터에 외부 LED 연결

## Technical Decisions
- **Board Selection**: Kria KV260 Vision AI Starter Kit
- **LED Pin**: PMOD1 Pin 1 (H12 - HDA11)
- **Clock**: 100MHz (시스템 클럭 사용)
- **Delay Method**: 클럭 카운터로 1초 딜레이 생성

## Open Questions
- [x] 프로젝트 위치: out 폴더 (해결)
- [x] 생성 방식: TCL 스크립트 (해결)
- [x] LED 연결: PMOD 사용 (해결)
- [ ] LED 연결 시 저항 필요 (후면 설명)

## Scope Boundaries
- IN: Vivado 프로젝트 생성, Verilog 소스, XDC 제약파일, TCL 스크립트
- OUT: 하드웨어 프로그래밍 (JTAG), Vitis SW 개발

## Research Findings
- KV260에는 내장 user LED가 없음
- PMOD 또는 RPi 커넥터로 외부 LED 연결 필요
- PMOD1 Pin 1 = H12 (HDA11)로 LVCMOS33 설정 가능
- Vivado 2021.1/2021.2 튜토리얼 활용 가능
