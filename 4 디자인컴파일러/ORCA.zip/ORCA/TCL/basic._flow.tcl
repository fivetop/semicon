# basic._flow.tcl
# ORCA 블록 합성을 위한 공통 Basic Flow 스크립트
#
# 목적:
#   - block 단위 합성에서 반복되는 절차(환경 설정/읽기/제약/컴파일/리포트/출력)를 표준화
#   - 블록마다 다른 값(탑 모듈명, RTL 목록, 라이브러리, 클록 주기 등)은 설정만 바꿔 재사용
#
# 사용 순서:
#   1) source /DATA/home/edu104/ORCA/TCL/basic._flow.tcl
#   2) set_basic_flow_config ...      ;# 블록별 값 설정
#   3) basic_flow                     ;# 1~6단계 일괄 실행
#      basic_flow 3                   ;# 1~3단계까지만 실행
#
# 참고:
#   - sdc_file가 지정되고 파일이 존재하면 수동 제약(create_clock 등) 대신 SDC를 우선 적용
#   - 스크립트 기본 출력 경로는 /DATA/home/edu104/ORCA/OUT, /DATA/home/edu104/ORCA/RPT
#   - 라이브러리/서치패스 기본값은 DC_LAB/2_Synthesis 설정을 우선 참조

namespace eval ::basic_flow_cfg {
    variable cfg
    # cfg 배열: 기본 합성 설정값
    # set_basic_flow_config 로 필요한 항목만 override 해서 사용한다.
    array set cfg {
        design_name      ORCA_TOP
        rtl_files        {}
        work_lib         WORK
        ref_syn_root     "/DATA/home/edu104/DC_LAB/2_Synthesis"
        ref_setup_script "/DATA/home/edu104/DC_LAB/2_Synthesis/0_Script/1_run_syn_setup"
        ref_setup_file   "/DATA/home/edu104/DC_LAB/2_Synthesis/.synopsys_dc.setup"
        use_ref_setup    1
        search_path      ""
        target_library   ""
        link_library     ""
        sdc_file         ""
        clk_port         clk
        clk_period       10.0
        in_delay         0.2
        out_delay        0.2
        drive_cell       ""
        drive_pin        ""
        out_load         0.05
        use_ultra        1
        compile_map_effort medium
        compile_area_effort  medium
        out_dir          "/DATA/home/edu104/ORCA/OUT"
        rpt_dir          "/DATA/home/edu104/ORCA/RPT"
        log_dir          "/DATA/home/edu104/ORCA/LOG"
        log_file         ""
        netlist_name     ""
        ddc_name         ""
        sdc_name         ""
    }
}

# 사용자 설정 입력 함수
# -key value 쌍으로 설정을 덮어쓴다.
# 예) set_basic_flow_config -design_name CPU_Wrapper -clk_period 5.0
proc set_basic_flow_config {args} {
    variable ::basic_flow_cfg::cfg

    if {[llength $args] % 2 != 0} {
        error "set_basic_flow_config expects key/value pairs."
    }

    foreach {k v} $args {
        set key [string trimleft $k "-"]
        if {$key eq "design"} {
            set key "design_name"
        }
        if {![info exists cfg($key)]} {
            error "Unknown option: $k"
        }
        set cfg($key) $v
    }
}

# 유틸 함수: 포트 존재 여부 확인
# get_ports 결과 collection의 크기로 판단한다.
proc _bf_has_port {port_name} {
    return [expr {[sizeof_collection [get_ports -quiet $port_name]] > 0}]
}

proc _bf_timestamp {} {
    return [clock format [clock seconds] -format "%Y-%m-%d %H:%M:%S"]
}

proc _bf_log {level msg} {
    variable ::basic_flow_cfg::cfg

    set line "[_bf_timestamp] [format {[%s]} $level] $msg"
    puts $line

    if {[info exists cfg(log_file)] && $cfg(log_file) ne ""} {
        set fp [open $cfg(log_file) a]
        puts $fp $line
        close $fp
    }
}

proc _bf_step {step_name body} {
    set t0 [clock milliseconds]
    _bf_log INFO "STEP_START: $step_name"
    uplevel 1 $body
    set dt [expr {([clock milliseconds] - $t0) / 1000.0}]
    _bf_log INFO "STEP_DONE : $step_name (elapsed=${dt}s)"
}

proc _bf_count_violations {rpt_file} {
    # report_constraint -all_violators 결과에서 "VIOLATED" 라인 수를 카운트한다.
    redirect -file $rpt_file { report_constraint -all_violators }

    set fp [open $rpt_file r]
    set txt [read $fp]
    close $fp

    set n 0
    foreach line [split $txt "\n"] {
        if {[regexp -nocase {VIOLATED} $line]} {
            incr n
        }
    }

    # 리포트 포맷 차이 대비: 총 위반 개수 요약 라인이 있으면 우선 사용
    if {[regexp -nocase {total[^0-9]*violat[^0-9]*([0-9]+)} $txt -> total_n]} {
        set n $total_n
    }
    return $n
}

proc _bf_apply_preset_constraints {preset} {
    variable ::basic_flow_cfg::cfg
    set T $cfg(clk_period)

    # path group은 있어도 무해하지만, 가독성을 위해 재정의 시도
    if {[regexp {^P5|^P10} $preset]} {
        catch {remove_path_group CORE}
        catch {group_path -name CORE -critical_range [expr {0.15 * $T}] -weight 5}
    }

    switch -- $preset {
        P1_FMAX_SAFE {
            catch {set_clock_uncertainty -setup [expr {0.08 * $T}] [all_clocks]}
            catch {set_clock_uncertainty -hold  [expr {0.03 * $T}] [all_clocks]}
        }
        P2_FMAX_HIGH_EFFORT {
            catch {set_clock_uncertainty -setup [expr {0.10 * $T}] [all_clocks]}
            catch {set_clock_uncertainty -hold  [expr {0.04 * $T}] [all_clocks]}
        }
        P3_FMAX_RETIME {
            catch {set_clock_uncertainty -setup [expr {0.10 * $T}] [all_clocks]}
            catch {set_clock_uncertainty -hold  [expr {0.04 * $T}] [all_clocks]}
        }
        P4_FMAX_2PASS {
            # 제약 추가 없음
        }
        P5_FMAX_PATH_WEIGHT {
            # group_path만 적용
        }
        P6_FMAX_IO_TIGHT {
            set tight_in  [expr {0.25 * $T}]
            set tight_out [expr {0.25 * $T}]
            if {[_bf_has_port $cfg(clk_port)]} {
                set clk_obj [get_clocks $cfg(clk_port)]
                set all_in [remove_from_collection [all_inputs] [get_ports -quiet $cfg(clk_port)]]
                if {[sizeof_collection $all_in] > 0} {
                    catch {set_input_delay  $tight_in  -clock $clk_obj $all_in}
                }
                if {[sizeof_collection [all_outputs]] > 0} {
                    catch {set_output_delay $tight_out -clock $clk_obj [all_outputs]}
                }
            }
        }
        P7_FMAX_TRANSITION_CTRL {
            catch {set_max_transition 0.20 [current_design]}
            catch {set_max_capacitance 0.20 [current_design]}
        }
        P8_FMAX_FANOUT_CTRL {
            catch {set_max_fanout 10 [current_design]}
            catch {set_clock_uncertainty -setup [expr {0.09 * $T}] [all_clocks]}
        }
        P9_FMAX_DFT_AWARE {
            # 제약 추가 없음
        }
        P10_FMAX_AGGR {
            catch {set_clock_uncertainty -setup [expr {0.12 * $T}] [all_clocks]}
            catch {set_clock_uncertainty -hold  [expr {0.05 * $T}] [all_clocks]}
        }
        default {
            error "Unknown synthesis preset: $preset"
        }
    }
}

proc _bf_compile_with_preset {preset} {
    variable ::basic_flow_cfg::cfg

    switch -- $preset {
        P1_FMAX_SAFE {
            compile_ultra
        }
        P2_FMAX_HIGH_EFFORT {
            compile_ultra -timing_high_effort_script
        }
        P3_FMAX_RETIME {
            compile_ultra -retime -timing_high_effort_script
        }
        P4_FMAX_2PASS {
            compile_ultra -timing_high_effort_script
            compile_ultra -incremental
        }
        P5_FMAX_PATH_WEIGHT {
            compile_ultra -timing_high_effort_script
        }
        P6_FMAX_IO_TIGHT {
            compile_ultra -timing_high_effort_script
        }
        P7_FMAX_TRANSITION_CTRL {
            compile_ultra
        }
        P8_FMAX_FANOUT_CTRL {
            compile_ultra
        }
        P9_FMAX_DFT_AWARE {
            compile_ultra -scan -timing_high_effort_script
        }
        P10_FMAX_AGGR {
            compile_ultra -retime -timing_high_effort_script
            compile_ultra -incremental
        }
        default {
            if {$cfg(use_ultra)} {
                compile_ultra
            } else {
                compile -map_effort $cfg(compile_map_effort) -area_effort $cfg(compile_area_effort)
            }
        }
    }
}

# [1] 환경/초기화 단계
# - 출력/리포트 디렉토리 생성
# - WORK 라이브러리 정의
# - 2_Synthesis setup(source) 후 search/target/link library 반영
proc init_env {} {
    variable ::basic_flow_cfg::cfg

    file mkdir $cfg(out_dir)
    file mkdir $cfg(rpt_dir)
    file mkdir $cfg(log_dir)

    if {$cfg(log_file) eq ""} {
        set cfg(log_file) [file join $cfg(log_dir) "${cfg(design_name)}_basic_flow.log"]
    }
    set fp [open $cfg(log_file) w]
    puts $fp "=== basic_flow log start: [_bf_timestamp] ==="
    close $fp

    # 2_Synthesis setup을 우선 반영한다.
    # .synopsys_dc.setup 내부 상대경로를 보장하기 위해 ref_syn_root로 이동 후 source 수행.
    if {$cfg(use_ref_setup)} {
        set old_pwd [pwd]
        if {![file isdirectory $cfg(ref_syn_root)]} {
            error "ref_syn_root not found: $cfg(ref_syn_root)"
        }
        set rc [catch {
            cd $cfg(ref_syn_root)
            if {[file exists $cfg(ref_setup_script)]} {
                _bf_log INFO "Source ref setup script: $cfg(ref_setup_script)"
                source $cfg(ref_setup_script)
            } elseif {[file exists $cfg(ref_setup_file)]} {
                _bf_log INFO "Source ref setup file: $cfg(ref_setup_file)"
                source $cfg(ref_setup_file)
            } else {
                error "No reference setup found. checked: $cfg(ref_setup_script), $cfg(ref_setup_file)"
            }
        } err]
        cd $old_pwd
        if {$rc} {
            error $err
        }
    }

    define_design_lib $cfg(work_lib) -path ./$cfg(work_lib)

    # 사용자 override 값이 있으면 참조 설정값 위에 덮어쓴다.
    if {$cfg(search_path) ne ""} {
        set_app_var search_path $cfg(search_path)
    }
    if {$cfg(target_library) ne ""} {
        set_app_var target_library $cfg(target_library)
    }
    if {$cfg(link_library) ne ""} {
        set_app_var link_library $cfg(link_library)
    }

    _bf_log INFO "init_env complete"
    _bf_log INFO "design_name    : $cfg(design_name)"
    _bf_log INFO "search_path    : [get_app_var search_path]"
    _bf_log INFO "target_library : [get_app_var target_library]"
    _bf_log INFO "link_library   : [get_app_var link_library]"
    _bf_log INFO "log_file       : $cfg(log_file)"
}

# [2] RTL 읽기 + 엘라보레이션 + 링크 단계
# - analyze / elaborate / current_design / link / uniquify
# - check_design 결과를 리포트 파일로 저장
proc read_and_link_design {} {
    variable ::basic_flow_cfg::cfg

    if {[llength $cfg(rtl_files)] == 0} {
        error "rtl_files is empty. Set it with set_basic_flow_config -rtl_files { ... }"
    }
    if {$cfg(design_name) eq ""} {
        error "design_name is empty. Set it with set_basic_flow_config -design_name <top>"
    }

    analyze -format verilog $cfg(rtl_files)
    elaborate $cfg(design_name)
    current_design $cfg(design_name)
    link
    uniquify

    redirect -file [file join $cfg(rpt_dir) "${cfg(design_name)}_check_design.rpt"] {
        check_design
    }

    _bf_log INFO "read_and_link_design complete"
}

# [3] 제약 적용 단계
# - sdc_file이 있으면 source로 일괄 적용
# - 없으면 기본 제약(create_clock, I/O delay, driving cell, load) 적용
proc apply_constraints {} {
    variable ::basic_flow_cfg::cfg

    if {$cfg(sdc_file) ne "" && [file exists $cfg(sdc_file)]} {
        source $cfg(sdc_file)
        _bf_log INFO "Applied SDC: $cfg(sdc_file)"
    } else {
        if {[_bf_has_port $cfg(clk_port)]} {
            create_clock -name $cfg(clk_port) -period $cfg(clk_period) [get_ports $cfg(clk_port)]
        } else {
            _bf_log WARN "clock port '$cfg(clk_port)' not found. Skip create_clock."
        }

        if {[_bf_has_port $cfg(clk_port)]} {
            set clk_obj [get_clocks $cfg(clk_port)]
            set all_in [remove_from_collection [all_inputs] [get_ports -quiet $cfg(clk_port)]]
            if {[sizeof_collection $all_in] > 0} {
                set_input_delay $cfg(in_delay) -clock $clk_obj $all_in
            }
            if {[sizeof_collection [all_outputs]] > 0} {
                set_output_delay $cfg(out_delay) -clock $clk_obj [all_outputs]
            }
        }

        if {$cfg(drive_cell) ne "" && $cfg(drive_pin) ne ""} {
            set non_clk_in [remove_from_collection [all_inputs] [get_ports -quiet $cfg(clk_port)]]
            if {[sizeof_collection $non_clk_in] > 0} {
                set_driving_cell -lib_cell $cfg(drive_cell) -pin $cfg(drive_pin) $non_clk_in
            }
        }

        if {[sizeof_collection [all_outputs]] > 0} {
            set_load $cfg(out_load) [all_outputs]
        }
    }

    _bf_log INFO "apply_constraints complete"
}

# [4] 합성 단계
# - use_ultra=1: compile_ultra
# - use_ultra=0: compile(map/area effort 사용)
proc run_synthesis {} {
    variable ::basic_flow_cfg::cfg

    # 10개 preset을 동일 출발점에서 비교하기 위해 pre-compile 스냅샷 저장
    set seed_ddc [file join $cfg(out_dir) "${cfg(design_name)}_seed_precompile.ddc"]
    write -format ddc -hierarchy -output $seed_ddc
    _bf_log INFO "Saved pre-compile seed DDC: $seed_ddc"

    set preset_list [list \
        P1_FMAX_SAFE \
        P2_FMAX_HIGH_EFFORT \
        P3_FMAX_RETIME \
        P4_FMAX_2PASS \
        P5_FMAX_PATH_WEIGHT \
        P6_FMAX_IO_TIGHT \
        P7_FMAX_TRANSITION_CTRL \
        P8_FMAX_FANOUT_CTRL \
        P9_FMAX_DFT_AWARE \
        P10_FMAX_AGGR \
    ]

    set best_preset ""
    set best_viol -1
    set best_ddc ""
    set summary_rows {}

    foreach p $preset_list {
        _bf_log INFO "Preset sweep start: $p"
        set rc [catch {
            # 동일 시작점 복원
            read_ddc $seed_ddc
            current_design $cfg(design_name)
            link

            _bf_apply_preset_constraints $p
            _bf_compile_with_preset $p

            set vrpt [file join $cfg(rpt_dir) "${cfg(design_name)}_${p}_viol.rpt"]
            set vcnt [_bf_count_violations $vrpt]

            set pddc [file join $cfg(out_dir) "${cfg(design_name)}_${p}.ddc"]
            write -format ddc -hierarchy -output $pddc

            _bf_log INFO "Preset result: $p violation_count=$vcnt ddc=$pddc"
            lappend summary_rows [format "%-24s %8d" $p $vcnt]

            if {$best_preset eq "" || $vcnt < $best_viol} {
                set best_preset $p
                set best_viol $vcnt
                set best_ddc $pddc
            }
        } err]

        if {$rc} {
            _bf_log WARN "Preset failed: $p error=$err"
        }
    }

    if {$best_preset eq ""} {
        error "All synthesis presets failed. Check logs and library/options compatibility."
    }

    # 이후 report/write 단계는 최적 preset 결과를 기준으로 수행
    read_ddc $best_ddc
    current_design $cfg(design_name)
    link

    set cfg(selected_preset) $best_preset
    set cfg(selected_violations) $best_viol

    # preset sweep 요약 파일 저장
    set summary_file [file join $cfg(rpt_dir) "${cfg(design_name)}_preset_sweep_summary.rpt"]
    set fp [open $summary_file w]
    puts $fp "Preset Sweep Summary"
    puts $fp "Design: $cfg(design_name)"
    puts $fp ""
    puts $fp [format "%-24s %8s" "Preset" "ViolCnt"]
    puts $fp [string repeat "-" 36]
    foreach row $summary_rows {
        puts $fp $row
    }
    puts $fp [string repeat "-" 36]
    puts $fp "BEST_PRESET=$best_preset"
    puts $fp "BEST_VIOLATION_COUNT=$best_viol"
    close $fp

    _bf_log INFO "Selected best preset: $best_preset (violation_count=$best_viol)"
    _bf_log INFO "Preset sweep summary file: $summary_file"
    _bf_log INFO "run_synthesis complete"
}

# [5] 검증/리포트 단계
# - QoR, timing, area, power, timing check, 위반 제약 보고서 생성
proc generate_reports {} {
    variable ::basic_flow_cfg::cfg

    set base [file join $cfg(rpt_dir) $cfg(design_name)]
    redirect -file "${base}_qor.rpt"     { report_qor }
    redirect -file "${base}_timing.rpt"  { report_timing -max_paths 10 -delay_type max }
    redirect -file "${base}_area.rpt"    { report_area }
    redirect -file "${base}_power.rpt"   { report_power }
    redirect -file "${base}_check_t.rpt" { check_timing }
    redirect -file "${base}_viol.rpt"    { report_constraint -all_violators }

    _bf_log INFO "generate_reports complete"
}

# [6] 산출물 저장 단계
# - mapped netlist(.v), 설계 DB(.ddc), constraint(.sdc) 기록
# - 파일명이 비어 있으면 design_name 기반 기본 이름 사용
proc write_outputs {} {
    variable ::basic_flow_cfg::cfg

    set netlist_name $cfg(netlist_name)
    set ddc_name $cfg(ddc_name)
    set sdc_name $cfg(sdc_name)

    if {$netlist_name eq ""} { set netlist_name "${cfg(design_name)}_mapped.v" }
    if {$ddc_name eq ""}     { set ddc_name     "${cfg(design_name)}.ddc" }
    if {$sdc_name eq ""}     { set sdc_name     "${cfg(design_name)}.sdc" }

    write -format verilog -hierarchy -output [file join $cfg(out_dir) $netlist_name]
    write -format ddc -hierarchy -output [file join $cfg(out_dir) $ddc_name]
    write_sdc [file join $cfg(out_dir) $sdc_name]

    _bf_log INFO "write_outputs complete"
}

# 오케스트레이션 함수: 1~N(최대 6) 단계를 순차 실행
# 예) basic_flow 4  -> 1~4단계만 실행
proc basic_flow {{max_step 6}} {
    if {![string is integer -strict $max_step]} {
        error "basic_flow max_step must be an integer (1..6)."
    }
    if {$max_step < 1 || $max_step > 6} {
        error "basic_flow max_step out of range: $max_step (valid: 1..6)"
    }

    set t0 [clock milliseconds]
    _bf_log INFO "basic_flow requested max_step=$max_step"

    if {$max_step >= 1} { _bf_step "1.init_env"             { init_env } }
    if {$max_step >= 2} { _bf_step "2.read_and_link_design" { read_and_link_design } }
    if {$max_step >= 3} { _bf_step "3.apply_constraints"    { apply_constraints } }
    if {$max_step >= 4} { _bf_step "4.run_synthesis"        { run_synthesis } }
    if {$max_step >= 5} { _bf_step "5.generate_reports"     { generate_reports } }
    if {$max_step >= 6} { _bf_step "6.write_outputs"        { write_outputs } }

    set total [expr {([clock milliseconds] - $t0) / 1000.0}]
    if {[info exists cfg(selected_preset)]} {
        _bf_log INFO "================ FINAL BEST PRESET ================"
        _bf_log INFO "BEST_PRESET : $cfg(selected_preset)"
        _bf_log INFO "VIOLATIONS  : $cfg(selected_violations)"
        _bf_log INFO "==================================================="
    }
    _bf_log INFO "basic_flow complete (ran 1..$max_step, total=${total}s)"
}
