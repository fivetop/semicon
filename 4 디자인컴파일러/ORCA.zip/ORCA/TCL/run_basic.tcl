# run_basic.tcl
# ORCA 프로젝트의 합성 플로우를 원클릭으로 실행하는 유틸리티 스크립트
#
# 이 파일은 DC_LAB/2_Synthesis/0_Script 디렉토리 내부에 존재하는
# 단계별 스크립트(1_run_syn_setup, 2_run_syn_read_verilog, …, 7_run_syn_write_output)
# 를 순차적으로 소싱(source)하여 전체 플로우를 자동으로 수행합니다.
#
# 프로시저: run_basic
#   - 인자 없음
#   - 사용 예:
#         dc_shell> source /DATA/home/edu104/ORCA/TCL/run_basic.tcl
#         dc_shell> run_basic
#   - 로그 메시지를 출력하며 각 단계 스크립트가 발견되지 않으면 경고를 남김
#
# 확장:
#   필요에 따라 steps 리스트에 스크립트를 추가하거나 순서를 변경할 수 있습니다.


proc run_basic {} {
    set base "/DATA/home/edu104/DC_LAB/2_Synthesis/0_Script"
    set steps {1_run_syn_setup 2_run_syn_read_verilog 2b_run_syn_read_verilog 3_run_syn_link_check 4_run_syn_constraints 5_run_syn_compile 6_run_syn_report 7_run_syn_write_output}

    puts "=== Running basic synthesis flow ==="
    puts ">>> Initial target_library: [get_app_var target_library]"

    foreach step $steps {
        set script [file join $base $step]
        if {[file exists $script]} {
            puts "-- sourcing $script"
            source $script
            # 각 단계 후 target_library 확인
            puts ">>> After $step: target_library = [get_app_var target_library]"
        } else {
            puts "WARNING: script $script not found, skipping"
        }
    }
    puts "=== Basic flow complete ==="
    puts ">>> Final target_library: [get_app_var target_library]"
}
