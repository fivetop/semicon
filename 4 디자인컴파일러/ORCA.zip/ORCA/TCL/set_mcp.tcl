# ----------------------------------------------------------------------
# set_mcp.tcl
# Multicycle Path (MCP) 을 편하게 설정하는 스크립트
# 입력 파라미터:
#   period   : 허용할 사이클 수 (정수)
#   from obj : 출발 오브젝트(핀, 셀 등) 또는 패턴
#   to obj   : 도착 오브젝트 또는 패턴
# 예시:
#   dc_shell> source set_mcp.tcl
#   dc_shell> set_mcp 3 regA/Q regB/D
#   또는
#   dc_shell> set_mcp 4 [get_pins core/reg_ctrl/Q*] [get_pins core/reg_data/D*]
# ----------------------------------------------------------------------

proc set_mcp {period from to {comment ""} {clocks ""}} {
    # 도움말/사용법 출력 조건
    if {$period eq "" || $period eq "help" || $period eq "-help" || $period eq "--help"} {
        puts "Usage: set_mcp <period> <from_object> <to_object> [comment] [clocks]"
        puts "  period       : integer >=2, allowable cycles"
        puts "  from_object  : start pin/object or pattern"
        puts "  to_object    : end pin/object or pattern"
        puts "  comment      : optional description"
        puts "  clocks       : optional clock(s) for multi-clock path (space separated)"
        return
    }

    # 입력 검증
    if {![string is integer $period] || $period < 2} {
        puts "ERROR: period must be integer >= 2 (got: $period)"
        return
    }

    # from/to 객체가 존재하는지 간단 확인 (컬렉션이 비어있지 않은지)
    set from_objs [get_pins $from -quiet]
    set to_objs   [get_pins $to   -quiet]

    if {[sizeof_collection $from_objs] == 0} {
        puts "WARNING: No pins matched for -from '$from'"
    }
    if {[sizeof_collection $to_objs] == 0} {
        puts "WARNING: No pins matched for -to '$to'"
    }

    # Multicycle Path 설정
    set options_setup -setup $period -from $from -to $to
    set options_hold  -hold [expr $period - 1] -from $from -to $to
    if {$clocks ne ""} {
        append options_setup " -through $clocks"
        append options_hold  " -through $clocks"
    }
    eval set_multicycle_path $options_setup
    eval set_multicycle_path $options_hold

    # 로그 출력 (가독성 좋게)
    set msg "MCP applied: setup $period / hold [expr $period-1]"
    if {$comment ne ""} {
        append msg "   // $comment"
    }
    if {$clocks ne ""} {
        append msg "   (clocks: $clocks)"
    }
    puts $msg
    puts "   -from $from"
    puts "   -to   $to"
    if {$clocks ne ""} {
        puts "   -clocks $clocks"
    }
    puts ""
}
