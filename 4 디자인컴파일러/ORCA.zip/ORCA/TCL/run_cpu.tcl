# run_cpu.tcl
# CPU 블록 합성을 위해 basic_flow를 호출하는 래퍼 스크립트
#
# 사용 예:
#   dc_shell> source /DATA/home/edu104/ORCA/TCL/run_cpu.tcl
#   dc_shell> run_cpu
#   dc_shell> run_cpu -design_name CPU_Wrapper -clk_period 5.0
#   dc_shell> run_cpu -target_library "/path/sc_max.db" -link_library "* /path/sc_max.db"

proc run_cpu {args} {
    # 기본값: 현재 ORCA 구조 기준 CPU 관련 RTL
    set design_name "RISC_CORE"
    set rtl_files [list \
        /DATA/home/edu104/ORCA/DOC/RTL/RISC_CORE.v \
        /DATA/home/edu104/ORCA/DOC/RTL/CONTROL.v \
        /DATA/home/edu104/ORCA/DOC/RTL/DATA_PATH.v \
        /DATA/home/edu104/ORCA/DOC/RTL/ALU.v \
        /DATA/home/edu104/ORCA/DOC/RTL/REG_FILE.v \
        /DATA/home/edu104/ORCA/DOC/RTL/BLENDER.v \
        /DATA/home/edu104/ORCA/DOC/RTL/PRGRM_CNT_TOP.v \
        /DATA/home/edu104/ORCA/DOC/RTL/PRGRM_CNT.v \
        /DATA/home/edu104/ORCA/DOC/RTL/PRGRM_DECODE.v \
        /DATA/home/edu104/ORCA/DOC/RTL/PRGRM_FSM.v \
        /DATA/home/edu104/ORCA/DOC/RTL/INSTRN_LAT.v \
    ]

    set target_library ""
    set link_library   ""
    set sdc_file       ""
    set clk_port       "clk"
    set clk_period     10.0
    set out_dir        "/DATA/home/edu104/ORCA/OUT/CPU"
    set rpt_dir        "/DATA/home/edu104/ORCA/RPT/CPU"
    set use_ultra      1

    # 인자 파싱: -key value 쌍
    if {[llength $args] % 2 != 0} {
        error "run_cpu expects key/value pairs. Example: run_cpu -clk_period 5.0"
    }
    foreach {k v} $args {
        switch -- $k {
            -design_name    { set design_name $v }
            -rtl_files      { set rtl_files $v }
            -target_library { set target_library $v }
            -link_library   { set link_library $v }
            -sdc_file       { set sdc_file $v }
            -clk_port       { set clk_port $v }
            -clk_period     { set clk_period $v }
            -out_dir        { set out_dir $v }
            -rpt_dir        { set rpt_dir $v }
            -use_ultra      { set use_ultra $v }
            default {
                error "Unknown option: $k"
            }
        }
    }

    # CPU_Wrapper가 준비된 경우 top 이름을 CPU_Wrapper로 쉽게 전환 가능
    # 기본값은 현재 RTL 존재 기준으로 RISC_CORE를 사용한다.
    foreach f $rtl_files {
        if {![file exists $f]} {
            error "RTL file not found: $f"
        }
    }

    source /DATA/home/edu104/ORCA/TCL/basic._flow.tcl

    set_basic_flow_config \
        -design_name    $design_name \
        -rtl_files      $rtl_files \
        -target_library $target_library \
        -link_library   $link_library \
        -sdc_file       $sdc_file \
        -clk_port       $clk_port \
        -clk_period     $clk_period \
        -out_dir        $out_dir \
        -rpt_dir        $rpt_dir \
        -use_ultra      $use_ultra

    puts "== run_cpu =="
    puts "design_name: $design_name"
    puts "rtl_files  : [llength $rtl_files] files"
    puts "out_dir    : $out_dir"
    puts "rpt_dir    : $rpt_dir"

    basic_flow
}
