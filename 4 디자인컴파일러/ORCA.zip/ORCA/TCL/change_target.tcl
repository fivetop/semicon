# change_target.tcl
# 여러 개의 target_library를 순차적으로 변경하면서 basic flow를 실행하는 유틸리티 스크립트
#
# 목적:
#   SAED32 라이브러리의 다양한 variant(rvt, hvt, lvt 등) 간에 쉽게 전환하여
#   각 라이브러리로 합성 플로우를 순차적으로 재실행할 수 있도록 합니다.
#
# 프로시저: change_target
#   입력: target_lib1 [target_lib2 target_lib3 ...] (단일 개 또는 여러 개의 라이브러리 이름)
#   사용 예:
#         dc_shell> source /DATA/home/edu104/ORCA/TCL/change_target.tcl
#         dc_shell> change_target "saed32hvt_ss0p95v125c.db"
#         dc_shell> change_target "saed32rvt_ss0p95v125c.db" "saed32hvt_ss0p95v125c.db" "saed32lvt_ss0p95v125c.db"
#   
#   동작 흐름:
#     1. 입력 검증 (단일 개 이상의 라이브러리 확인)
#     2. 각 라이브러리에 대해 순차적으로:
#        - 현재 target_library 저장
#        - 새로운 target_library 설정
#        - link_library 업데이트
#        - 변경 성공 확인
#        - 디자인 재링크 (link 명령)
#        - run_basic 실행 (모든 7단계 합성 스크립트 순차 실행)
#        - 최종 확인 (입력값과 실제값 일치도 검증)
#     3. 모든 라이브러리 처리 완료 메시지 출력

proc change_target {args} {
    # ===== 입력 검증 =====
    # 최소 1개 이상의 target_library가 주어져야 함
    if {[llength $args] == 0} {
        puts "ERROR: At least one target_library must be provided"
        puts "Usage: change_target lib1.db \[lib2.db lib3.db ...\]"
        return
    }

    # run_basic 함수가 메모리에 로드되어 있는지 미리 확인
    if {[info procs run_basic] eq ""} {
        puts ">>> Sourcing run_basic.tcl ..."
        source [file join [file dirname [info script]] run_basic.tcl]
    }

    # ===== 여러 target_library 순차 실행 =====
    set total_libs [llength $args]
    set current_idx 1

    foreach target_lib $args {
        puts ""
        puts "===== Library $current_idx / $total_libs: $target_lib ====="

        # 빈 문자열 확인
        if {$target_lib eq ""} {
            puts "ERROR: target_lib cannot be empty"
            incr current_idx
            continue
        }

        # ===== 현재 상태 저장 =====
        # 변경 전 target_library 값을 저장하여 로그 메시지에 사용
        set old_target [get_app_var target_library]

        # ===== target_library 변경 =====
        # DC app variable인 target_library를 새 라이브러리로 변경
        puts ">>> Changing target_library from '$old_target' to '$target_lib'"
        set_app_var target_library $target_lib

        # ===== link_library 업데이트 =====
        # link_library도 함께 변경하여 새 target_library와의 일관성 유지
        set_app_var link_library "* $target_lib"

        # ===== 변경 성공 확인 =====
        # set_app_var 실행 후 실제로 값이 변경되었는지 검증
        set new_target [get_app_var target_library]
        if {$new_target eq $target_lib} {
            puts ">>> Target library successfully changed to: $new_target"
        } else {
            puts "WARNING: Target library change failed! Current: $new_target"
            incr current_idx
            continue
        }

        # ===== 디자인 재링크 =====
        # target_library 변경 후 기존 디자인을 새 라이브러리와 링크
        puts ">>> Re-linking design with new target library..."
        link

        # ===== basic flow 실행 =====
        # 2_Synthesis/0_Script의 1~7 단계 스크립트를 순차 실행
        puts ">>> Starting basic flow with new target_library..."
        run_basic

        # ===== 최종 확인 =====
        # run_basic 실행 후 target_library가 유지되었는지 확인
        set final_target [get_app_var target_library]
        if {$final_target eq $target_lib} {
            puts ">>> SUCCESS: Target library matches input '$target_lib' after basic flow."
        } else {
            puts ">>> WARNING: Target library changed during flow! Input: '$target_lib', Final: '$final_target'"
        }

        incr current_idx
    }

    # ===== 모든 라이브러리 처리 종료 =====
    puts ""
    puts "===== Sequential synthesis with all target libraries completed ====="
    puts ">>> Total libraries processed: $total_libs"
    puts ">>> Final target_library: [get_app_var target_library]"
}
