# ----------------------------------------------------------------------
#  EXAMPLE: simple panedwindow facility
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Panedwindow.grip.cursor sb_v_double_arrow widgetDefault

proc panedwindow_create {win width height} {
    global pwInfo

    frame $win -class Panedwindow -width $width -height $height
    frame $win.pane1
    place $win.pane1 -relx 0.5 -rely 0 -anchor n \
        -relwidth 1.0 -relheight 0.5
    frame $win.pane2
    place $win.pane2 -relx 0.5 -rely 1.0 -anchor s \
        -relwidth 1.0 -relheight 0.5

    frame $win.sash -height 4 -borderwidth 2 -relief sunken
    place $win.sash -relx 0.5 -rely 0.5 -relwidth 1.0 -anchor c

    frame $win.grip -width 10 -height 10 \
        -borderwidth 2 -relief raised
    place $win.grip -relx 0.95 -rely 0.5 -anchor c

    bind $win.grip <ButtonPress-1>   "panedwindow_grab $win"
    bind $win.grip <B1-Motion>       "panedwindow_drag $win %Y"
    bind $win.grip <ButtonRelease-1> "panedwindow_drop $win %Y"

    return $win
}

proc panedwindow_grab {win} {
    $win.grip configure -relief sunken
}

proc panedwindow_drag {win y} {
    set realY [expr $y-[winfo rooty $win]]
    set Ymax  [winfo height $win]
    set frac [expr double($realY)/$Ymax]
    if {$frac < 0.05} {
        set frac 0.05
    }
    if {$frac > 0.95} {
        set frac 0.95
    }
    place $win.sash -rely $frac
    place $win.grip -rely $frac

    return $frac
}

proc panedwindow_drop {win y} {
    set frac [panedwindow_drag $win $y]
    panedwindow_divide $win $frac
    $win.grip configure -relief raised
}

proc panedwindow_divide {win frac} {
    place $win.sash -rely $frac
    place $win.grip -rely $frac

    place $win.pane1 -relheight $frac
    place $win.pane2 -relheight [expr 1-$frac]
}
