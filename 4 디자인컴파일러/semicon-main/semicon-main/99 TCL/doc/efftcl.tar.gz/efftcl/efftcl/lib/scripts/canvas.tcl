# ----------------------------------------------------------------------
#  EXAMPLE: canvas library routines
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
# USAGE: canvas_bind_select <thing>
#
# Adds bindings that support selection of canvas items to the
# given <thing>.  This may be a canvas widget, or a bind tag
# that can be added to a canvas widget.
# ----------------------------------------------------------------------
proc canvas_bind_select {thing} {
    bind $thing <ButtonPress-1> {
        canvas_shape_create %W rectangle %x %y
    }
    bind $thing <B1-Motion> {
        canvas_shape_drag %W %x %y
    }
    bind $thing <ButtonRelease-1> {
        canvas_select_end %W %x %y
    }
    bind $thing <Shift-ButtonRelease-1> {
        canvas_select_end %W %x %y add
    }
    bind $thing <KeyPress-BackSpace> {
        canvas_select_delete %W
    }
    bind $thing <KeyPress-Delete> {
        canvas_select_delete %W
    }
    bind $thing <KeyPress-Up> {
        canvas_select_move %W 0 -2
    }
    bind $thing <KeyPress-Down> {
        canvas_select_move %W 0 2
    }
    bind $thing <KeyPress-Left> {
        canvas_select_move %W -2 0
    }
    bind $thing <KeyPress-Right> {
        canvas_select_move %W 2 0
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_bind_rect <thing>
#
# Adds bindings that support the creation of rectangle items to
# the given <thing>.  This may be a canvas widget, or a bind tag
# that can be added to a canvas widget.
# ----------------------------------------------------------------------
proc canvas_bind_rect {thing} {
    bind $thing <ButtonPress-1> {
        canvas_shape_create %W rectangle %x %y
    }
    bind $thing <B1-Motion> {
        canvas_shape_drag %W %x %y
    }
    bind $thing <ButtonRelease-1> {
        canvas_shape_end %W %x %y
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_bind_oval <thing>
#
# Adds bindings that support the creation of oval items to the
# given <thing>.  This may be a canvas widget, or a bind tag
# that can be added to a canvas widget.
# ----------------------------------------------------------------------
proc canvas_bind_oval {thing} {
    bind $thing <ButtonPress-1> {
        canvas_shape_create %W oval %x %y
    }
    bind $thing <B1-Motion> {
        canvas_shape_drag %W %x %y
    }
    bind $thing <ButtonRelease-1> {
        canvas_shape_end %W %x %y
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_bind_spline <thing>
#
# Adds bindings that support the creation of spline items to the
# given <thing>.  This may be a canvas widget, or a bind tag
# that can be added to a canvas widget.
# ----------------------------------------------------------------------
proc canvas_bind_spline {thing} {
    bind $thing <ButtonPress-1> {
        canvas_spline_point %W %x %y
    }
    bind $thing <Motion> {
        canvas_spline_adjust %W %x %y
    }
    bind $thing <Double-ButtonPress-1> {
        canvas_spline_done %W
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_bind_text <canvas>
#
# Adds bindings that support the creation and editing of text items
# to the given <thing>.  This may be a canvas widget, or a bind tag
# that can be added to a canvas widget.
# ----------------------------------------------------------------------
proc canvas_bind_text {thing} {
    bind $thing <ButtonPress-1> {
        canvas_text_select %W %x %y
    }
    bind $thing <KeyPress> {
        canvas_text_edit_add %W %A
    }
    bind $thing <KeyPress-Return> {
        canvas_text_edit_add %W "\n"
    }
    bind $thing <KeyPress-BackSpace> {
        canvas_text_edit_backsp %W
    }
    bind $thing <KeyPress-Delete> {
        canvas_text_edit_backsp %W
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_select_end <canvas> <x> <y> ?<op>?
#
# Invoked at the end of selection operation to handle the release
# point <x>,<y> on a <canvas>.  Finds the items in the selection
# rectangle and draws a marker around them.  If the optional <op>
# argument is "add", then the items are added to previously selected
# items.  Otherwise, previously selected items are forgotten, and
# only the new items are selected.
# ----------------------------------------------------------------------
proc canvas_select_end {win x y {op "clear"}} {
    global env canvInfo

    canvas_shape_drag $win $x $y

    set coords [$win coords "rubbershape"]
    foreach {x0 y0 x1 y1} $coords {}
    $win delete "rubbershape"

    canvas_select_done $win $op

    if {abs($x1-$x0) < 2 && abs($y1-$y0) < 2} {
        set items [$win find overlapping $x0 $y0 $x0 $y0]
        $win addtag "selected" withtag [lindex $items end]
    } else {
        eval $win addtag "selected" enclosed $coords
    }

    set coords [$win bbox "selected"]
    if {$coords != ""} {
        foreach {x0 y0 x1 y1} $coords {}

        $win create line \
            $x0 $y0 $x1 $y0 $x1 $y1 $x0 $y1 $x0 $y0 \
            -fill black -width 2 -tags "marker"

        set images {
            stripes.xbm stripes2.xbm stripes3.xbm stripes4.xbm
        }
        set file [file join $env(EFFTCL_LIBRARY) images %v]
        set cmd [list $win itemconfigure marker -stipple @$file]
        set canvInfo($win-shimmer) [animate_start 200 $images $cmd]
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_select_done <canvas> ?<op>?
#
# Used to clear the current selection.  If a marker rectangle is
# on the canvas, it is deleted.  If the optional <op> argument is
# "clear", then the "selected" tag is removed from any items that
# might have been selected.  Otherwise, the current items remain
# selected.
# ----------------------------------------------------------------------
proc canvas_select_done {win {op clear}} {
    global canvInfo

    $win delete "marker"
    if {[info exists canvInfo($win-shimmer)]} {
        animate_stop $canvInfo($win-shimmer)
        unset canvInfo($win-shimmer)
    }
    if {$op == "clear"} {
        $win dtag "selected"
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_select_delete <canvas>
#
# Deletes any items that have been selected by a previous call
# to canvas_select_end.
# ----------------------------------------------------------------------
proc canvas_select_delete {win} {
    $win delete "selected"
    canvas_select_done $win
}

# ----------------------------------------------------------------------
# USAGE: canvas_select_move <canvas> <dx> <dy>
#
# Moves any items that have been selected by a previous call
# to canvas_select_end.  Items are moved by <dx> in the x-direction,
# and <dy> in the y-direction.
# ----------------------------------------------------------------------
proc canvas_select_move {win dx dy} {
    $win move "selected" $dx $dy
    $win move "marker" $dx $dy
}

# ----------------------------------------------------------------------
# USAGE: canvas_select_scale <canvas> <sx> <sy>
#
# Scales any items that have been selected by a previous call
# to canvas_select_end.  Items are scaled by <sx> in the x-direction,
# and <sy> in the y-direction.
# ----------------------------------------------------------------------
proc canvas_select_scale {win sx sy} {
    foreach {x0 y0 x1 y1} [$win bbox "selected"] {}

    set xm [expr 0.5*($x0+$x1)]
    set ym [expr 0.5*($y0+$y1)]
    $win scale "selected" $xm $ym $sx $sy
    $win scale "marker" $xm $ym $sx $sy
}

# ----------------------------------------------------------------------
# USAGE: canvas_pen <canvas> <color>
#
# Sets the pen color for items created by the procedures in this
# library.  If any items have been selected by a previous call to
# canvas_select_end, their pen color is updated to the new <color>.
# ----------------------------------------------------------------------
proc canvas_pen {win color} {
    global canvInfo

    foreach item [$win find withtag "selected"] {
        switch [$win type $item] {
            rectangle - polygon - oval - arc {
                $win itemconfigure $item -outline $color
            }
            line - text {
                $win itemconfigure $item -fill $color
            }
            bitmap {
                $win itemconfigure $item -foreground $color
            }
        }
    }
    set canvInfo($win-penColor) $color
}

# ----------------------------------------------------------------------
# USAGE: canvas_fill <canvas> <color>
#
# Sets the fill color for items created by the procedures in this
# library.  If any items have been selected by a previous call to
# canvas_select_end, their pen color is updated to the new <color>.
# ----------------------------------------------------------------------
proc canvas_fill {win color} {
    global canvInfo

    foreach item [$win find withtag "selected"] {
        switch [$win type $item] {
            rectangle - polygon - oval - arc {
                $win itemconfigure $item -fill $color
            }
            bitmap {
                $win itemconfigure $item -background $color
            }
        }
    }
    set canvInfo($win-fillColor) $color
}

# ----------------------------------------------------------------------
# USAGE: canvas_shape_create <canvas> <shape> <x> <y>
#        canvas_shape_drag <canvas> <x> <y>
#        canvas_shape_end <canvas> <x> <y>
#
# Used to handle the click, drag and drop actions when a new shape
# is created on the canvas.  The "create" operation creates a new
# <shape> item with the starting coordinate <x>,<y>.  The "drag"
# operation stretches its end coordinate to <x>,<y>.  The "end"
# operation sets its end coordinate and final colors.
# ----------------------------------------------------------------------
proc canvas_shape_create {win shape x y} {
    $win create $shape \
        $x $y $x $y -outline black -width 2 \
        -tags "rubbershape"
}

proc canvas_shape_drag {win x y} {
    set coords [$win coords "rubbershape"]
    set coords [lreplace $coords 2 3 $x $y]
    eval $win coords "rubbershape" $coords
}

proc canvas_shape_end {win x y} {
    global canvInfo

    canvas_shape_drag $win $x $y

    $win itemconfigure "rubbershape" \
        -outline $canvInfo($win-penColor) \
        -fill $canvInfo($win-fillColor)

    $win dtag "rubbershape"
}

# ----------------------------------------------------------------------
# USAGE: canvas_spline_point <canvas> <x> <y>
#        canvas_spline_adjust <canvas> <x> <y>
#        canvas_spline_done <canvas> <x> <y>
#
# Used to handle the click, move, click, move, double-click actions
# when a spline is created on the canvas.  The "point" operation
# creates a new spline item if necessary, and adds a point <x>,<y>.
# The "adjust" operation stretches the end coordinate to <x>,<y>.
# The "end" operation sets the end coordinate and final colors.
# ----------------------------------------------------------------------
proc canvas_spline_point {win x y} {
    if {[$win find withtag "rubbershape"] == ""} {
        $win create line \
            $x $y $x $y -smooth 1 -fill black \
            -width 2 -tags "rubbershape"
    } else {
        set coords [$win coords "rubbershape"]
        lappend coords $x $y
        eval $win coords "rubbershape" $coords
    }
}

proc canvas_spline_adjust {win x y} {
    if {[$win find withtag "rubbershape"] != ""} {
        set coords [$win coords "rubbershape"]
        set lastx [expr [llength $coords]-2]
        set coords [lreplace $coords $lastx end $x $y]

        eval $win coords "rubbershape" $coords
    }
}

proc canvas_spline_done {win} {
    global canvInfo

    if {[$win find withtag "rubbershape"] != ""} {
        if {$canvInfo($win-fillColor) != ""} {
            set coords [$win coords "rubbershape"]
            eval lappend coords [lrange $coords 0 1]

            $win delete "rubbershape"
            eval $win create polygon $coords \
                -smooth 1 -width 2 \
                -outline $canvInfo($win-penColor) \
                -fill $canvInfo($win-fillColor)
        } else {
            $win itemconfigure "rubbershape" \
                -fill $canvInfo($win-penColor)

            $win dtag "rubbershape"
        }
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_text_select <canvas> <x> <y>
#
# Invoked when you click on a canvas with text bindings.  Looks
# for a text item at the click point, and if it exists, sets up
# focus for text editing.
# ----------------------------------------------------------------------
proc canvas_text_select {win x y} {
    global canvInfo

    canvas_text_done $win

    if {[$win type current] == "text"} {
        $win addtag "editText" withtag current
    } else {
        $win create text $x $y \
            -fill $canvInfo($win-penColor) \
            -anchor w -justify left -tags "editText"
    }

    focus $win
    $win focus "editText"
    $win icursor "editText" @$x,$y
}

# ----------------------------------------------------------------------
# USAGE: canvas_text_edit_add <canvas> <str>
#
# Invoked when you have selected some text and are entering
# characters.  Adds the <str> string to the text being edited.
# ----------------------------------------------------------------------
proc canvas_text_edit_add {win str} {
    $win insert "editText" insert $str
}

# ----------------------------------------------------------------------
# USAGE: canvas_text_edit_backsp <canvas>
#
# Invoked when you have selected some text and you hit the backspace
# or delete key.  Deletes the character to the left of the cursor
# and moves the cursor back.
# ----------------------------------------------------------------------
proc canvas_text_edit_backsp {win} {
    set pos [expr [$win index "editText" insert] - 1]
    if {$pos >= 0} {
        $win dchars "editText" $pos
    }
}

# ----------------------------------------------------------------------
# USAGE: canvas_text_done <canvas>
#
# Invoked when you are done editing one bit of text, and you start
# editing another or you switch modes somehow.  If the current
# text item is empty, it is automatically deleted.  Also, focus
# is reset so that the text can no longer be edited.
# ----------------------------------------------------------------------
proc canvas_text_done {win} {
    set mesg [$win itemcget "editText" -text]
    if {[string length [string trim $mesg]] == 0} {
        $win delete "editText"
    }

    $win dtag "editText"
    $win focus ""
}

# ----------------------------------------------------------------------
# USAGE: canvas_save <canvas>
#
# Scans through the given <canvas> and produces a script that
# captures its contents.  Any items tagged with the name
# "canvas_save_ignore" are not returned in the script.  The
# script may be saved in a file, then later loaded and given
# to canvas_load to reproduce the original canvas.
# ----------------------------------------------------------------------
proc canvas_save {win} {
    set script "# contents of $win\n"
    foreach item [$win find all] {
        set tags [$win gettags $item]
        if {[lsearch $tags "canvas_save_ignore"] < 0} {
            set type   [$win type $item]
            set coords [$win coords $item]

            set opts ""
            foreach desc [$win itemconfigure $item] {
                set name [lindex $desc 0]
                set init [lindex $desc 3]
                set val  [lindex $desc 4]
                if {$val != $init} {
                    lappend opts $name $val
                }
            }
            append script "draw $type $coords $opts\n"
        }
    }
    return $script
}

# ----------------------------------------------------------------------
# USAGE: canvas_load <canvas> <script>
#
# Used to load a drawing produced by canvas_save.  The <script>
# string may contain commands like "draw rectangle ...", and the
# items will be created on the <canvas>.  If <script> contains
# anything unsafe like "exec rm *", it is flagged as an error.
# ----------------------------------------------------------------------
set canvParser [interp create -safe]

proc canvas_load {win script} {
    global canvParser
    $win delete all
    $canvParser alias draw canvas_parser_cmd $win
    $canvParser eval $script
}

proc canvas_parser_cmd {win args} {
    eval $win create $args
}
