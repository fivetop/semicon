# ----------------------------------------------------------------------
#  DEMO: canvas animation using "after" command
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

pack [canvas .c -width 200 -height 140 -background white]

.c create rectangle 10 10 20 130 -fill black
.c create rectangle 180 10 190 130 -fill black

proc new_ball {xpos ypos speed color} {
    set x0 [expr $xpos-10]
    set x1 [expr $xpos+10]
    set y1 [expr $ypos+20]
    .c create oval $x0 $ypos $x1 $y1 \
        -fill $color -tag "ball-$ypos"
    bounce $xpos $ypos $speed
}

proc bounce {xpos ypos speed} {
    .c move "ball-$ypos" $speed 0
    set xpos [expr $xpos+$speed]
    if {$speed > 0 && $xpos >= 170} {
        set speed [expr -$speed]
        .c create text 175 [expr $ypos-5] -text "Boing!" \
            -anchor se -tag "boing-$ypos"
        after 300 [list .c delete boing-$ypos]
    } elseif {$speed < 0 && $xpos <= 30} {
        set speed [expr -$speed]
        .c create text 25 [expr $ypos-5] -text "Boing!" \
            -anchor sw -tag "boing-$ypos"
        after 300 [list .c delete boing-$ypos]
    }
    after 50 [list bounce $xpos $ypos $speed]
}

new_ball 100 60 5 red
