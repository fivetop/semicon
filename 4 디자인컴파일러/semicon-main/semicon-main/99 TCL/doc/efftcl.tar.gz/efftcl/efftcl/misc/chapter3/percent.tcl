# ----------------------------------------------------------------------
#  EXAMPLE: percent substitutions in the bind command
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

canvas .c -background white
pack .c

array set colors {1 red 2 green 3 blue}
bind .c <ButtonPress> {
    .c create text %x %y -text "click!" -fill $colors(%b)
}
