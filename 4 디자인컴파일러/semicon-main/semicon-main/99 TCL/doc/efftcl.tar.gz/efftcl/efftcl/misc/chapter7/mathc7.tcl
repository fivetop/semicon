# ----------------------------------------------------------------------
#  DEMO: math client program 7 -- using sockets
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Entry.width 7 startupFile
option add *Entry.background white startupFile
option add *Entry.justify center startupFile

entry .x
pack .x -side left
frame .op
pack .op -side left
button .op.add -text "+" -command do_add
pack .op.add -fill both
button .op.sub -text "-" -command do_subtract
pack .op.sub -fill both
entry .y
pack .y -side left
label .result -text ""
pack .result -side left

proc do_add {} {
    set x [.x get]
    set y [.y get]
    client_send add $x $y {show_result %v}
}

proc do_subtract {} {
    set x [.x get]
    set y [.y get]
    client_send subtract $x $y {show_result %v}
}

proc cmd_show_result {num} {
    .result configure -text "= $num"
}

proc cmd_error_result {msg} {
    notice_show $msg error
}

set parser [interp create -safe]
$parser alias show_result cmd_show_result
$parser alias error_result cmd_error_result

proc client_handle {sid} {
    global backend parser buffer

    if {[gets $sid request] < 0} {
        catch {close $sid}
        set backend ""
        notice_show "Lost connection to server" error
    } else {
        append buffer $request "\n"
        if {[info complete $buffer]} {
            set request $buffer
            set buffer ""
            if {[catch {$parser eval $request} result] != 0} {
                notice_show $result error
            }
        }
    }
}

proc client_send {args} {
    global backend
    if {$backend != ""} {
        puts $backend $args
    }
}

set sid [socket localhost 9001]
fileevent $sid readable "client_handle $sid"
fconfigure $sid -buffering line
set backend $sid
