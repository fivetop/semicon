# ----------------------------------------------------------------------
#  DEMO: simple confirmation dialog
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

rename exit tcl_exit
proc exit {{status 0}} {
    if {[confirm_ask "Do you really want to quit?"]} {
        tcl_exit $status
    }
}

button .quit -text "Quit" -command exit
pack .quit
