# ----------------------------------------------------------------------
#  DEMO: match the best font with font_best
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

set fancyFont [font_best "AvantGarde Bk BT" Geneva Helvetica \
    -size 24 -weight bold -slant italic]

button .b -text "Hello, World!" -font $fancyFont
pack .b
