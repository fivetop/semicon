# ----------------------------------------------------------------------
#  EXAMPLE: hierarchical list viewer
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Hierlist.activeColor gray widgetDefault
option add *Hierlist.indent 15 widgetDefault
option add *Hierlist.hbox.background white widgetDefault
option add *Hierlist.hbox.width 40 widgetDefault
option add *Hierlist.hbox.height 10 widgetDefault
option add *Hierlist.hbox.cursor center_ptr widgetDefault
option add *Hierlist.hbox.font \
    -*-lucida-medium-r-normal-sans-*-120-* widgetDefault

set hierInfo(sideArrow) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images side.gif]]

set hierInfo(downArrow) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images down.gif]]

proc hierlist_create {win} {
    frame $win -class Hierlist
    scrollbar $win.sbar -command "$win.hbox yview"
    pack $win.sbar -side right -fill y
    text $win.hbox -wrap none -takefocus 0 \
        -yscrollcommand "$win.sbar set"
    pack $win.hbox -side left -expand yes -fill both

    set tabsize [option get $win indent Indent]
    set tabsize [winfo pixels $win $tabsize]
    set tabs "15"
    for {set i 1} {$i < 20} {incr i} {
        lappend tabs [expr $i*$tabsize+15]
    }
    $win.hbox configure -tabs $tabs

    set btags [bindtags $win.hbox]
    set i [lsearch $btags Text]
    if {$i >= 0} {
        set btags [lreplace $btags $i $i]
    }
    bindtags $win.hbox $btags

    bind $win <Destroy> "hierlist_destroy $win"
    return $win
}

proc hierlist_destroy {win} {
    global hierInfo

    if {[info exists hierInfo($win-data)]} {
        set var $hierInfo($win-data)
        upvar #0 $var data
        unset data
        unset hierInfo($win-data)
    }
}

proc hierlist_display {win info} {
    hierlist_data $win $info

    $win.hbox delete 1.0 end
    $win.hbox mark set "root:start" 1.0
    $win.hbox mark gravity "root:start" left
    hierlist_insert $win "root"
}

proc hierlist_insert {win node} {
    global hierInfo

    set var $hierInfo($win-data)
    upvar #0 $var data

    set indent ""
    foreach digit [split $node "-"] {
        append indent "\t"
    }

    set activebg [option get $win activeColor Color]
    $win.hbox mark set pos "$node:start"

    foreach subnode $data($node-children) {
        if {$data($subnode-children) != ""} {
            set arrow "$win.hbox.arrow-$subnode"
            label $arrow -image $hierInfo(sideArrow) \
                -borderwidth 0
            bind $arrow <ButtonPress-1> \
                "hierlist_expand $win $subnode"
            $win.hbox window create pos -window $arrow
        }
        $win.hbox insert pos \
            "$indent$data($subnode-label)\n" $subnode

        $win.hbox tag bind $subnode <Enter> \
            "$win.hbox tag configure $subnode -background $activebg"

        $win.hbox tag bind $subnode <Leave> \
            "$win.hbox tag configure $subnode -background {}"

        $win.hbox mark set "$subnode:start" pos
        $win.hbox mark gravity "$subnode:start" left
    }
    $win.hbox mark set "$node:end" pos
}

proc hierlist_expand {win node} {
    global hierInfo

    set arrow "$win.hbox.arrow-$node"
    set image [$arrow cget -image]

    if {$image == $hierInfo(sideArrow)} {
        $arrow configure -image $hierInfo(downArrow)
        bind $arrow <ButtonPress-1> \
            "hierlist_collapse $win $node"

        hierlist_insert $win $node
    }
}

proc hierlist_collapse {win node} {
    global hierInfo

    set arrow "$win.hbox.arrow-$node"
    set image [$arrow cget -image]

    if {$image == $hierInfo(downArrow)} {
        $arrow configure -image $hierInfo(sideArrow)
        bind $arrow <ButtonPress-1> \
            "hierlist_expand $win $node"

        $win.hbox delete "$node:start" "$node:end"
    }
}

proc hierlist_data {win info} {
    global hierInfo

    if {[info exists hierInfo($win-data)]} {
        set var $hierInfo($win-data)
        upvar #0 $var data
        unset data
    } else {
        set counter 0
        while {1} {
            set var "hierData#[incr counter]"
            upvar #0 $var data
            if {![info exists data]} {
                break
            }
        }
        set hierInfo($win-data) $var
    }

    hierlist_data_add $var root "" $info
}

proc hierlist_data_add {var node label info} {
    upvar #0 $var data

    set data($node-label) $label
    set data($node-children) ""

    set num 0
    foreach rec $info {
        set subnode "$node-[incr num]"
        lappend data($node-children) $subnode

        set sublabel [lindex $rec 0]
        set subinfo [lindex $rec 1]

        hierlist_data_add $var $subnode $sublabel $subinfo
    }
}
