# ----------------------------------------------------------------------
#  DEMO: output to stdout is buffered by line
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set fid [open "| cat" "w"]

while {1} {
    puts $fid "This is a line of text which might be buffered"
    after 1000
}
