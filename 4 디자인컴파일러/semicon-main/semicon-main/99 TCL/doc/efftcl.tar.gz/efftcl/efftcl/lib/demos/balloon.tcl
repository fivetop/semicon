# ----------------------------------------------------------------------
#  DEMO: use "wm" commands to manage a balloon help window
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

label .title -text "Balloon help controls:"
pack .title -pady 4
balloonhelp_for .title "Label for balloon help controls"

button .on -text "On" -command {balloonhelp_control 1}
pack .on -fill x
balloonhelp_for .on "Turns on balloon help"

button .off -text "Off" -command {balloonhelp_control 0}
pack .off -fill x
balloonhelp_for .off "Turns off balloon help"
