# ----------------------------------------------------------------------
#  EXAMPLE: inserting text into a text widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7
pack .t

.t insert end {Emergency Instructions
In case of a nuclear meltdown, engage
the Emergency Core Coolant System (ECCS)
and rotate the Flow Control knob fully
clockwise.}
