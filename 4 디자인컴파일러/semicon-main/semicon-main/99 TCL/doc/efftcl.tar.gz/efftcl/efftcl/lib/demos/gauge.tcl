# ----------------------------------------------------------------------
#  DEMO: simple progress gauge
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

gauge_create .g PaleGreen
pack .g -expand yes -fill both -padx 10 -pady 10

button .go -text "Go" -command {
    for {set i 0} {$i <= 100} {incr i} {
        after 100
        gauge_value .g $i
    }
}
pack .go
