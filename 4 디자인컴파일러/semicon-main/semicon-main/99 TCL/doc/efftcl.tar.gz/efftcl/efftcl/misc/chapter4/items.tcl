#!/bin/sh
# ----------------------------------------------------------------------
#  EXAMPLE: example of all the items on a canvas
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"
# ----------------------------------------------------------------------
package require Efftcl

option add *background white
option add *highlightBackground white
option add *Canvas*background LightGray
option add *Canvas*e.background gray
option add *Canvas*e.highlightBackground gray
option add *Label.font -*-courier-bold-r-normal--12-120-*

wm title . "canvas"
. configure -background white

proc canvas_items {name code} {
    set counter 0
    while {1} {
        set win ".item[incr counter]"
        if {![winfo exists $win]} {
            break
        }
    }
    frame $win
    pack $win -fill x -padx 4 -pady 2
    canvas $win.canv -width 52 -height 52 -highlightthickness 0
    pack $win.canv -side left
    regsub -all {%W} $code .c mesg
    set mesg [string trim $mesg]
    label $win.code -anchor w -justify left -text $mesg
    pack $win.code -side left

    regsub -all {%W} $code $win.canv cmd
    eval $cmd
}

canvas_items lines {
%W create line 0 15 15 25 35  5 50 15 -width 2 -fill blue
%W create line 0 30 15 40 35 20 50 30 -arrow both
%W create line 0 45 15 55 35 35 50 45 -smooth yes -fill red
}

canvas_items rectangles {
%W create rectangle  5 10 35 35 -width 4
%W create rectangle 15 20 45 45 -fill red -stipple gray50
}

canvas_items polygons "
%W create polygon 5 5 30 20 45 10 \\
    40 45 20 35 10 40 -fill green
"

canvas_items ovals {
%W create oval 10 10 30 30 -fill blue
%W create oval 15 15 45 45 -outline green -width 3
}

canvas_items arcs "
%W create arc 10 10 30 30 -extent 240 -fill blue
%W create arc 15 15 45 45 -start 45 -extent -180 \\
    -style arc -width 3 -outline green
"

canvas_items bitmaps "
%W create bitmap 25 25 -anchor se -bitmap questhead
%W create bitmap 25 25 -anchor nw -bitmap error \\
    -background red -foreground white
"

cd [file join $env(EFFTCL_LIBRARY) images]
canvas_items images {
set imh [image create photo -file boom.gif]
%W create image 25 25 -anchor c -image $imh
}

canvas_items text "
%W create text 30 25 -anchor se -text \"Hello\"
%W create text 30 25 -anchor n -text \"World!\" \\
    -font -*-times-medium-i-normal--14-140-*
"

canvas_items window {
%W create oval 5 5 45 45 -fill blue
entry %W.e -width 5
%W create window 25 25 -anchor c -window %W.e
}
