# ----------------------------------------------------------------------
#  EXAMPLE: use "list" to protect file names
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Text.background white startupFile

. configure -menu .mbar
menu .mbar

.mbar add cascade -label "File" -menu .mbar.file
menu .mbar.file
.mbar.file add command -label "Open..." -command {
    set file [tk_getOpenFile]
    if {$file != ""} {
        open_doc $file
        add_doc $file
    }
}
.mbar.file add command -label "Save As..."
.mbar.file add command -label "Print..."

.mbar.file add separator
.mbar.file add separator
.mbar.file add command -label "Exit" -command exit

text .text -yscrollcommand {.sbar set}
pack .text -side left -expand yes -fill both
scrollbar .sbar -orient vertical -command {.text yview}
pack .sbar -side right -fill y

# ----------------------------------------------------------------------
# Add document list to "File" menu
# ----------------------------------------------------------------------
proc open_doc {file} {
    set fid [open $file r]
    set contents [read $fid]
    close $fid

    .text delete 1.0 end
    .text insert 1.0 $contents
}

proc add_doc {file} {
    set name [file tail $file]
    if {[catch {.mbar.file index $name}] != 0} {
        set pos [expr [.mbar.file index "Print..."]+2]
        .mbar.file insert $pos command -label $name \
            -command [list open_doc $file]
    }
}
