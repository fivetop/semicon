# ----------------------------------------------------------------------
#  EXAMPLE: bind debugging routines
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
# USAGE: bind_show <thing> ?-verbose?
#
# Displays all of the bindings for a particular widget.
# ----------------------------------------------------------------------
proc bind_show {w {mode "-quiet"}} {
    puts "$w"
    foreach tag [bindtags $w] {
        puts "\t$tag"
        foreach spec [bind $tag] {
            puts "\t\t$spec"
            if {$mode == "-verbose"} {
                set cmd [bind $tag $spec]
                set cmd [string trim $cmd "\n"]
                regsub -all "\n" $cmd "\n\t\t\t" cmd
                puts "\t\t\t$cmd"
            }
        }
    }
}

# ----------------------------------------------------------------------
# USAGE: bind_debug <win> <state>
#
# Turns bind debugging on or off for a particular window <win>.
# ----------------------------------------------------------------------
proc bind_debug {w on} {
    set events {
        {ButtonPress    {W=%W #=%# x=%x y=%y b=%b s=%s }}
        {ButtonRelease  {W=%W #=%# x=%x y=%y b=%b s=%s }}
        {Circulate      {W=%W #=%# x=%x y=%y p=%p }}
        {Colormap       {W=%W #=%# x=%x y=%y }}
        {Configure      {W=%W #=%# x=%x y=%y a=%a o=%o h=%h w=%w B=%B }}
        {Destroy        {W=%W #=%# x=%x y=%y }}
        {Enter          {W=%W #=%# x=%x y=%y d=%d f=%f h=%h m=%m s=%s }}
        {Expose         {W=%W #=%# x=%x y=%y c=%c h=%h w=%w }}
        {FocusIn        {W=%W #=%# x=%x y=%y d=%d m=%m }}
        {FocusOut       {W=%W #=%# x=%x y=%y d=%d m=%m }}
        {Gravity        {W=%W #=%# x=%x y=%y }}
        {KeyPress       {W=%W #=%# x=%x y=%y k=%k s=%s A=%A K=%K N=%N }}
        {KeyRelease     {W=%W #=%# x=%x y=%y k=%k s=%s A=%A K=%K N=%N }}
        {Leave          {W=%W #=%# x=%x y=%y d=%d f=%f m=%m s=%s }}
        {Map            {W=%W #=%# x=%x y=%y o=%o }}
        {Motion         {W=%W #=%# x=%x y=%y s=%s }}
        {Property       {W=%W #=%# x=%x y=%y }}
        {Reparent       {W=%W #=%# x=%x y=%y o=%o }}
        {Unmap          {W=%W #=%# x=%x y=%y }}
        {Visibility     {W=%W #=%# x=%x y=%y s=%s }}
    }

    foreach e $events {
        set type [lindex $e 0]
        set fmt [lindex $e 1]
        bind BindDebugger <$type> "puts \"<$type> $fmt\""
    }

    set allwin [bind_debug_allwindows $w]
    foreach w $allwin {
        set tags [bindtags $w]
        set i [lsearch $tags BindDebugger]
        if {$on} {
            if {$i < 0} {
                set tags [linsert $tags 0 BindDebugger]
                bindtags $w $tags
            }
        } else {
            if {$i >= 0} {
                set tags [lreplace $tags $i $i]
                bindtags $w $tags
            }
        }
    }
}

# ----------------------------------------------------------------------
# USAGE: bind_debug_allwindows <win>
#
# Returns a list containing an entire tree of windows starting with
# the window <win>.
# ----------------------------------------------------------------------
proc bind_debug_allwindows {w} {
    set list $w
    foreach i [winfo children $w] {
        eval lappend list [bind_debug_allwindows $i]
    }
    return $list
}
