#!/bin/sh
# ----------------------------------------------------------------------
#  EXAMPLE: changing tag characteristics on the fly
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

text .t -width 40 -height 7 -background white \
    -font -*-helvetica-medium-r-normal--*-120-*
pack .t

.t tag configure "heading" -spacing1 0.1i -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "body" -lmargin1 0.2i

.t tag configure "emphasis" -foreground red \
    -underline yes

proc heading {mesg} {
    .t insert end $mesg "heading"
}
proc body {mesg} {
    .t insert end $mesg "body"
}
proc emphasis {mesg} {
    .t insert end $mesg "body emphasis"
}

heading "Emergency Instructions\n"
body "In case of a nuclear meltdown, engage\nthe "
emphasis "Emergency Core Coolant System"
body " (ECCS)\nand rotate the "
emphasis "Flow Control"
body " knob fully\nclockwise."

animate_start 500 {red white} {
    .t tag configure "emphasis" -foreground %v
}
