# ----------------------------------------------------------------------
#  EXAMPLE: message box
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
set response [tk_messageBox -type yesno -title "InstallMagik" \
    -icon question -message "File exists.  Overwrite?"]

if {$response} {
    tk_messageBox -icon info -message "Installation Complete."
} else {
    tk_messageBox -icon error -message "Installation Aborted."
}
