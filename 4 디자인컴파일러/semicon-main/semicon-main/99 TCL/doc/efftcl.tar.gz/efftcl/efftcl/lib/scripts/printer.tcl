# ----------------------------------------------------------------------
#  EXAMPLE: simple printer dialog
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

proc printer_create {top} {
    global prInfo

    set top [dialog_create Printer $top]

    set info [dialog_info $top]
    radiobutton $info.printer \
        -text "Send to printer with command: " \
        -variable prInfo($top-where) -value "printer"
    entry $info.printerCmd
    radiobutton $info.file \
        -text "Save output in file: " \
        -variable prInfo($top-where) -value "file"
    entry $info.fileName

    grid $info.printer    -row 0 -sticky w
    grid $info.printerCmd -row 1 -sticky ew
    grid rowconfigure $info 2 -minsize 6
    grid $info.file       -row 3 -sticky w
    grid $info.fileName   -row 4 -sticky ew

    $info.printerCmd insert 0 "lpr"
    $info.fileName insert 0 "output.txt"
    $info.printer invoke

    bind $info.printerCmd <FocusIn> "$info.printer invoke"
    bind $info.fileName <FocusIn> "$info.file invoke"

    set cntls [dialog_controls $top]
    button $cntls.ok -command "set prInfo($top-status) 1"
    pack $cntls.ok -side left -expand yes
    focus $cntls.ok

    button $cntls.cancel -command "set prInfo($top-status) 0"
    pack $cntls.cancel -side left -expand yes

    wm protocol $top WM_DELETE_WINDOW "$cntls.cancel invoke"
    wm withdraw $top

    return $top
}

proc printer_print {top cmd {ok "Print"} {cancel "Cancel"}} {
    global prInfo

    set cntls [dialog_controls $top]
    $cntls.ok configure -text $ok
    $cntls.cancel configure -text $cancel

    dialog_wait $top prInfo($top-status)

    if {$prInfo($top-status)} {
        switch $prInfo($top-where) {
            printer {
                set info [dialog_info $top]

                set print [format {
                    exec %s << [%s]
                } [$info.printerCmd get] $cmd]

                if {[catch $print result] != 0} {
                    notice_show $result error
                } elseif {[string trim $result] != ""} {
                    notice_show $result info
                } else {
                    notice_show "Document printed" info
                }
            }
            file {
                set info [dialog_info $top]
                set fname [$info.fileName get]

                set print [format {
                    set fid [open %s w]
                    puts -nonewline $fid [%s]
                    close $fid
                } $fname $cmd]

                if {[catch $print result] != 0} {
                    notice_show $result error
                } else {
                    notice_show "Output saved in file \"$fname\"" info
                }
            }
        }
    }
}
