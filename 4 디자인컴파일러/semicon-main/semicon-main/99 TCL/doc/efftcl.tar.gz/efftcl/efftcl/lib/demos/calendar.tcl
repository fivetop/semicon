# ----------------------------------------------------------------------
#  DEMO: calendar widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

image create photo flag \
    -file [file join $env(EFFTCL_LIBRARY) images flag.gif]

calendar_create .cal
calendar_decorate_with .cal flags
calendar_select_cmd .cal {set flags(%d) flag}

pack .cal -expand yes -fill both
