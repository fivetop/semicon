/*
 * ----------------------------------------------------------------------
 *  DEMO: standard I/O library in C does smart buffering
 * ----------------------------------------------------------------------
 *  Effective Tcl/Tk Programming
 *    Mark Harrison, AsiaInfo Software Research and Development
 *    Michael McLennan, Bell Labs Innovations for Lucent Technologies
 *    Addison-Wesley Professional Computing Series
 * ======================================================================
 *  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
 * ======================================================================
 */

#include <stdio.h>

main() {
    while (1) {
        printf("This is a line of text which might be buffered\n");
        sleep(1);
    }
}
