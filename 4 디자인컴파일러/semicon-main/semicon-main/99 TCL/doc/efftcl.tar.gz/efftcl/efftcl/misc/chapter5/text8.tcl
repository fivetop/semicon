# ----------------------------------------------------------------------
#  EXAMPLE: binding actions to tags
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7 \
    -background white -cursor left_ptr \
    -font -*-helvetica-medium-r-normal--*-120-*
pack .t

bind .t <ButtonPress> break

.t tag configure "heading" -spacing1 0.1i -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "body" -lmargin1 0.2i

proc heading {mesg} {
    .t insert end $mesg heading
}
proc body {mesg} {
    .t insert end $mesg body
}

set linkNum 0
proc link {mesg linkCode} {
    global linkNum
    set tag "link[incr linkNum]"
    .t insert end $mesg [list body $tag]
    .t tag configure $tag -foreground red -underline 1

    .t tag bind $tag <Enter> \
        ".t tag configure $tag -foreground blue"

    .t tag bind $tag <Leave> \
        ".t tag configure $tag -foreground red"

    .t tag bind $tag <ButtonPress> \
        ".t delete 1.0 end; $linkCode"
}

proc show_main {} {
    heading "Emergency Instructions\n"
    body "In case of a nuclear meltdown, engage\nthe "
    link "ECCS" show_eccs
    body " and rotate the "
    link "Flow Control" show_flow
    body " knob\nfully clockwise."
}

proc show_eccs {} {
    heading "Emergency Core Coolant System\n"
    body "This system protects the reactor core\n"
    body "in case the temperature approaches meltdown.\n"
    link "<< Back" show_main
}


proc show_flow {} {
    heading "Flow Control\n"
    body "This red knob near the bottom of the ECCS\n"
    body "panel regulates the flow of coolant to the\n"
    body "reactor.  Turn clockwise to increase the flow.\n"
    link "<< Back" show_main
}

show_main
