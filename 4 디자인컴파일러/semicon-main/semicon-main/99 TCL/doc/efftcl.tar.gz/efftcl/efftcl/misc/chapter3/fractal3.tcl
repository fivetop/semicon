#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: using "busy_eval" during long calculations
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

proc fractal_draw {color maxiters size} {
    global fractal

    fractal_cmap cmap $color $maxiters

    set fractal(width) $size
    set fractal(height) $size
    $fractal(image) configure -width $size -height $size

    set dr [expr $fractal(x1)-$fractal(x0)]
    set di [expr $fractal(y1)-$fractal(y0)]

    $fractal(image) blank
    for {set x 0} {$x < $size} {incr x} {
        set cr [expr double($x*$dr)/$size+$fractal(x0)]
        for {set y 0} {$y < $size} {incr y} {
            set ci [expr double($y*$di)/$size+$fractal(y0)]

            set zr 0.0; set zi 0.0
            for {set iter 0} {$iter < $maxiters} {incr iter} {
                set rsq [expr $zr*$zr]
                set isq [expr $zi*$zi]
                set zi [expr 2*$zr*$zi + $ci]
                set zr [expr $rsq - $isq + $cr]
                if {$rsq + $isq >= 4.0} {
                    break
                }
            }
            $fractal(image) put $cmap($iter) -to $x $y
        }
        update
    }
}

proc fractal_cmap {var color maxiters} {
    upvar $var cmap

    foreach {r0 g0 b0} [winfo rgb . $color] {}
    foreach {r1 g1 b1} [winfo rgb . white] {}

    for {set i 0} {$i <= $maxiters} {incr i} {
        set r [expr round($i*double($r1-$r0)/$maxiters + $r0)]
        set g [expr round($i*double($g1-$g0)/$maxiters + $g0)]
        set b [expr round($i*double($b1-$b0)/$maxiters + $b0)]
        set cmap($i) [format "#%.4x%.4x%.4x" $r $g $b]
    }
    set cmap($maxiters) #000000
}

proc fractal_box {win x y} {
    global fractal
    set x0 [expr $x-$fractal(width)/4]
    set x1 [expr $x+$fractal(width)/4]
    set y0 [expr $y-$fractal(height)/4]
    set y1 [expr $y+$fractal(height)/4]
    $win delete zoombox
    $win create rectangle $x0 $y0 $x1 $y1 -outline white -tags zoombox
}
proc fractal_zoom {win x y} {
    global fractal

    fractal_box $win $x $y
    foreach {zx0 zy0 zx1 zy1} [$win coords zoombox] {}
    set dx [expr $fractal(x1)-$fractal(x0)]
    set dy [expr $fractal(y1)-$fractal(y0)]
    set x0 [expr $zx0*double($dx)/$fractal(width)  + $fractal(x0)]
    set y0 [expr $zy0*double($dy)/$fractal(height) + $fractal(y0)]
    set x1 [expr $zx1*double($dx)/$fractal(width)  + $fractal(x0)]
    set y1 [expr $zy1*double($dy)/$fractal(height) + $fractal(y0)]
    set fractal(x0) $x0
    set fractal(x1) $x1
    set fractal(y0) $y0
    set fractal(y1) $y1
    $win delete zoombox
    after idle {.compute invoke}
}

set fractal(image) [image create photo]
set fractal(x0) -2
set fractal(x1) 1
set fractal(y0) -1.5
set fractal(y1) 1.5

canvas .display
pack .display -padx 4 -pady 4

.display create image 0 0 -anchor nw -image $fractal(image)

bind .display <Enter> {
    fractal_box %W %x %y
}
bind .display <Motion> {
    fractal_box %W %x %y
}
bind .display <Leave> {
    %W delete zoombox
}
bind .display <ButtonPress-1> {
    fractal_zoom %W %x %y
}

frame .controls
pack .controls -fill x -padx 8 -pady 4
scale .controls.size -orient horizontal -showvalue off \
    -from 10 -to 200
label .controls.sizesm -text "small"
label .controls.sizelg -text "large"
label .controls.quall -text "Quality:"
scale .controls.qual -orient horizontal -showvalue off \
    -from 10 -to 200
label .controls.quallo -text "low"
label .controls.qualhi -text "high"

catch {.controls.sizesm configure -font -*-helvetica-medium-r-normal--*-100-*}
catch {.controls.sizelg configure -font -*-helvetica-medium-r-normal--*-100-*}
catch {.controls.quallo configure -font -*-helvetica-medium-r-normal--*-100-*}
catch {.controls.qualhi configure -font -*-helvetica-medium-r-normal--*-100-*}

label .controls.colorl -text "Color:"
button .controls.color -command {
    set color [.controls.color cget -background]
    set color [tk_chooseColor -initialcolor $color]
    if {$color != ""} {
        .controls.color configure \
            -background $color -activebackground $color
    }
}
label .controls.sizel -text "Size:"

grid .controls.quall .controls.quallo .controls.qual .controls.qualhi -sticky ew
grid .controls.sizel .controls.sizesm .controls.size .controls.sizelg -sticky ew
grid .controls.colorl .controls.color -sticky ew
grid configure .controls.color -columnspan 3
grid configure .controls.quall .controls.sizel .controls.colorl -sticky e
grid configure .controls.quallo .controls.sizesm -sticky e
grid configure .controls.qualhi .controls.sizelg -sticky w
grid columnconfigure .controls 2 -weight 1

button .compute -text "Compute" -command {
    set size [.controls.size get]
    .display configure -width $size -height $size
    set color [.controls.color cget -background]
    set maxiters [.controls.qual get]

    busy_eval {
        fractal_draw $color $maxiters $size
    }
}
pack .compute -padx 4 -pady 4

.controls.qual set 10
.controls.size set 50
.controls.color configure -background blue -activebackground blue
.compute invoke
