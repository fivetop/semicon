# ----------------------------------------------------------------------
#  DEMO: simple toolbar with mutually-exclusive tools
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

toolbar_create .tbar top {
    .show configure -text "MODE:\n%t"
}
pack .tbar -side left -fill y -padx 4 -pady 4

label .show -width 20 -background white
pack .show -side right -expand yes -fill both -padx 4 -pady 4

toolbar_add .tbar select [image create bitmap \
    -file [file join $env(EFFTCL_LIBRARY) images select.xbm]]

toolbar_add .tbar rect [image create bitmap \
    -file [file join $env(EFFTCL_LIBRARY) images rect.xbm]]

toolbar_add .tbar oval [image create bitmap \
    -file [file join $env(EFFTCL_LIBRARY) images oval.xbm]]

toolbar_add .tbar spline [image create bitmap \
    -file [file join $env(EFFTCL_LIBRARY) images spline.xbm]]
