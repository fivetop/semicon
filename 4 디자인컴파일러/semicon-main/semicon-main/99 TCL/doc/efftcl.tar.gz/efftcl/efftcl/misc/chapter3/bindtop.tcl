# ----------------------------------------------------------------------
# EXAMPLE: binding to a toplevel widget can be problematic
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
option add *Entry.background white startupFile

frame .mbar -borderwidth 2 -relief raised
pack .mbar -fill x
menubutton .mbar.file -text "File"
pack .mbar.file -side left
menubutton .mbar.edit -text "Edit"
pack .mbar.edit -side left
menubutton .mbar.view -text "View"
pack .mbar.view -side left

canvas .display -width 3i -height 3i -background black
pack .display -expand yes -fill both

frame .sep -height 2 -borderwidth 1 -relief sunken
pack .sep -fill x -pady 8

frame .info
pack .info -fill x
label .info.namel -text "Name:"
entry .info.name
.info.name insert 0 "Schematic 17a"
label .info.commentl -text "Comments:"
entry .info.comment
.info.comment insert 0 "Interior cross-section"
label .info.datel -text "Date:"
entry .info.date
.info.date insert 0 "5/19/81"

grid .info.namel .info.name -sticky e
grid .info.commentl .info.comment -sticky e
grid .info.datel .info.date -sticky e
grid columnconfigure .info 1 -weight 1
grid .info.name .info.comment .info.date -sticky ew

bind . <Configure> {
    puts "resizing %W"
    resize_drawing .display
}

# ----------------------------------------------------------------------
# Load up a drawing...
# ----------------------------------------------------------------------
proc resize_drawing {win} {
    $win delete all
    $win create line 98.0 298.0 98.0 83.0 -fill green -width 2
    $win create line 98.0 83.0 101.0 69.0 -fill green -width 2
    $win create line 101.0 69.0 108.0 56.0 -fill green -width 2
    $win create line 108.0 56.0 116.0 47.0 -fill green -width 2
    $win create line 116.0 47.0 124.0 41.0 -fill green -width 2
    $win create line 124.0 41.0 137.0 35.0 -fill green -width 2
    $win create line 137.0 35.0 152.0 33.0 -fill green -width 2
    $win create line 152.0 33.0 166.0 36.0 -fill green -width 2
    $win create line 166.0 36.0 177.0 41.0 -fill green -width 2
    $win create line 177.0 42.0 188.0 49.0 -fill green -width 2
    $win create line 188.0 49.0 196.0 59.0 -fill green -width 2
    $win create line 196.0 59.0 202.0 72.0 -fill green -width 2
    $win create line 202.0 72.0 204.0 83.0 -fill green -width 2
    $win create line 204.0 83.0 204.0 300.0 -fill green -width 2
    $win create line 99.0 288.0 204.0 287.0 -fill green -width 2
    $win create line 101.0 284.0 198.0 284.0 -fill green -width 2
    $win create line 102.0 284.0 102.0 152.0 -fill green -width 2
    $win create line 200.0 284.0 199.0 152.0 -fill green -width 2
    $win create line 134.0 289.0 131.0 279.0 -fill blue -width 4
    $win create line 131.0 279.0 126.0 149.0 -fill blue -width 4
    $win create line 168.0 288.0 171.0 282.0 -fill blue -width 4
    $win create line 171.0 282.0 175.0 150.0 -fill blue -width 4
    $win create line 135.0 284.0 170.0 284.0 -fill blue -width 4
    $win create line 134.0 291.0 169.0 290.0 -fill blue -width 4
    $win create line 128.0 150.0 176.0 150.0 -fill blue -width 2
    $win create line 126.0 150.0 134.0 135.0 -fill blue -width 2
    $win create line 134.0 136.0 168.0 136.0 -fill blue -width 2
    $win create line 168.0 136.0 176.0 150.0 -fill blue -width 2
    $win create line 133.0 152.0 133.0 249.0 -fill magenta
    $win create line 171.0 153.0 171.0 217.0 -fill magenta
    $win create line 140.0 152.0 140.0 280.0 -fill magenta
    $win create line 163.0 152.0 163.0 281.0 -fill magenta
    $win create line 130.0 154.0 171.0 154.0 -fill magenta
    $win create line 130.0 162.0 172.0 162.0 -fill magenta
    $win create line 130.0 170.0 172.0 170.0 -fill magenta
    $win create line 131.0 178.0 171.0 178.0 -fill magenta
    $win create line 131.0 185.0 170.0 185.0 -fill magenta
    $win create line 131.0 193.0 170.0 193.0 -fill magenta
    $win create line 132.0 202.0 170.0 202.0 -fill magenta
    $win create line 133.0 210.0 170.0 210.0 -fill magenta
    $win create line 132.0 218.0 170.0 218.0 -fill magenta
    $win create line 134.0 227.0 170.0 227.0 -fill magenta
    $win create line 135.0 234.0 170.0 234.0 -fill magenta
    $win create line 134.0 242.0 169.0 242.0 -fill magenta
    $win create line 133.0 250.0 168.0 250.0 -fill magenta
    $win create line 134.0 259.0 168.0 259.0 -fill magenta
    $win create line 133.0 267.0 169.0 267.0 -fill magenta
    $win create line 133.0 274.0 169.0 274.0 -fill magenta
    $win create line 147.0 152.0 147.0 280.0 -fill magenta -width 3
    $win create line 156.0 151.0 156.0 281.0 -fill magenta -width 3
    $win create line 149.0 93.0 153.0 93.0 -fill yellow
    $win create line 153.0 93.0 153.0 90.0 -fill yellow
    $win create line 153.0 90.0 152.0 88.0 -fill yellow
    $win create line 152.0 87.0 149.0 89.0 -fill yellow
    $win create line 149.0 89.0 149.0 93.0 -fill yellow
    $win create line 152.0 83.0 157.0 86.0 -fill yellow
    $win create line 157.0 86.0 158.0 93.0 -fill yellow
    $win create line 158.0 93.0 154.0 97.0 -fill yellow
    $win create line 153.0 97.0 149.0 97.0 -fill yellow
    $win create line 148.0 97.0 144.0 92.0 -fill yellow
    $win create line 144.0 92.0 144.0 87.0 -fill yellow
    $win create line 144.0 87.0 147.0 84.0 -fill yellow
    $win create line 147.0 84.0 152.0 83.0 -fill yellow
    $win create line 152.0 77.0 160.0 83.0 -fill yellow
    $win create line 160.0 83.0 163.0 90.0 -fill yellow
    $win create line 163.0 90.0 161.0 97.0 -fill yellow
    $win create line 161.0 97.0 154.0 102.0 -fill yellow
    $win create line 154.0 102.0 148.0 102.0 -fill yellow
    $win create line 148.0 102.0 141.0 96.0 -fill yellow
    $win create line 141.0 96.0 138.0 88.0 -fill yellow
    $win create line 138.0 88.0 141.0 83.0 -fill yellow
    $win create line 141.0 82.0 146.0 78.0 -fill yellow
    $win create line 146.0 78.0 152.0 78.0 -fill yellow
    $win create line 152.0 70.0 164.0 74.0 -fill orange -width 3
    $win create line 164.0 74.0 169.0 82.0 -fill orange -width 3
    $win create line 169.0 82.0 170.0 92.0 -fill orange -width 3
    $win create line 170.0 92.0 167.0 101.0 -fill orange -width 3
    $win create line 167.0 101.0 159.0 107.0 -fill orange -width 3
    $win create line 159.0 107.0 151.0 109.0 -fill orange -width 3
    $win create line 151.0 109.0 139.0 105.0 -fill orange -width 3
    $win create line 138.0 105.0 131.0 97.0 -fill orange -width 3
    $win create line 131.0 98.0 131.0 85.0 -fill orange -width 3
    $win create line 131.0 85.0 137.0 74.0 -fill orange -width 3
    $win create line 137.0 74.0 147.0 70.0 -fill orange -width 3
    $win create line 147.0 70.0 154.0 70.0 -fill orange -width 3
    $win create line 153.0 66.0 163.0 54.0 -fill orange -width 2
    $win create line 163.0 54.0 165.0 70.0 -fill orange -width 2
    $win create line 165.0 70.0 181.0 68.0 -fill orange -width 2
    $win create line 181.0 68.0 174.0 83.0 -fill orange -width 2
    $win create line 174.0 83.0 188.0 90.0 -fill orange -width 2
    $win create line 188.0 90.0 173.0 99.0 -fill orange -width 2
    $win create line 176.0 99.0 180.0 110.0 -fill orange -width 2
    $win create line 180.0 111.0 166.0 110.0 -fill orange -width 2
    $win create line 166.0 110.0 162.0 124.0 -fill orange -width 2
    $win create line 162.0 124.0 150.0 114.0 -fill orange -width 2
    $win create line 148.0 114.0 138.0 126.0 -fill orange -width 2
    $win create line 138.0 126.0 136.0 111.0 -fill orange -width 2
    $win create line 132.0 109.0 122.0 110.0 -fill orange -width 2
    $win create line 122.0 110.0 126.0 97.0 -fill orange -width 2
    $win create line 126.0 97.0 113.0 89.0 -fill orange -width 2
    $win create line 113.0 89.0 125.0 81.0 -fill orange -width 2
    $win create line 125.0 81.0 121.0 69.0 -fill orange -width 2
    $win create line 121.0 69.0 133.0 71.0 -fill orange -width 2
    $win create line 133.0 71.0 138.0 55.0 -fill orange -width 2
    $win create line 138.0 55.0 149.0 66.0 -fill orange -width 2
    $win create line 150.0 66.0 154.0 66.0 -fill red -width 2
    $win create line 155.0 66.0 161.0 68.0 -fill red -width 2
    $win create line 161.0 68.0 167.0 73.0 -fill red -width 2
    $win create line 167.0 73.0 173.0 79.0 -fill red -width 2
    $win create line 172.0 78.0 174.0 89.0 -fill red -width 2
    $win create line 174.0 89.0 173.0 98.0 -fill red -width 2
    $win create line 173.0 98.0 169.0 106.0 -fill red -width 2
    $win create line 169.0 106.0 162.0 112.0 -fill red -width 2
    $win create line 162.0 112.0 152.0 114.0 -fill red -width 2
    $win create line 152.0 114.0 143.0 112.0 -fill red -width 2
    $win create line 143.0 112.0 135.0 109.0 -fill red -width 2
    $win create line 135.0 109.0 128.0 101.0 -fill red -width 2
    $win create line 128.0 101.0 125.0 91.0 -fill red -width 2
    $win create line 125.0 91.0 127.0 79.0 -fill red -width 2
    $win create line 127.0 79.0 135.0 70.0 -fill red -width 2
    $win create line 135.0 70.0 142.0 67.0 -fill red -width 2
    $win create line 142.0 67.0 154.0 66.0 -fill red -width 2
    $win create line 141.0 55.0 151.0 53.0 -fill red -width 2
    $win create line 151.0 53.0 164.0 56.0 -fill red -width 2
    $win create line 164.0 56.0 172.0 62.0 -fill red -width 2
    $win create line 172.0 62.0 179.0 69.0 -fill red -width 2
    $win create line 179.0 69.0 184.0 80.0 -fill red -width 2
    $win create line 184.0 80.0 185.0 95.0 -fill red -width 2
    $win create line 185.0 95.0 182.0 104.0 -fill red -width 2
    $win create line 182.0 104.0 177.0 113.0 -fill red -width 2
    $win create line 177.0 113.0 166.0 122.0 -fill red -width 2
    $win create line 166.0 122.0 153.0 125.0 -fill red -width 2
    $win create line 153.0 125.0 144.0 125.0 -fill red -width 2
    $win create line 144.0 125.0 133.0 121.0 -fill red -width 2
    $win create line 135.0 122.0 125.0 116.0 -fill red -width 2
    $win create line 125.0 116.0 119.0 106.0 -fill red -width 2
    $win create line 119.0 106.0 116.0 95.0 -fill red -width 2
    $win create line 116.0 95.0 114.0 83.0 -fill red -width 2
    $win create line 114.0 83.0 118.0 73.0 -fill red -width 2
    $win create line 118.0 73.0 126.0 62.0 -fill red -width 2
    $win create line 126.0 62.0 140.0 55.0 -fill red -width 2
    $win create line 102.0 152.0 124.0 152.0 -fill red -width 2
    $win create line 177.0 152.0 199.0 152.0 -fill red -width 2
    $win create line 102.0 151.0 102.0 90.0 -fill red -width 2
    $win create line 101.0 91.0 104.0 73.0 -fill red -width 2
    $win create line 104.0 73.0 112.0 57.0 -fill red -width 2
    $win create line 112.0 57.0 125.0 44.0 -fill red -width 2
    $win create line 125.0 44.0 140.0 38.0 -fill red -width 2
    $win create line 141.0 38.0 156.0 37.0 -fill red -width 2
    $win create line 156.0 37.0 169.0 41.0 -fill red -width 2
    $win create line 169.0 41.0 180.0 48.0 -fill red -width 2
    $win create line 180.0 48.0 189.0 57.0 -fill red -width 2
    $win create line 189.0 57.0 196.0 68.0 -fill red -width 2
    $win create line 196.0 69.0 200.0 82.0 -fill red -width 2
    $win create line 200.0 82.0 200.0 96.0 -fill red -width 2
    $win create line 200.0 96.0 200.0 152.0 -fill red -width 2
    $win create line 171.0 137.0 182.0 131.0 -fill red -width 2
    $win create line 182.0 131.0 190.0 122.0 -fill red -width 2
    $win create line 190.0 122.0 197.0 110.0 -fill red -width 2
    $win create line 197.0 110.0 201.0 97.0 -fill red -width 2
    $win create line 130.0 138.0 120.0 130.0 -fill red -width 2
    $win create line 120.0 130.0 112.0 120.0 -fill red -width 2
    $win create line 112.0 121.0 102.0 103.0 -fill red -width 2
    $win create line 181.0 135.0 193.0 146.0 -fill blue
    $win create line 193.0 146.0 198.0 146.0 -fill blue
    $win create line 189.0 128.0 198.0 136.0 -fill blue
    $win create line 187.0 130.0 197.0 139.0 -fill blue
    $win create line 189.0 137.0 195.0 142.0 -fill blue
    $win create line 195.0 142.0 198.0 142.0 -fill blue
    $win create line 187.0 139.0 191.0 135.0 -fill blue
    $win create line 195.0 69.0 192.0 71.0 -fill orange
    $win create line 189.0 71.0 185.0 61.0 -fill orange
    $win create line 185.0 61.0 175.0 49.0 -fill orange
    $win create line 175.0 49.0 158.0 41.0 -fill orange
    $win create line 158.0 41.0 139.0 41.0 -fill orange
    $win create line 139.0 41.0 125.0 48.0 -fill orange
    $win create line 125.0 48.0 112.0 62.0 -fill orange
    $win create line 112.0 62.0 105.0 86.0 -fill orange
    $win create line 105.0 86.0 107.0 107.0 -fill orange
    $win create line 107.0 107.0 120.0 124.0 -fill orange
    $win create line 120.0 125.0 134.0 131.0 -fill orange
    $win create line 134.0 131.0 137.0 127.0 -fill orange
    $win create line 194.0 71.0 189.0 72.0 -fill orange
    $win create line 189.0 72.0 179.0 56.0 -fill orange
    $win create line 179.0 56.0 170.0 48.0 -fill orange
    $win create line 170.0 48.0 158.0 43.0 -fill orange
    $win create line 158.0 43.0 139.0 43.0 -fill orange
    $win create line 139.0 43.0 126.0 50.0 -fill orange
    $win create line 126.0 50.0 115.0 64.0 -fill orange
    $win create line 115.0 64.0 108.0 86.0 -fill orange
    $win create line 108.0 86.0 110.0 105.0 -fill orange
    $win create line 110.0 105.0 118.0 115.0 -fill orange
    $win create line 118.0 115.0 122.0 111.0 -fill orange
    $win create line 194.0 71.0 186.0 71.0 -fill orange
    $win create line 186.0 71.0 176.0 55.0 -fill orange
    $win create line 176.0 55.0 160.0 45.0 -fill orange
    $win create line 160.0 45.0 141.0 45.0 -fill orange
    $win create line 141.0 45.0 128.0 50.0 -fill orange
    $win create line 128.0 50.0 118.0 64.0 -fill orange
    $win create line 118.0 64.0 110.0 85.0 -fill orange
    $win create line 110.0 85.0 113.0 89.0 -fill orange
    $win create line 189.0 72.0 176.0 56.0 -fill orange
    $win create line 176.0 56.0 161.0 48.0 -fill orange
    $win create line 161.0 48.0 140.0 47.0 -fill orange
    $win create line 140.0 47.0 138.0 54.0 -fill orange
    $win create line 127.0 54.0 118.0 67.0 -fill orange
    $win create line 118.0 67.0 121.0 68.0 -fill orange
    $win create line 162.0 54.0 170.0 52.0 -fill orange
    $win create line 170.0 52.0 189.0 70.0 -fill orange
    $win create line 179.0 68.0 185.0 68.0 -fill orange
    $win create line 185.0 68.0 192.0 73.0 -fill orange
    $win create line 193.0 73.0 189.0 78.0 -fill orange
    $win create line 189.0 78.0 189.0 91.0 -fill orange
    $win create line 193.0 72.0 193.0 78.0 -fill orange
    $win create line 193.0 78.0 195.0 102.0 -fill orange
    $win create line 195.0 102.0 188.0 118.0 -fill orange
    $win create line 188.0 118.0 175.0 130.0 -fill orange
    $win create line 175.0 130.0 166.0 130.0 -fill orange
    $win create line 167.0 131.0 163.0 125.0 -fill orange
    $win create line 195.0 71.0 190.0 85.0 -fill orange
    $win create line 190.0 85.0 192.0 103.0 -fill orange
    $win create line 192.0 103.0 186.0 112.0 -fill orange
    $win create line 186.0 112.0 180.0 110.0 -fill orange
    $win create text 173.0 22.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Contacts
    $win create text 167.0 14.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Electrical
    $win create line 151.0 28.0 138.0 55.0 -fill white
    $win create line 152.0 29.0 164.0 54.0 -fill white
    $win create text 222.0 16.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Slow
    $win create text 228.0 24.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Reflective
    $win create text 223.0 32.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Lenses
    $win create line 206.0 38.0 173.0 73.0 -fill white
    $win create text 107.0 31.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Lenses
    $win create text 112.0 22.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Reflective
    $win create text 104.0 14.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Fast
    $win create line 113.0 32.0 130.0 63.0 -fill white
    $win create text 62.0 41.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Plutonium-239
    $win create line 66.0 43.0 146.0 87.0 -fill white
    $win create text 59.0 55.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Uranium-235
    $win create line 63.0 57.0 140.0 89.0 -fill white
    $win create text 53.0 94.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Beryllium
    $win create text 68.0 104.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Reflector Lining}
    $win create line 68.0 97.0 98.0 89.0 -fill white
    $win create line 68.0 98.0 103.0 105.0 -fill white
    $win create text 58.0 133.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Uranium-238
    $win create line 64.0 133.0 131.0 101.0 -fill white
    $win create text 51.0 148.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Beryllium
    $win create line 59.0 148.0 132.0 106.0 -fill white
    $win create text 81.0 222.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Lithium-6 Deutride}
    $win create line 87.0 222.0 165.0 199.0 -fill white
    $win create line 88.0 222.0 137.0 222.0 -fill white
    $win create text 69.0 238.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Plutonium-239
    $win create text 60.0 248.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Spark Plug}
    $win create line 69.0 244.0 151.0 244.0 -fill white
    $win create text 276.0 86.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Primary
    $win create text 272.0 95.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Device
    $win create line 209.0 55.0 223.0 55.0 -fill white
    $win create line 223.0 55.0 223.0 127.0 -fill white
    $win create line 223.0 127.0 209.0 127.0 -fill white
    $win create line 224.0 89.0 246.0 89.0 -fill white
    $win create text 274.0 202.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Device
    $win create text 280.0 193.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Secondary
    $win create line 209.0 136.0 224.0 136.0 -fill white
    $win create line 224.0 136.0 224.0 289.0 -fill white
    $win create line 224.0 289.0 209.0 289.0 -fill white
    $win create line 225.0 198.0 241.0 198.0 -fill white
    $win create text 54.0 69.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Graphite
    $win create text 66.0 78.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Shock Absorber}
    $win create line 70.0 80.0 136.0 92.0 -fill white
    $win create text 49.0 119.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text Vacuum
    $win create line 55.0 119.0 130.0 98.0 -fill white
    $win create text 295.0 219.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Polystyrene Foam}
    $win create text 296.0 228.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Impregnated with}
    $win create text 283.0 238.0 -anchor e -fill white -font -*-lucida-medium-r-*-*-*-80-*-*-*-*-*-* -text {Pentane Gas}

    set w [winfo width $win]
    set h [winfo height $win]
    $win scale all 180 150 [expr $w/350.0] [expr $h/350.0]
    $win move all [expr 0.5*$w-150] [expr 0.5*$h-150]
}
