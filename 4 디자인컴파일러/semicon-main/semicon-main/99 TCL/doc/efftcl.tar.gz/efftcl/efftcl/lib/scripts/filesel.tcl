# ----------------------------------------------------------------------
#  EXAMPLE: simple file selection dialog
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Fileselect*Listbox.background white widgetDefault
option add *Fileselect*Entry.background white widgetDefault
option add *Fileselect*lbox.width 30 widgetDefault
option add *Fileselect*lbox.height 10 widgetDefault

proc fileselect_create {top} {
    global fsInfo

    set top [dialog_create Fileselect $top]
    set info [dialog_info $top]

    frame $info.list
    pack $info.list -expand yes -fill both -padx 4 -pady 4
    scrollbar $info.list.sbar -command "$info.list.lbox yview"
    pack $info.list.sbar -side right -fill y
    listbox $info.list.lbox -yscrollcommand "$info.list.sbar set"
    pack $info.list.lbox -side left -expand yes -fill both

    frame $info.sel
    pack $info.sel -fill x -padx 4 -pady 4
    label $info.sel.title -text "File:"
    pack $info.sel.title -side left
    entry $info.sel.name
    pack $info.sel.name -side left -expand yes -fill x


    set cntls [dialog_controls $top]
    button $cntls.ok -command {set fselectStatus 1}
    pack $cntls.ok -side left -expand yes
    focus $cntls.ok

    button $cntls.cancel -command {set fselectStatus 0}
    pack $cntls.cancel -side left -expand yes

    bind $info.list.lbox <ButtonPress-1> "fileselect_select $top"
    bind $info.list.lbox <Double-ButtonPress-1> "fileselect_dselect $top"
    bindtags $info.list.lbox [list Listbox $info.list.lbox $top all]

    bind $info.sel.name <KeyPress-Return> "$cntls.ok invoke"

    wm title $top "File Selection"
    wm protocol $top WM_DELETE_WINDOW "$cntls.cancel invoke"
    wm withdraw $top

    set fsInfo($top) ""
    return $top
}

proc fileselect_ask {top dir {ok "OK"} {cancel "Cancel"}} {
    global fselectStatus

    set cntls [dialog_controls $top]
    $cntls.ok configure -text $ok
    $cntls.cancel configure -text $cancel

    fileselect_show $top $dir

    dialog_wait $top fselectStatus

    if {$fselectStatus} {
        set info [dialog_info $top]
        return [$info.sel.name get]
    }
    return ""
}

proc fileselect_show {top dir} {
    global fsInfo
    set fsInfo($top) $dir

    set info [dialog_info $top]
    $info.list.lbox delete 0 end
    if {[file dirname $dir] != $dir} {
        $info.list.lbox insert end ".."
    }
    set pattern [file join $dir *]

    foreach file [lsort [glob -nocomplain $pattern]] {
        if {[file isdirectory $file]} {
            $info.list.lbox insert end "[file tail $file]/"
        }
    }
    foreach file [lsort [glob -nocomplain $pattern]] {
        if {[file isfile $file]} {
            $info.list.lbox insert end "[file tail $file]"
        }
    }
}

proc fileselect_get {top} {
    global fsInfo

    set info [dialog_info $top]
    set dir $fsInfo($top)
    set i [$info.list.lbox curselection]
    if {$i != ""} {
        set selected [string trimright [$info.list.lbox get $i] /]
        if {$selected == ".."} {
            set dir [file dirname $dir]
        } else {
            set dir [file join $dir $selected]
        }
        return $dir
    }
    return ""
}

proc fileselect_select {top} {
    set next [fileselect_get $top]
    set info [dialog_info $top]
    $info.sel.name delete 0 end
    $info.sel.name insert 0 $next
}

proc fileselect_dselect {top} {
    set next [fileselect_get $top]
    set info [dialog_info $top]
    $info.list.lbox selection clear 0 end
    if {$next != "" && [file isdirectory $next]} {
        fileselect_show $top $next
    }
}

if {[info commands tk_*File] == ""} {
    fileselect_create .fileselect

# <-- must be like this for auto_mkindex
proc tk_getOpenFile {args} {
        set title "Open"
        set dir [pwd]
        foreach {name val} $args {
            switch -- $name {
                -initialdir {
                    set dir $val
                }
                -title {
                    set title $val
                }
            }
        }
        wm title .fileselect $title
        return [fileselect_ask .fileselect $dir "Open"]
    }

# <-- must be like this for auto_mkindex
proc tk_getSaveFile {args} {
        set title "Save As"
        set dir [pwd]
        foreach {name val} $args {
            switch -- $name {
                -initialdir {
                    set dir $val
                }
                -title {
                    set title $val
                }
            }
        }
        wm title .fileselect $title
        set file [fileselect_ask .fileselect $dir "Save"]
        if {$file != "" && [file exists $file]} {
            set mesg "File \"$file\" already exists.\nDo you want to overwrite it?"
            if {[confirm_ask $mesg "Yes" "No"]} {
                return $file
            }
            return ""
        }
        return $file
    }
}
