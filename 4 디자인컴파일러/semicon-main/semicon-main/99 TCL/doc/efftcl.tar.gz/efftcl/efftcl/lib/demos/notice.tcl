# ----------------------------------------------------------------------
#  DEMO: simple notice dialog
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

label .prompt -text "Enter some text:"
pack .prompt -anchor w

text .mesg -width 50 -height 6 -wrap word
pack .mesg -expand yes -fill both -padx 2 -pady 2

button .show -text "Show Notice" -command {
    notice_show [string trim [.mesg get 1.0 end]]
}
pack .show -pady 4
