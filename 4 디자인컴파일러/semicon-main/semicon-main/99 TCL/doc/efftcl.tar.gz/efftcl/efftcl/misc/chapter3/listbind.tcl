# ----------------------------------------------------------------------
#  DEMO: show double-click in action
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

listbox .lb
label .choice
pack .lb .choice

foreach i {Blessed be the ties that bind} {
   .lb insert end $i
}

bind .lb <Double-Button-1> {
    .choice configure -text "selection: [.lb get active]"
}
