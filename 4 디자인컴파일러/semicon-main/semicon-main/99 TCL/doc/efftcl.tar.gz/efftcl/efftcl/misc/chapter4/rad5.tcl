# ----------------------------------------------------------------------
#  EXAMPLE: simple drawings on the canvas
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

canvas .c -width 100 -height 110
pack .c

.c create oval 10 10 90 90 -fill yellow -width 2
.c create arc 15 15 85 85 -start 60 -extent 60 \
    -fill black -tags {sign hilite}
.c create arc 15 15 85 85 -start 180 -extent 60 \
    -fill black -tags {sign hilite}
.c create arc 15 15 85 85 -start 300 -extent 60 \
    -fill black -tags {sign hilite}
.c create oval 40 40 60 60 -outline "" -fill yellow
.c create oval 44 44 56 56 -outline "" \
    -fill black -tags {sign hilite}
.c create text 50 95 -anchor n -text "Warning" \
    -tags {message hilite}

.c bind hilite <Enter> {
    .c itemconfigure hilite -fill red
}
.c bind hilite <Leave> {
    .c itemconfigure hilite -fill black
}
.c bind message <ButtonPress-1> {
    if {[.c itemcget message -text] == "Warning"} {
        .c itemconfigure message -text "RED ALERT"
    } else {
        .c itemconfigure message -text "Warning"
    }
}
