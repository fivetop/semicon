# ----------------------------------------------------------------------
#  DEMO: simple button help with <Enter>/<Leave> events
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Canvas.background white startupFile
option add *Canvas.width 200 startupFile
option add *Canvas.height 100 startupFile

frame .cmd
button .cmd.back \
    -bitmap [file join @$env(EFFTCL_LIBRARY) images back.xbm]
button .cmd.fwd \
    -bitmap [file join @$env(EFFTCL_LIBRARY) images fwd.xbm]
canvas .c
label .help -relief sunken -borderwidth 2 -anchor w

pack .cmd .c .help -side top -fill x
pack .cmd.back .cmd.fwd -side left

bind .cmd.back <Enter> {.help configure -text "Page backward"}
bind .cmd.back <Leave> {.help configure -text ""}
bind .cmd.fwd <Enter> {.help configure -text "Page forward"}
bind .cmd.fwd <Leave> {.help configure -text ""}
