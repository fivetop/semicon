package ifneeded Efftcl 1.0 [list source [file join $dir efftcl.tcl]]
