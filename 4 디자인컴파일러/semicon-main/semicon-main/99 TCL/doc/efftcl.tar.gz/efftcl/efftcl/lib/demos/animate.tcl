# ----------------------------------------------------------------------
#  DEMO: use "after" to do animation
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

set images {}
set counter 0
for {set i 1} {$i <= 9} {incr i} {
    set file [file join $env(EFFTCL_LIBRARY) images esec$i.gif]
    set imh [image create photo -file $file]
    label .l$i -image $imh
    lappend images $imh
}

label .show -image [lindex $images 0]
pack .show -padx 8 -pady 8

button .start -text "Start" -state normal -command {
    set pending [animate_start 100 $images {
        .show configure -image %v
    }]
    .stop configure -state normal
    .start configure -state disabled
}
pack .start -fill x

button .stop -text "Stop" -state disabled -command {
    animate_stop $pending
    .start configure -state normal
    .stop configure -state disabled
}
pack .stop -fill x
