#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: use "update" to force changes
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

proc slow {} {
    . configure -cursor watch
    .status configure -text "Working..."
    update

    for {set i 0} {$i < 3000} {incr i} {
        # do something important...

#        update
after 100
    }

    . configure -cursor ""
    .status configure -text "Ready"
    update
}

label .status -text "Ready" -width 15
pack .status

button .busy -text "Go" -command slow
pack .busy -fill x
