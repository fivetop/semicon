# ----------------------------------------------------------------------
#  EXAMPLE: using "update idletasks" to flush out changes
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
label .countdown -text "Ready"
pack .countdown -padx 4 -pady 4

button .launch -text "Launch" -command {
    for {set i 10} {$i >= 0} {incr i -1} {
        .countdown configure -text $i
        update idletasks
        after 1000
    }
}
pack .launch -padx 4 -pady 4
