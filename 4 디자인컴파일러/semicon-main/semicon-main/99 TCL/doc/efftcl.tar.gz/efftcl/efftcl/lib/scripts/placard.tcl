# ----------------------------------------------------------------------
#  EXAMPLE: introductory placard for apps that take a while to start up
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

proc placard_create {script} {
    global env placard

    wm withdraw .
    set placard [open "| wish" w]

    puts $placard {
        wm overrideredirect . 1
        . configure -borderwidth 4 -relief raised

        after idle {
            update idletasks
            set maxw [winfo screenwidth .]
            set maxh [winfo screenheight .]
            set x0 [expr ($maxw-[winfo reqwidth .])/2]
            set y0 [expr ($maxh-[winfo reqheight .])/2]
            wm geometry . "+$x0+$y0"
        }
    }
    puts $placard $script
    flush $placard
}

proc placard_eval {script} {
    global placard
    puts $placard $script
    flush $placard
}

proc placard_destroy {} {
    global placard
    update
    puts $placard "exit"
    flush $placard
    close $placard
    wm deiconify .
}


# ----------------------------------------------------------------------
#  These procedures don't work properly on Windows and Macintosh
#  platforms--at least, not yet.  Ignore them.
# ----------------------------------------------------------------------
if {$tcl_platform(platform) == "windows" ||
    $tcl_platform(platform) == "macintosh"} {

    proc placard_create {script} {}
    proc placard_eval {script} {}
    proc placard_destroy {} {}
}
