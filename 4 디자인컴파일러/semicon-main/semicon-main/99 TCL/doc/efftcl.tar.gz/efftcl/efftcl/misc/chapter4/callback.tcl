#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: calendar widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

calendar_create .cal 7/4/1997
pack .cal -expand yes -fill both

entry .entry
pack .entry -fill x -padx 4 -pady 4

calendar_select_cmd .cal {
    puts "selected: %d"
    .entry delete 0 end
    .entry insert 0 "%d"
}
