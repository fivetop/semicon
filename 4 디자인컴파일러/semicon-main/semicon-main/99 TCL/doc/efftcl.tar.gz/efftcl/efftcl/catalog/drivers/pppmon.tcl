# ----------------------------------------------------------------------
#  Driver for "pppmon" example when invoked from the catalog
#
#  Checks to see whether "pppstats" is on the command path, and
#  if not, automatically substitutes the fake "pppstats" program
#  from the "fixes" directory.
#
#  This program should be invoked in the same directory context
#  as the "catalog.tcl" script.
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
#  USAGE: find_tclsh
#
#  This procedure returns the appropriate "tclsh" program for the
#  current "wish".  If tclsh is not found, it returns the null string.
# ----------------------------------------------------------------------
proc find_tclsh {} {
    global tcl_version

    set bin [file dirname [info nameofexecutable]]
    set best [glob -nocomplain [file join $bin tclsh$tcl_version]]
    if {$best != ""} {
        return $best
    }
    set best [glob -nocomplain [file join $bin tclsh]]
    if {$best != ""} {
        return $best
    }
    set any [glob -nocomplain [file join $bin tclsh*]]
    set best [lindex [lsort $any] end]
    return $best
}

# ----------------------------------------------------------------------
wm withdraw .
auto_load tk_messageBox

if {[catch {open "| pppstats" "r"} fid] == 0} {

    catch {close $fid}    ;# success!

} else {
    set tclsh [find_tclsh]
    rename open tcl_open
    proc open {args} [format {
        return [tcl_open "%s" "r"]
    } [list "|" $tclsh [file join fixes pppstats]]]

    if {[catch {open "| pppstats" "r"} fid] == 0} {

        catch {close $fid}    ;# success with demo!

        tk_messageBox -icon warning -message "Program \"pppstats\" not found.\nSubstituting the demo version \"efftcl/fixes/pppstats\", which generates random data."
    } else {
        tk_messageBox -icon error -message "Program \"pppstats\" not found.\nLocate the \"pppstats\" directory (may be /usr/sbin), add that directory to your command path, and try again."
        exit
    }
}

# Now, load the real "pppmon" application...
# ----------------------------------------------------------------------
source [file join apps pppmon]
update
wm deiconify .
