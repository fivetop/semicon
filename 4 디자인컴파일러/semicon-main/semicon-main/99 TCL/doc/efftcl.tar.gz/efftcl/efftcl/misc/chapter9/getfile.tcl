# ----------------------------------------------------------------------
#  EXAMPLE: options for tk_getOpenFile
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
set tk_strictMotif 1

label .image -image [image create photo]
pack .image

button .load -text "Load Image..." \
    -command {load_image .image}
pack .load

proc load_image {win} {
    set types {
        {{GIF Files} {.gif}     }
        {{GIF Files} {}     GIFF}
        {{PPM Files} {.ppm}     }
        {{PGM Files} {.pgm}     }
    }
    set file [tk_getOpenFile -title "Load Image" \
        -filetypes $types]

    if {$file != ""} {
        set imh [$win cget -image]
        $imh configure -file $file
    }
}
