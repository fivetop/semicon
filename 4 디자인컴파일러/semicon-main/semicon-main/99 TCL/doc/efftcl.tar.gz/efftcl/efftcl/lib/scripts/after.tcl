# ----------------------------------------------------------------------
#  EXAMPLE: after debugging routines
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
# USAGE: after_debug
#
# Pops up a dialog that displays a list of pending "after" events.
# ----------------------------------------------------------------------
proc after_debug {} {
    if {![winfo exists .afterdb.t]} {
        toplevel .afterdb
        wm title .afterdb "After: Debug Info"
        text .afterdb.t -width 50 -height 10 -wrap none
        pack .afterdb.t -fill both -expand yes
        after_debug_update
    }
}

proc after_debug_update {} {
    if {[winfo exists .afterdb.t]} {
        .afterdb.t delete 1.0 end
        foreach t [after info] {
            .afterdb.t insert end "$t\t[after info $t]\n"
        }
        after 100 after_debug_update
    }
}
