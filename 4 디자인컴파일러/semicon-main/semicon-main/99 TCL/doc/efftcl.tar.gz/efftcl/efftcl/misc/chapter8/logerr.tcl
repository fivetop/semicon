# ----------------------------------------------------------------------
#  DEMO: handling background errors with "bgerror"
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

proc bgerror {error} {
    set fid [open "/tmp/log.txt" a]
    puts $fid $error
    close $fid
}

button .err -text "Error" -command {
    expr 200e3000*1
}
pack .err
