# ----------------------------------------------------------------------
#  DEMO: math client program 3 -- calls backend 3
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Entry.width 7 startupFile
option add *Entry.background white startupFile
option add *Entry.justify center startupFile

entry .x
pack .x -side left
frame .op
pack .op -side left
button .op.add -text "+" -command do_add
pack .op.add -fill both
button .op.sub -text "-" -command do_subtract
pack .op.sub -fill both
entry .y
pack .y -side left
label .result -text ""
pack .result -side left

set backend [open "|tclsh maths3.tcl" "r+"]
fconfigure $backend -buffering line

proc do_add {} {
    global backend
    set x [.x get]
    set y [.y get]
    puts $backend "add $x $y"
    gets $backend num
    .result configure -text "= $num"
}

proc do_subtract {} {
    global backend
    set x [.x get]
    set y [.y get]
    puts $backend "subtract $x $y"
    gets $backend num
    .result configure -text "= $num"
}
