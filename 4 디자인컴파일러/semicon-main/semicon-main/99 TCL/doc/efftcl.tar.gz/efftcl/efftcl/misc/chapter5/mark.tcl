# ----------------------------------------------------------------------
#  EXAMPLE: adding marks into the text
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7 -background white \
    -font -*-helvetica-medium-r-normal--*-120-*
pack .t

.t tag configure "heading" -spacing1 0.1i -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "body" -lmargin1 0.2i

.t tag configure "emphasis" -foreground red \
    -underline yes

.t insert end "Emergency Instructions\n" heading
.t insert end "In case of a nuclear meltdown, " body
.t insert end "engage\nthe " body
.t insert end "Emergency Core Coolant System" {body emphasis}
.t insert end " (ECCS)\nand rotate the " body
.t insert end "Flow Control" {body emphasis} " knob fully\n" body
.t insert end "clockwise." body

.t mark set "emergency" 1.0
.t insert 1.0 "Introduction\n" heading "blah\nblah\nblah\n" body
set heading [.t get emergency "emergency lineend"]
puts "heading: $heading"
.t insert emergency "More Stuff\n" heading "blah\nblah\n" body
