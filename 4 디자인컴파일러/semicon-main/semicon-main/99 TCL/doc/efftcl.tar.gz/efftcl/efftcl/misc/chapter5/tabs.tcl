# ----------------------------------------------------------------------
#  EXAMPLE: using tabs to create tables
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 50 -height 10 -background white \
    -font -*-helvetica-medium-r-normal--*-120-* \
    -tabs {1.5i right 2i center 2.5i left}
pack .t

.t tag configure "heading" -spacing1 10 -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "superscript" -offset 5 \
    -font -*-helvetica-medium-r-normal--*-80-*

.t insert end "\tName\tSymbol\tHalf-Life\n" heading

foreach {name num symbol hlife} {
    "Uranium 238" 238 U "4,500,000,000 years"
    "Iodine 129" 129 I "16,000,000 years"
    "Plutonium 239" 239 Pu "240,000 years"
    "Cesium 137" 137 Cs "30 years"
    "Strontium 90" 90 Sr "29 years"
    "Tritium" 3 H "12 years"
} {
    .t insert end "\t$name"
    .t insert end "\t$num" superscript "$symbol"
    .t insert end "\t$hlife\n"
}
