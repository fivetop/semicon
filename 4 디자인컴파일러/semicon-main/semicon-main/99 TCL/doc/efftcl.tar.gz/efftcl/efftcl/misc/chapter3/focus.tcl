# ----------------------------------------------------------------------
#  DEMO: show "focus" command
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
. configure -borderwidth 4

set x 1
foreach t {Name Address City Phone Email URL} {
    label .lab$x -text "$t:"
    entry .ent$x
    grid .lab$x -row $x -column 0 -sticky e
    grid .ent$x -row $x -column 1 -sticky ew
    incr x
}
focus .ent1
