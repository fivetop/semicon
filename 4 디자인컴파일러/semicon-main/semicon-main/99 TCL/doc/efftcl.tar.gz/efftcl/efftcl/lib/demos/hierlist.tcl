# ----------------------------------------------------------------------
#  DEMO: hierarchical list viewer
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Entry.background white startupFile

hierlist_create .list
pack .list -side bottom -expand yes -fill both

label .prompt -text "Enter directory name:"
pack .prompt -side left

entry .dname
pack .dname -fill x

bind .dname <KeyPress-Return> {
    set dir [.dname get]
    busy_eval {
        hierlist_display .list [find_files $dir]
    }
}

proc find_files {dir} {
    set flist ""
    set pattern [file join $dir *]
    foreach file [lsort [glob -nocomplain $pattern]] {
        if {[file isdirectory $file]} {
            set contents [find_files $file]
        } else {
            set contents ""
        }
        lappend flist [list [file tail $file] $contents]
    }
    return $flist
}
