#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: using arrays with the calendar widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

cd [file join $env(EFFTCL_LIBRARY) images]

set holidays(07/04/1997) [image create photo -file flag.gif]
set holidays(12/25/1997) [image create photo -file bell.gif]

calendar_create .cal
pack .cal -expand yes -fill both

calendar_decorate_with .cal holidays
