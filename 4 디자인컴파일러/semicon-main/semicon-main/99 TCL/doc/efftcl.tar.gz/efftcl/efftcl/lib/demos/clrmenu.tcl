# ----------------------------------------------------------------------
#  DEMO: menu of color choices
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

label .sample -width 20 -height 3 -text "Sample Text"
pack .sample -side right -expand yes -fill both

set imh [image create bitmap -foreground black -background white \
    -file [file join $env(EFFTCL_LIBRARY) images pen.xbm] \
    -maskfile [file join $env(EFFTCL_LIBRARY) images penm.xbm]]

colormenu_create .pen -image $imh
pack .pen -padx 4 -pady 4

set imh [image create bitmap -foreground black -background white \
    -file [file join $env(EFFTCL_LIBRARY) images paint.xbm] \
    -maskfile [file join $env(EFFTCL_LIBRARY) images paintm.xbm]]

colormenu_create .fill -image $imh
pack .fill -padx 4 -pady 4

colormenu_action .pen {
    .sample configure -foreground "%c" -text "%c"
}
colormenu_action .fill {
    .sample configure -background "%c"
}

colormenu_select .pen black
colormenu_select .fill white
