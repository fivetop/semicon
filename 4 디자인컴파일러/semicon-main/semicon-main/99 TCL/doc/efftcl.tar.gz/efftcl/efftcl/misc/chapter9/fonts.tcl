# ----------------------------------------------------------------------
#  EXAMPLE: font examples
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

toplevel .cntl
button .cntl.continue -text "Continue" -command {set continue 1}
pack .cntl.continue

label .l -text "Hello, World!" \
    -font -*-lucida-bold-o-normal--*-140-*
pack .l

tkwait variable continue
destroy .l

label .l -text "Hello, World!" \
    -font {Lucida 14 bold italic}
pack .l

tkwait variable continue
destroy .l

set token [font create -family Lucida \
    -size 14 -weight bold -slant italic]

label .l -text "Hello, World!" -font $token
pack .l

tkwait variable continue

font configure $token -slant roman

tkwait variable continue
destroy .l

label .l -text "Hello, World!" \
    -font {"AvantGarde Bk BT" 18}
pack .l

tkwait variable continue
destroy .l
exit
