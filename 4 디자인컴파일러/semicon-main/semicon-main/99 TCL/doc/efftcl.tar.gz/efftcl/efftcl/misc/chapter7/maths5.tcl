# ----------------------------------------------------------------------
#  DEMO: math server 5, asynchronous with percent substitution
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set parser [interp create -safe]
$parser eval {
    proc percent_subst {percent string subst} {
        if {![string match %* $percent]} {
            error "bad pattern \"$percent\": should be %something"
        }
        regsub -all {\\|&} $subst {\\\0} subst
        regsub -all $percent $string $subst string
        return $string
    }
}

$parser eval {
    proc add {x y cmd} {
        set num [expr $x+$y]
        set response [percent_subst %v $cmd $num]
        return $response
    }
    proc subtract {x y cmd} {
        set num [expr $x-$y]
        set response [percent_subst %v $cmd $num]
        return $response
    }
}

proc back_handler {parser} {
    if {[gets stdin request] < 0} {
        exit
    } elseif {[catch {$parser eval $request} result] == 0} {
        puts $result
    } else {
        puts [list error_result $result]
    }
}

fileevent stdin readable "back_handler $parser"
vwait enter-mainloop
