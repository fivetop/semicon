# ----------------------------------------------------------------------
#  DEMO: output to stdout is buffered by line
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

while {1} {
    puts "This is a line of text which might be buffered"
    after 1000
}
