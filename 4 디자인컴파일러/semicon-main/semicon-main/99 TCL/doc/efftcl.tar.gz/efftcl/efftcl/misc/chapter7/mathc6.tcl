# ----------------------------------------------------------------------
#  DEMO: math client program 6 -- multi-line requests
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Entry.width 7 startupFile
option add *Entry.background white startupFile
option add *Entry.justify center startupFile

entry .x
pack .x -side left
frame .op
pack .op -side left
button .op.add -text "+" -command do_add
pack .op.add -fill both
button .op.sub -text "-" -command do_subtract
pack .op.sub -fill both
entry .y
pack .y -side left
label .result -text ""
pack .result -side left

proc do_add {} {
    global backend
    set x [.x get]
    set y [.y get]
    puts $backend "add $x $y {"
    puts $backend "    show_result %v"
    puts $backend "}"
}

proc do_subtract {} {
    global backend
    set x [.x get]
    set y [.y get]
    puts $backend "subtract $x $y {"
    puts $backend "    show_result %v"
    puts $backend "}"
}

proc cmd_show_result {num} {
    .result configure -text "= $num"
}

proc cmd_error_result {msg} {
    notice_show $msg error
}

set parser [interp create -safe]
$parser alias show_result cmd_show_result
$parser alias error_result cmd_error_result

proc front_handler {fd parser} {
    global buffer
    if {[gets $fd request] < 0} {
        catch {close $fd}
        notice_show "Lost backend" error
    } else {
        append buffer $request "\n"
        if {[info complete $buffer]} {
            set request $buffer
            set buffer ""
            if {[catch {$parser eval $request} result]} {
                notice_show $result error
            }
        }
    }
}

set backend [open "|tclsh maths6.tcl" "r+"]
fconfigure $backend -buffering line
fileevent $backend readable \
    "front_handler $backend $parser"
