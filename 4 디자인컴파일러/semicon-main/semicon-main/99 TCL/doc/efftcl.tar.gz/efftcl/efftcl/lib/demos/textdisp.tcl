# ----------------------------------------------------------------------
#  DEMO: read-only text display
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

button .display -text "Display File..." -command {
    set fname [tk_getOpenFile -title "Display File"]
    if {$fname != ""} {
        set win [textdisplay_create $fname]
        if {[catch {textdisplay_file $win $fname} err] != 0} {
            textdisplay_clear $win
            textdisplay_append $win "Could not load file:\n" bold
            textdisplay_append $win $err italic
        }
    }
}
pack .display
