# ----------------------------------------------------------------------
#  EXAMPLE: inserting text into a text widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 30 -height 5 -wrap none \
    -xscrollcommand {.xsbar set} \
    -yscrollcommand {.ysbar set}
scrollbar .xsbar -orient horizontal -command {.t xview}
scrollbar .ysbar -orient vertical -command {.t yview}

grid .t .ysbar -sticky nsew
grid .xsbar -sticky nsew
grid columnconfigure . 0 -weight 1
grid rowconfigure . 0 -weight 1

.t insert end {Emergency Instructions
In case of a nuclear meltdown, engage
the Emergency Core Coolant System (ECCS)
and rotate the Flow Control knob fully
clockwise.  Then open the primary release
value and vent excess pressure through
the Exhaust Relief System (ERS) to the
atmosphere.
}
