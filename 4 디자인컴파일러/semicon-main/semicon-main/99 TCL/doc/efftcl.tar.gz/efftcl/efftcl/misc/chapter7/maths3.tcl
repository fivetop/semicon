# ----------------------------------------------------------------------
#  DEMO: math server 3, smart safe parsing
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set parser [interp create -safe]

$parser eval {
    proc add {x y} {
        return [expr $x+$y]
    }
    proc subtract {x y} {
        return [expr $x-$y]
    }
}

while {[gets stdin request] != -1} {
    if {[catch {$parser eval $request} result] != 0} {
        puts "error: $result"
    } else {
        puts $result
    }
}
