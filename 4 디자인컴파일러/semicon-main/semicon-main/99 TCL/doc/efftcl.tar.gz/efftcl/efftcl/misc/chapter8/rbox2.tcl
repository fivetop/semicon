#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: box of mutually-exclusive choices
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

radiobox_create .options "Installation Options:"
pack .options -padx 4 -pady 4

radiobox_add .options "Full install"
radiobox_add .options "Demo only"
radiobox_add .options "Data files"
