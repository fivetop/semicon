# ----------------------------------------------------------------------
#  DEMO: simple dialog
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl
wm withdraw .

set top [dialog_create Dialog]

set win [dialog_info $top]
frame $win.area -width 2i -height 1i -background white
pack $win.area

set win [dialog_controls $top]
frame $win.area -width 2i -height 0.5i -background white
pack $win.area
