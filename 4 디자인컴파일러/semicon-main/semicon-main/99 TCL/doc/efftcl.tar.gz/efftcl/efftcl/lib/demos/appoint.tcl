# ----------------------------------------------------------------------
#  DEMO: appointment schedule widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

set timeSlots {}
foreach hour {8 9 10 11} {
    foreach min {00am 30am} {
        lappend timeSlots "$hour:$min"
    }
}
foreach hour {12 1 2 3 4 5 6 7} {
    foreach min {00pm 30pm} {
        lappend timeSlots "$hour:$min"
    }
}

appointment_create .page
pack .page -side right -expand yes -fill both -pady 4

set date [clock format [clock seconds] -format "%m/%d/%Y"]
foreach time $timeSlots {
    set schedule($time) [list "off" ""]
}
appointment_load .page $date schedule
