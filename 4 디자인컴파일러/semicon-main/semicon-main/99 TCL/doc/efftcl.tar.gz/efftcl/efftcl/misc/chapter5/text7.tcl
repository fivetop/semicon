# ----------------------------------------------------------------------
#  EXAMPLE: handling index values
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7 \
    -background white -cursor left_ptr \
    -font -*-helvetica-medium-r-normal--*-120-*
pack .t

.t tag configure "heading" -spacing1 0.1i -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "body" -lmargin1 0.2i

proc heading {mesg} {
    .t insert end $mesg heading
}
proc body {mesg} {
    .t insert end $mesg body
}

heading "Emergency Instructions\n"
body "In case of a nuclear meltdown, engage\n"
body "the Emergency Core Coolant System (ECCS)\n"
body "and rotate the Flow Control knob fully\n"
body "clockwise."

.t tag configure "hilite" -foreground red

bind .t <Motion> {
    .t tag remove "hilite" 1.0 end
    .t tag add "hilite" "@%x,%y wordstart" "@%x,%y wordend"
}
