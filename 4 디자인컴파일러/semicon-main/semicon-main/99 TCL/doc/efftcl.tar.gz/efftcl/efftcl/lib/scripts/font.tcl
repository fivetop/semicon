# ----------------------------------------------------------------------
#  EXAMPLE: procedures to manipulate fonts
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Tk 8.0

option add *Fontselect*Listbox.background white widgetDefault
option add *Fontselect*Text.background white widgetDefault
option add *Fontselect*Entry.background white widgetDefault

# ----------------------------------------------------------------------
# USAGE: font_best <family> <family>... <option> <value>...
#
# Creates a new font with an automatically generated name.  If the
# first <family> is not installed, then the font defaults to the next
# family, and the next, and so on.  If none of the families are
# installed, the font defaults to a system face.  The remaining
# arguments are treated as <option> <value> pairs like "-size 10",
# used to configure the font.
# ----------------------------------------------------------------------
proc font_best {args} {
    set fname [font create]
    set family ""
    while {[llength $args] > 0} {
        set arg0 [lindex $args 0]
        if {[string index $arg0 0] == "-"} {
            break
        }
        set args [lrange $args 1 end]

        if {$family == ""} {
            font configure $fname -family $arg0
            if {[font actual $fname -family] == $arg0} {
                set family $arg0
            }
        }
    }

    eval font configure $fname $args
    return $fname
}

# ----------------------------------------------------------------------
# Fontselect dialog
# ----------------------------------------------------------------------
# USAGE: font_select_update
#
# Invoked whenever one of the slots within the fnInfo structure
# changes.  If the slot corresponds to a font characteristic, then
# the internal font is updated to the current state.
# ----------------------------------------------------------------------
proc font_select_update {name1 name2 op} {
    global fnInfo

    switch -- $name2 {
        family - size - weight - slant - underline - overstrike {
            font configure $fnInfo(font) -$name2 $fnInfo($name2)
        }
    }
}

# ----------------------------------------------------------------------
set fnInfo(font) [font create]
trace variable fnInfo w font_select_update

set fnInfo(dialog) [dialog_create Fontselect]
wm title $fnInfo(dialog) "Font Selector"

wm protocol $fnInfo(dialog) WM_DELETE_WINDOW {
    set win [dialog_controls $fnInfo(dialog)]
    $win.cancel invoke
}
wm withdraw $fnInfo(dialog)

set win [dialog_info $fnInfo(dialog)]
frame $win.sample -height 1i
pack propagate $win.sample 0
pack $win.sample -side bottom -fill x
text $win.sample.text -width 1 -height 1 -wrap none \
    -font $fnInfo(font) \
    -yscrollcommand "$win.sample.sbar set"
pack $win.sample.text -side left -expand yes -fill both
scrollbar $win.sample.sbar -orient vertical \
    -command "$win.sample.text yview"
pack $win.sample.sbar -side right -fill y
label $win.samplel -text "Sample:"
pack $win.samplel -side bottom -anchor w
frame $win.sep2 -height 2 -borderwidth 1 -relief sunken
pack $win.sep2 -side bottom -fill x -pady 8

listbox $win.families -height 1 -exportselection 0 \
    -yscrollcommand "$win.sbar set"
pack $win.families -side left -expand yes -fill both
scrollbar $win.sbar -orient vertical -command "$win.families yview"
pack $win.sbar -side left -fill y
frame $win.opts
pack $win.opts -side left -padx 2
label $win.opts.sizel -text "Size:"
grid $win.opts.sizel -row 0 -column 0 -sticky e
entry $win.opts.size -width 5
grid $win.opts.size -row 0 -column 1 -sticky ew
label $win.opts.weightl -text "Weight:"
grid $win.opts.weightl -row 1 -column 0 -sticky e
tk_optionMenu $win.opts.weight fnInfo(weight) normal bold
grid $win.opts.weight -row 1 -column 1 -sticky ew
label $win.opts.slantl -text "Slant:"
grid $win.opts.slantl -row 2 -column 0 -sticky e
tk_optionMenu $win.opts.slant fnInfo(slant) roman italic
grid $win.opts.slant -row 2 -column 1 -sticky ew
label $win.opts.ulinel -text "Underline:"
grid $win.opts.ulinel -row 3 -column 0 -sticky e
tk_optionMenu $win.opts.uline fnInfo(underline) off on
grid $win.opts.uline -row 3 -column 1 -sticky ew
label $win.opts.ovstrl -text "Overstrike:"
grid $win.opts.ovstrl -row 4 -column 0 -sticky e
tk_optionMenu $win.opts.ovstr fnInfo(overstrike) off on
grid $win.opts.ovstr -row 4 -column 1 -sticky ew

eval $win.families insert 0 [lsort [font families]]
$win.families selection set 0
set fnInfo(family) [$win.families get 0]

bind $win.families <ButtonPress-1> {font_select_family %W %y}
bind $win.families <B1-Motion> {font_select_family %W %y}

proc font_select_family {win y} {
    global fnInfo

    set index [$win nearest $y]
    if {$index != ""} {
        set fnInfo(family) [$win get $index]
    }
}

$win.opts.size insert 0 "12"
bind $win.opts.size <KeyPress-Return> {font_select_size %W}
bind $win.opts.size <Leave> {font_select_size %W}
bind $win.opts.size <FocusOut> {font_select_size %W}

proc font_select_size {win} {
    global fnInfo

    set size [$win get]
    if {[catch {expr round($size)} size] == 0} {
        set fnInfo(size) $size
    } else {
        $win delete 0 end
        $win insert 0 $fnInfo(size)
    }
}

set win [dialog_controls $fnInfo(dialog)]
button $win.ok -text "OK" -command {
    set fnInfo(ok) 1
}
pack $win.ok -side left -expand yes -padx 4

button $win.cancel -text "Cancel" -command {
    set fnInfo(ok) 0
}
pack $win.cancel -side left -expand yes -padx 4

set fnInfo(size) 12
set fnInfo(sample) "ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
1234567890 !@#$%^&*()"


# ----------------------------------------------------------------------
# USAGE: font_select ?<sample>?
#
# Pops up a dialog, allowing the user to select a font.  If the
# <sample> text is included, then this text is displayed in the
# dialog.  Otherwise, a default string is displayed, showing part
# of the alphabet.
# ----------------------------------------------------------------------
proc font_select {{sample ""}} {
    global fnInfo
    set info [dialog_info $fnInfo(dialog)]

    $info.sample.text delete 1.0 end
    if {[string length $sample] == 0} {
        set sample $fnInfo(sample)
    }
    $info.sample.text insert 1.0 $sample

    set cntls [dialog_controls $fnInfo(dialog)]
    focus $cntls.ok
    dialog_wait $fnInfo(dialog) fnInfo(ok)

    if {$fnInfo(ok)} {
        return [font configure $fnInfo(font)]
    }
    return ""
}
