# ----------------------------------------------------------------------
#  APPLICATION: electric secretary
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Text.background white startupFile
option add *Listbox.background white startupFile
option add *Entry.background white startupFile

image create photo pencil-image -data {
R0lGODdhEgAMAMIAAP///zAwMAAAAP+uZQAA/wAATQAAAAAAACwAAAAAEgAMAAADLAi63P4g
QAEolXU4WzsdIPSABNFwnFKUDOqppSk2q6y41FLLeKezM8YqKEoAADs=
}

image create photo esec-logo -data {
R0lGODdheABaAPcAAAAAADEYajEgcykYUhgIMTkgezEYYjkgcyAQSkoplEopnCkYWjEgajkg
g0EpiyAQQWI5zRAIKRgQOUEgg1IxrCkYYs3NAEEplFoxvWJiABAIIAgAEMXFAL29AEEgiwgA
GNXVAEoppFIxpGpqACAQUloxtN7eALS0AGI5xaSkAHt7AHNzABgQQQgIGGo53ouLAHNB7lIp
pKysAM3FAHNB5ntK/xgQMRAIMZycAFoxrGpB5oODAGI51SkQUt7VAFoxxcW9AAAACGpB3lIx
tFo5xZSUAHNB9ntzANXNAL20AINK7mo51WI5vWpBxUFBAEEgexAQAEEpe2o5zVIxnDEgWpRa
/5RS/1o5nGpiAItS/+bmALSsAItS9v///0opiykpAGJBrFpaAGo5xWpB1XtK3u7uAEpKAIta
1aykAFo5lGJKlCAgAFpBnGI5tHtB9oNK/6xz7mpBzYNK9ko5e3NqAHtK9qScAIN7ADEYWoNS
7lo5tIuDAHNBzXNanFIpnDkgamJBpMW93hAQCL2s7ntzGBgYADExAHtarEoxi1JKIKRzzZxq
/zkpSsWc3ggIIKSD1c2U/1o5g5xqzWpiEFJSADk5AHtK5pSDMbSD1YNztP//AINzvbR79pRq
zYNizWpaOYtzrO7m9pSLAIuDrHtSxWpiGHtzIFpSEFpKSkoxe0E5MXNKtJRa7tXV5sWL7qxz
/6yLze7m7tXN3nNarEpBKZxq1TkpWubeAL2D/6SUSko5g2pBvYuDGN7F/1Ixi3tB1VJKAJSL
CINa3rS0EGJBtJRa5qSD/720zUo5OXtqrEExQXNB1VI5i2I5rFJKMWo5vYNS/6xq/2pqCJyU
AINavWJSKXNK1XtqnKRi/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAeABaAAAI/wABCBxIsKDBgwgTKlzIsKHD
hxAjSpxIsaLFixgzatzIsaPHjyBDihxJsqTJkyhTqlzJsqXLlzBjypzp0tAXmjgXrkCzZcWI
MJWg5Bzq5MUJDhxkqDiyoukISjeHwtyJdIYFEDhWHFHBlWkGqS9fIL1qoYPSDFhGjNB6xAxY
jkEeFAgQYIHdBQPyDnhAoC8BXkhAcDghY8uJHRkSJ04r9C3GDQQQeAhBN4ADBwXmVt4cAJUM
GSeSdOjgcwQWxWEcX9wgAUFeBwosuzBipIbt2zVguIAA4dKJ0UCAcGjqVO0a1RZd5+1xIXaD
59CjwxYRKRdwpBw67Nhxp+sI5BUlDP9wvSAABQ8HoqsvYEACACfCxwbu8ELUi/s7UoOfKKHH
gAUkCCCCAAawYOCBLEggwQcDZWAVCCCYYIIP9BVhoYWF7DfRAD3gNQBsDDzQEA4+SGgChBKm
sIMKO7yggoYTPUDCADMm4AADNjR0wolIaFGGJrdYIMMIGahlhiAa0OWhXnlpMJAGCPSAgAYb
aFAeX34R0JpfGwCwQQROAhABAV2SVEFedg2RAANnjpflmwSYMkwZZYBgVgo4TKNYYqpUEIMI
BSQg6KAJEKBBBAgYEMAENtLFG3oOVHYBBJsZsAAEDSCqaAELlAlSBP/htQAFDTBgKgOcpUrX
JyngiQMOeO7/mQEVBmAQQwMK5KqAAxMs0FeiB0ygAARvxBFAAihgYE0TF5RAwQ8lKDAEBjQI
U4AOnArAgAIwSDGASKDqJQAFBWzL27nopgtGMHa0CtoJOOx5SgAGoODAAQYMIMGbDxwQQAOX
JcBEFn4UoG0JJQQggAAYlDDBZSUYA4YOByhwgAMJKLCMiCExOcAEFDAwgQgUlGzyySKIkMAE
hBT2WwfCFaGWWsoYUIC9BAikgYIsPCDXBA0I6gFmHtBVwQQhUKCwADyU0EABBxQAQQI64BoA
Ag94GtIDTIJYwHqZQb3AggIVATN2VuHQnQrSGGDABETga1el5jVAwgMMKjCBzf4e//BIHwws
7MIF4z1QQQMhLKFADFqPtOQAIawZQQQOJcGBVYFBmMJ9e1Tj9gUoHEuooBN4gIEBBOXQAL4C
0JXDBAsLIMQEWg6gKAYQYHDBSeGiScEEAUAUmA/E+wDhDnvcZ4vbImAggK4KXCD9ASVg8K1A
G+TQenpR05DAwgUIUQACFdB1AAa4K3ASAUyO2+tDwJhoPBJl0bGCCpO4bQDJdaFn/gEH+IH1
BgK5qJ1qAoNbWALEZwBdDGIO58OAJA7hpA8cSiSPA1mIHjICEFhgBtnpwAlSoBhk6A8DFMjZ
EADIQqmFbiABuACqTpUAFyxtgQEIVChGIQAIUAATivAVAf/KF6aPeKw5OHrIDkR4giY2MV6J
oZXbIOCAnIXgaw+7DAqq8IQFRaBnCzBA4ASwwDGGgGKCCoQsAuC9HBBsAeXLWUgeFwIFMKBx
CnnBZ5qYBBBoAQQkTIQUpeaALkXrMg6QXg6q8AwD8OUBYVwaw3gwRgygIFAJ2EQXUgGDXeUA
BhhoQBE/0rsBVOB3wXvICywgIS2cCIQdSAwt3DYBCBRAS/8CYAGEpYAmWGEKnNHWwn4wBgFE
jQ/MElQBSHEBB5xpX3j0SCkP8LsKLCQIH2hNl1KAnctZJQl0GAEj3DYsVQ0tAc0sQR1ogEIs
TqAADvBCrxCAF6y9RDl5KQAFDsD/gF+RYEZ5URRncmQHCxj0KhDqgApKEbUGNIEGPCACEX4A
rWgBjV4kUBAAbPAA97zFYx4QwalGSlIGFCBXDRCIDEBQIhOZIAUqcAZdLDU2jcIoIaGynSWh
ly7d8IYIQ5gA5QBgAeN5EIRA2MEIGnNThzyALg14WAmWwAMUUiBy+GoP2QwChNF4dTQ7cEtT
IRIAfj7AQBIY6kOccJ2qzGAFxxkrSjJwuYMe9CtyRYkK7HrQJDghryhJAV8NKgOmApYkgh0s
DnLygQ+0oAWHWoBaXVKEVqlAMVF5iQY0cAMCsKAHOSQBAhAQQ44dViOO3ZkEFiC28h0AAkoY
34cKEM3T/zoEshroSw9I8M6wdXICFyhZAbjAhAUc4AKmtS1DsNnYnZnSABWwCwNKELYCGCEE
l9HDKwogBisU4AK0VS5CNjs5CfgMgAKtjIeElcMCeMAIFqsYDQLFhRwcILmnbW4EbmBe16RX
AEYgxgXYMAuDtWkBIWADKKKWACMIAGsnhY0YWIE62zoCQAiYUXnIVRnYOKABgNAbBFDwOH0m
IxYCKEAMjMAX0l7sMotIw0Y+MLkItMZ2lRnAKC3SWBqXF5+beZ4OvieABohgaWGjwRDo6IBM
dGEOKmYxjr8GsBoUICOc9Qv56BK72JGgtgrZgJgba5cK6K9ekZKUAsrFrVSStv88kuRBAphk
HkZ14RoF+AEN3DYFREBHATW4XkWC0Nm+SMDMCqPAiMcQh9cJoAJgLkgLxqTl8nGmAIPzgAJI
NoRiuCIAQ9CBZCNgXF0+xwOwUEPXFOCBBLTiGK9dQg7hQA0qUyDQFiG0Xw4txmBFTlA54AIf
Wtc4x9bYxj7L0moVxYCM3SiGg4uOit0QAAzwIF+cOe4FrtAIVfuOUwbwxRV6aEsFnAEOAvCA
B8BQhx1DRNd+YTYCBDI6N+agBcam9AOUk94AYInX/5IWCuRAhidcwAUHqICZmYcCBqCvwxMo
XdhCAIMD6GUCMaAXXRIgNQhoug3Y8MKXJjuR3GpZYST/GEgLRjtaEjwBAQoyL44rszBTJaAB
+yIAnA2wsogLrAAYcIEQDR01AbgAAwUYD3WrWwCK5ysvIbgAoxbXiz7kbt8IiIJGgsDy0fJK
ALWFrsIVroAQxC5XQ2jmAWCuINAGIEd2JKm1B7Dr8hlTByGQI7mYjgEYPF2fDW2AB2qRBhHg
NyPs2y0911zhg7DnzCgkIwAFsoCuZxi8CxCIA7q8MPRhyXDma4D3yvQDpktNB/Q6ZQjcDRIS
nHlYAsj8QZJ05gqgIASy9xL7LC/5Mpmd80dvMbMBqADvDYQIpocAD0RrgCvIsSQDqIwBFB17
hIRx4TazFwL26xefBbQCusu9/wI4H74EGM5muyirfA9AgMkRiAFRjbgnMMB6krA2bD9ww8K2
32MxA+C5+lNLE+AzXDNzXBZAHpAjAIAAF8B5HiAECWA+qwAJzABAJUADFUBP6SVHiNISN6Bu
EXdr44cqqnJmBhADKNA6lTFGZHQvIWBLChhDnLdAa4JJnNAJZUUENlQZmXF4LRFD0nMBBAc7
nNdl9MI8JdBlZRcDsMFCRAADOPImPWMA46IDJjUoZ4ALUXAASyAEijIAJCcTBLAoDiACSqAE
JRADdYQBUiAFTEBkRxh5gXIAlHNFUANATygAJAAniVJtPHAAgpIrIhANzfAAYegYLbAAUVAA
IhA9Cf8gAt01IAxAhRCgALknEBSASA7gASgADQJAd1nShwwDAdYEAJGBAH+ggHIVAc9ROh4g
BW9QKjZDRfi1AEGYXVUwBQ/WX4gGNUenisr1VKfyPJ1EL5NSAB5FEAgAPQmgBHnwBCpIFyGC
NVEAjMqFT3DkATwQKdMHAQIAJjWmAc1lAOlRhpagBF5QLgmAAJFmWxJgIPtGAg5gdvRCAUnI
L/4laADQAn+QGd8oXgkBJ/0yF1NEAQZAAPtmgKgCkAURBJPzAdFEabumKK1DiQrgNiuoQHTI
kAMBb4bGjgLRAoVWd1RYGR5ARV2WAB4QJRxZEGxnaGa2fSOpZRRZHimmADpicCseUAGH2JIA
4C+VB3oLswAdZV5cg2gCkFx4UAA96ZMqdzEN0EMDsjCq0jpN6ZQLsXIT8At5MJVFOIBYmRF4
0AZkMAZpeEUOcIlhuZZs2ZZu+ZZwGZdyOZd0WZd2eZcaERAAOw==
}

# ----------------------------------------------------------------------
proc percent_subst {percent string subst} {
    if {![string match %* $percent]} {
        error "bad pattern \"$percent\": should be %something"
    }
    regsub -all {\\|&} $subst {\\\0} subst
    regsub -all $percent $string $subst string
    return $string
}

# ----------------------------------------------------------------------
proc radiobox_create {win {title ""}} {
    global rbInfo

    set rbInfo($win-current) ""
    set rbInfo($win-count) 0

    frame $win -class Radiobox

    if {$title != ""} {
        label $win.title -text $title
        pack $win.title -side top -anchor w
    }
    frame $win.border -borderwidth 2 -relief groove
    pack $win.border -expand yes -fill both

    bind $win <Destroy> "radiobox_destroy $win"
    return $win
}

proc radiobox_destroy {win} {
    global rbInfo
    unset rbInfo($win-count)
    unset rbInfo($win-current)
}

proc radiobox_add {win choice {command ""}} {
    global rbInfo

    set name "$win.border.rb[incr rbInfo($win-count)]"
    radiobutton $name -text $choice -command $command \
        -variable rbInfo($win-current) -value $choice
    pack $name -side top -anchor w

    if {$rbInfo($win-count) == 1} {
        $name invoke
    }
}

proc radiobox_select {win choice} {
    global rbInfo
    set rbInfo($win-current) $choice
}

proc radiobox_get {win} {
    global rbInfo
    return $rbInfo($win-current)
}

# ----------------------------------------------------------------------
image create photo colordial-wheel -data {
R0lGODdhtACWAPYAAP///wAAALa2tllZWQD/ANvb2wAAVQAA/wAoAAAoVQAo/wBV/wB9/wCq
/wDX/wD/VQD/qgD//ygAACgAVSgA/ygoACgoVSgo/yhVAChVVShV/yh9/yiq/yjX/yj/ACj/
VSj/qij//1UA/1UoAFUoVVUo/1VVAFVVVVVVqlVV/1V9VVV9qlV9/1Wq/1XX/1X/AFX/VVX/
qlX//30A/30o/31VVX1Vqn1V/319VX19qn19/32qVX2qqn2q/33X/33/AH3/VX3/qn3//6oA
/6oo/6pV/6p9Vap9qqp9/6qqVaqqqqqq/6rXqqrX/6r/AKr/Var/qqr//9cA/9co/9dV/9d9
/9eqqteq/9fXqtfX/9f/ANf/Vdf/qtf///8AAP8AVf8Aqv8A//8oAP8oVf8oqv8o//9VAP9V
Vf9Vqv9V//99AP99Vf99qv99//+qAP+qVf+qqv+q///XAP/XVf/Xqv/X////AP//Vf//qgAA
AAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAtACWAAAH/oBKgoOEhYaHiImKi4yNjo+QkZKTlJWW
l5iZmpucnZ6foKGio6SlpqeoqaqrnT+sowCxsrO0tK+YL7kvP7s/vr++Tj/CTsVOt5a1ysrI
kbrPvL69wMLDw8bYxc2Py92y24seL+Liz7nRwNTXxNlaTu7u4Ine3vKGHvjj5rro0z9A1qyx
y/auoJaDWuwRAtClDkOHDR9KjNhFoSB8+cjtewGDF8B/6Z4IE+mEZEmD7xCqtAjAYSwuLrvQ
kSUzVkN7GDHqK5cLRi4gvXZ9BOgEyMijxUTCewIvpcqD8hjiyUJz5kM8NutgBUfAQ9ecGn1y
7LnrBcChvoz+eLLupLEt/ga1bHmqxU7dhM1axqIKMWYdin+bEfgKVtwHfWP5dfyx+CPboknd
ltSi1Mlcp0/t2tmMrCFMAFwAZMHjGaLVlrcGdyWM7zA5n2J9Av3XCy3ktcZEknR3We7BuXI1
19Vs55XohxH5dgGA5SGW5axUr8bX9QNGGB7Ekv0pFCRRo0Z1n1QqEq7v3wiFbx6+ubiq0fCn
ym+Y3Pkq6dM9WM/nmqxYoGd5BxJbj4lHElNMUYbegnfUtUV7ELqHynFUVXhccxgyx1Aq+E33
wVfWuebTYbBxxBhtARKIm4GTlWfZeXPNZYeMD0bYnhwSlhLfjlNRSCEdqKj2wGoPeNWaToe9
/kDiWACiOOBauIU3XotyvRgjepvVaMcdm3FpB444nmLhmH/RkQVMGWZhymBDDumBmwSE2JqS
dMZmYkcdBQjQE+Dp9oR4cAVqpW80zphle17i+OWXcuiIYRYYdoHFX3Vk0RAWlgJJCgFDcupV
kXEaeeRhS8IA24l5AnEWn2uFZ+CfliF45axaNGholxGCqSsp8PVaR3OQynRmmWqOwumxH4L6
oX7MWldndmOZypiq3u3p6lp+xkrZrLMaWiOXXnIph7iMymHuKFn0OhUX6aLZEKSWFhtKm566
WaR19zKL3b4cnQqDnqpaWxSB2W4hq2UGE/rgwlvWimuXYM5R7rmh/mAKL6SVmpkupmj+Kgq9
yep3b6j7hahkiaZyBOC/KQLB558wx3zwFjHWHBzD4OIqMY47m+tzo6DAp2GwZ8KHaRfBzsvp
AyEXma+cJpPab78AUhuwqgRjW1J5fxpM87ZyzXXHFg3mbLaiPZs7x89AewIvpnBjbPFUmJoJ
SptOO/1Bvk/rm13KpuIJxL//BPyyyy7L3PUTczFO8+O1Lly22VtuyfO4bJvrRtucvL1xFhrH
LfonD5Se95shfqC6fqtbB8MH/AauMuFXY42t4oznvi3kj0teK+V3YB485nKs7fPmm3siOtHL
X4yFJ6bHWfreqjPdbOrZkRo44IPXjjXi/i/j7rXjvdM8I9m/b3nH2cEPb3zxaiPvRifOe758
3J2YzvT+IVqv+v+uU93Jpmaq7hnwauETX+7K1zu5jG19k1OfHSTWPvjBz3jIkwPyOHE/+3mQ
E/qjHv+YBsDWvS57+9peAVmGQPAlTnHjoxn5aPZA9EFwfRKcQ/DWtsOfvUGDQHSDEDfhwQ6O
ThMhHGEJAaif18EOdn9T4QFrdzgFek2GDCSbFm+ovvZJ7IsXtKAb5iA/Ic4vE0YsIryQaLq9
8W+JAHTi617XL9gFboqGAx/uFndFBtbwhuBa37i8GEb4/ZCMGnxDGdEIqTTeLxNJfCMJlyjH
J5rKjlJkYQsT/hizGGKxd38kGyBvOC4eXnBta0PeD83ISkxgYQmvfJ6aYqmEWTbBCky4wvMu
EUnq+ZKSqpujHTF5R01u0mVQ+FMyn5DMLUBBhlzI4h9H6cU78HAOqITfGLepQSEq0oxquATc
xtnIcmLBCpBigrwqYToI7A8EvwSmJYmpwhV6j09QQKbMnrnAZ/YummPbIjXXp8MvojKbbyAj
IhX5TXCe0RJqimgtJyrRLOTynLx8gDv3BgL+wfMDHw2mSLdHz2LWLgiqyiczYZZMfjrzpTSL
JigfOFAdWnOC2DyoITVIRjc0lJVqeOgksIApJcANnUw4p0UxhUuLWkKj04MA9aT6/tGQguB1
V/1ADOZYT5N2D6Up1eMyl8kFxvlzCzIFKBfGhgeajrKg2LRm8VCZUDn8kKGJ9GZQ3aCGcFIC
lrWUJRPQWcvBzlKi7NToBzYqVQBaFauv2yrstgoDymYSCGDF7MuCsNLOPqGsMJUpWmPKVlG+
1ZqoxeZcVatQn9rVm7Dlq2wrQctZAlaWRr3lYHc5Cagq9gHwpCpIVQdPyGp1jpS1LGWBEANV
ZRasKm2pMj9L3dGOVqZ4EOgd2rpdgqbWmjll7V3t+tpvfjOo6O0rbWeZy6TCcpa41GUT2OlO
qbqzo/DML3G1CtLI+tdUyv1XZbv3L+giEwhjXSk/uVDW/mimlWbZjTAEuetduIY3p3adw119
ymGfBnUNsu2rXyPxPNyeU7fxba9RrUCJ+i72xfgdbn4he9UYHHeryS1gcwsMA7AaOMEtfemC
r4vWO6x1reujsHdTe2G6atiuDOVwQ0GcXvVOYpYTNepES2xUWC5hEvVVrH1lTGYQ2HirNa6s
mpPL3DY317lhzad05/xSBhPZwUZeH5Lbyl08wBW8F07oGAW9YYaqQZHoXYOIRwyJV2qZllaY
r0S5LAmodnTM+tWvja+aZhwDeMDN3TFKewxnznJWztJt8Gef6eDRRngLElYyHQjq5ybnNKF3
ZWiUPewGRfN10UOd6BUGqwQU/iuBCUqwwhKQLQkI1BcCwQVBfqUNUk6fGQadriyO3dzmIJAa
pSiV86mZmUwuQKHBrWZwNF/N5+52t606pIOFw5vQJ79BkRqW8qH33etFWxkSgD32sVk8WMAO
O9lg1ih+ob1YalM7BvCEOLZjgGOKqzkIW/U2uL+NWQR7vKUgp6650WpnB3NBwmttN7z97GdA
N/neGsZ1lN+wb5r329+MdsQun3eFYhNcEDtfdiSeDW3gAnfa1bb2xLVd8R5nvMcaB3fHwx2E
kEPhmVcfecnVneeTp/zdd5j1HFo+B3mX/dYajjkZdU1zRVJZ0X2FuxrMkHNHFIvYPlfCl/HO
Ykg4/rvoIIC2tAdf7U1D3OKIxzHGnR6EqE9ds41n5qmvzkytq7vkaMXDkcHebrH72ez0TrvM
731vn7q93zcXMd3NQOJB9B3vz2PxfJn9iL/fF9oMd/jgKV5jM1M88aHeeOMxO/zGmxrVIB/5
uS3PYM0bGQ/Q3270WR52a4Ie9KKPeelJX/N9w13uc5+7JHD55dcPAtks7nvtnd1wwSd992bW
6uGBH4Oo19/4xCe+uJ9QdZCfG+sMtnzqlnknl2fTx2djV3bWd3bYBAfYNHqkp2vd930idgbh
x3qQMF+CgGzl92UIt4FD93eBN4KDB3+H53v0h3Eq2HhQZ3yNl09Vh2CU/nd1NGhuAXh56+Z1
z3eAYcdyCYh9ZgdzQkh6PgVib7AGNKdocrcGqzd3GDh+5xeFHhiCuId7JXiFJ/h7WkhxKnh/
9+eCkfeCVVd15JZ1/4eD6qZ5agh9PEgHbTVr8haHDIhraheBEbgGIKaEaqCHfbV6ZvCHkaB+
nGB7JHiF0gZxZuZ7KPh7Xdh4X+iCUCCGkUhu/VeDyyeAzZeJ0HdybMiGPShvn3d2dPAGozgH
DmiHpJeH/ZaEe9hXFmiBfyh+yECIVliIJjh/W8iF9feIkCiJ/VeJZmiDaKiJa9iJn/h5oSiH
aXeKqHiEvXaER9iKFOiHfwiItyCCtSh48JeI/rnIiLsIhuAYieJ4dcBoiTeIg2rIiZ3IZ3gA
h58nh/JGiqaofc2IhHm4h3rIhGagj2dQjU/ICrRoiyU4f4vojY0IjmM4huRIgwx5hpiYhl63
ievYjtDnhmUHj/NYivfGjKl4b3mIh/i4h/vohPpYjdcoghFQiCGwjbjYjQcZjgo5jg0ZjA95
eWuojuvohnH4jvCYUHBAis14hPYIknoIi6/oj38oBq/gbClphStZgisZAyFAcVMZAzJAcVcZ
A0JQfzJgfELQiwpZjjMpjAzWBeoGGuk4kRRpke1IB255dg4YlxD4k9A4lPhIlGpglEhpBmLw
j4mQA4IAmDwgCDxw/gSEYJh+FwHOFgLQlpIg8JRROZUgkJVVmZUq2JWN95WZ2XhRUHWdCQVR
MJPmCAVmqW6lqXkAoJZruZZv2ZrzKJd0SZf2KJRCKY37eJt/2I/+qJSOMJhKYJiIWZiDOZiA
CZiM8HeMCQKOCZnwJwOLmJVWGQSYGQSaSZ1VJwSR+Jk0GJqgaYldIIBmaZaoqYapiRWdqJNt
GYdxCAejOIp0+QbviYR1iYdKiIe3yYT9qJtmcAZ9yZuLkANJYJhJMJg78JtJIAhGIAgH2ggQ
oJiMCQErCaHS9pTO6ZxYOZm/15VaWX9buZnXmZ39F5rcyZ1cEJo2GJ6X1wXkyYblSZGs/umW
MPqWcWmKQLmRHimU9niXe3iU+1mN/MmXfNkIggmcSjCkxFmkSLoITLmY0MacjzmZZlaZVjml
GvqVWmmd1gkF2OmZVzeiV/ed5xYFXPCdZTmm46mi5pmTbZmerUmK7AmfcPqTPzmbQ0mfinYG
R5mfuZmUfOmfiACgBlqYBaoEOICgg5mgPLCgiqCYKZmSjLmSkPqYEFehUkmlu9ihmvmVX9mZ
2ImdoYmd3Qma5iamYnpuKDqmoREa0Fee5akVLxqjdMCecumeNkqndkqfeXmnt6mb/SgG/dmX
jGCkv1mYSCqcSIqYitCgDaqcTxqpU7mSlJqVV3mVWykE1Yql/psaBJ/anSIqqiYqpqiKquKp
omjJqqv6omwqo6YYq3FKenCAhGyAo3Z6Bvi5Bnqqm33Jn/35n0kAoP7arwNqBDyQoIUqsMia
CIzKrI3arE9KqVMpA9MqnRtqnZraqdqqrdzKrSVKmqRZoh5bml2gouRqnqyqkwCgk7Aaqyor
p+36rkf4rreKq/R6r7kpBvrap376p8cqnEfAsz6rqIiQsAvrrJL6rJU6rVMqBF1prRRrnZ25
rd3ard9plmKKouFJGlihqqm5tW6oFSgLq7L6miw7p+8Ks/KKhzO7jzRrs7/qq76qCP8atwAr
tzlgnImgrA4KoRLqrEc7rUhbrRta/rHU+bQYG7XeyrHh2bFWi7VbS7LQ57UnSwd1kLKyGqtj
C6drYLYxO7N5SbNjkJSf67Zv+5dIWpyle7qAWaiLwKgh0KghAKmvO5mvK5UV6rfUKgMVW7Fa
2qlR8LS9C5q9O6ZRQLXhiaIMkZrL0bipqRUnG7mUu7JxCgdymrm2Oq/2aq/5ea9iELrbK7qK
UKjgO7DiK7DkywOFmgO+ibAR4KARsJLtC7vPCrGT6bdWqbTSqanUqam+q62/27ukOrUlWrzi
KrLK67he65aTG6OVK72Wy7LxSr1sgIcRjLbXm716+rmhOwaiO7o6iwOpmwNHsAN1K7A5gAM9
a8Kqi7AN/vqoEAq/slu79Iu7Wrm0uMu0QvC0niqiUTu1wyvAIbscoQEasoAVsTATRuy8CeyW
CwyfDgyfa/DAT0yfM4u9eLqf/YjBfKnBG+wF3/vBhFqY53u+O3AE/rq66wuh7/u+jxm7MhAC
MAyx01qtNmytm3rDNwy8/tsF/1u8AizE5BoLRIwHWjHI7Ti5SbzA0iu9TPyT8frAE2y9eJq9
+4nFWty9bsvFf9mvOWAEI8wDJQzGICzCOTCo6ovGrbvGaxy/DwvHVom7rjzHdXzD/Ou/wEua
w1u1wzumIcsQy5G8W/vLhJzAh7yysiqnjPwGEfyuj0zBeErF+UnJ22sGlSwG/l6Qs4VQwqM8
ykfgwf3Kzdjcrwd7COu7vq37uu/7uq/bxuoMsa0MsUprrTVMx3bsvzesw7esxyHbwz/My0IM
yLPAvEZsyDA6ucXcwIrMBmUbxRKMh2hQwZEsyRjMtltMzXALzh5svp3swWFcwmZczu17zuis
zm68znD8zlopz9YaBfNcz/57y/f8wzANxDRBC1gxyJJ70zeNyIl80AndyAo9xQ+dvWMQ0fqq
wWNQzUjdxR48xt7swduMzedrxh9dzuiczlZN0nD8yu+M0ird1S3d0vgc1vu8y71M0w4huS1x
0wkMB3VQzDvNyGWbzAttr2wws0GNp5/LnxGtxUhN/s2Y/KcaDdVQjdEDW8IpHLTjTNVVHdJu
PNJZ/crxLM8qXc8sncf3rM8wfbzL4BBnLdAJHAfE/NZwgNAI/cTIrNANbdd3bbNGLc2W/AXU
fNRe8NeHoNFPHdgi7MGc7MEcrb4fPdWL3dhY/dhbHdkpPc9f3bv4jNljfby+PAtH7Nl0ANrs
GQeincgQfNoRXNcOfddjcAYYrNfdC9t+7de0fc1Ljc1MXcK3DdVSDdwgfdXDDdkofdxendx6
rM/MTdbK4BKcrdY53daWa9CkPdqjHcUT3NBooNp4zZ/gbdTdq8FecNTmrdSCHdgYjs1STdXx
LdyO/dhabdwrfd9g/dIx/u3ctODfJ1sHhmzIbF3dbp3Ipa3M2/3E9Jrad93gGDzU403NYvAF
s33e6H3hRI7hZtwB7esAr9sBS77kbewCbuwCECvlMuADuOsC1uoDWX7DPqDSTdC7Xx4FX94F
TaDHloI0IWsporEclMLmsdDZLS65bB2rbS291i3jBs4Geo7gNk7XeLrgDQ7e0mzUEA7bsD3b
X2DhGY7hGu3Bq+sA66vkEcDkIUDpHfDkUR7lU37lSqvlQuDpXS4ETXDDYV7qvZsFw1vmaI7m
a/4XeqEXLN4SLA7g1E3dO43QeZ652x3BCo69gB7J3z3Uwh7h1XzoQC7khNDohr3sOLDoh30I
/pA+6e2L5JXe5CEA5TJw6TJA5VIuBFhe5Vuu5VGg5aNe7mAu5mSe7mgeL2ju6pwN65zd4iz+
4gJ+53cuvaRN2k9c4wp+Br+u4+Ct1xA+BoaO1ImeCDhwAoZtA82eAzWAAyvQ7BEP8Y6+qA4A
6UjO5Bqv8dne8S5w6S4g5SHv7VruAlp+8uQu6mIu5l/e8uneBKjO7pbyF1nQ5vEu6yzu2fRu
57ee56Ot59vd62dQ15EM6MH+4MI+1BNe7F4A5HDb7ChA8VEf8Qxf9ThQAzmgAosA6UruABk/
6dXeAZc+9tte9lJu5ViO5Sj/6eNe7irf8mX+5ZYC8+ueLkhDKTUv/us4P+ssDtp+Dwf23vP5
vuu8vgZoQPQLbvQBn/QRftQE/+Oz/b1RX8JY3+xYrwI4gPkqkPVYv/Vcn/FeL/aVPvYdEPIg
H/LbPvImv/Y+0PptL+pNAPcsnwWxjzS0b/fpkvuUEus5z/ezHgd18Pd1Dvg+D/TGb/h1XdeA
/u/B3vzD/gUUfuwHjwjNfgIUrwI2sPkqgPXc78Hbv/UR4PXiP/qjL/ZjL+WlL/Kq7wNqv/rk
7vpN4AOxP/+xH/MwT/e5n/94v/u9n/Ns/feAEEcXB0cIx0bIdqjI1rjWeMZ2hraGdnaJNnap
OdbZKebpNfblReqlhJqqepKDg4JTswKr/mKDQ6uSc4Jjo6Lqi+oQ7NAxPNxxjOzSoezS7Ozs
4+ITPV093eTThK3N3Z3V9J0VLk5el2Vel66uHlcn2F4YHx/HWN94H4kmacm/mcnpKdQoMaRI
/VKFg1UNFTUS5lgYK6ErWzUOqhJGzBgxZMmWLXvWjJo0a9W2ZevmTds4cORaolu3Dp67OvPk
tYFzaNG9e/oooeln6QyZMwADdhL1hWCpUhZRsdL16pWuFQ2fOjzRNJWwYhs5emQGFqRIktey
mUXJLRzLceXOuY2Zrh28OHRrHqKHaOfOfJUm+bWkaWgnogG/jEJ6KqtEXQxl6bKqkGFWYME2
avTK7CNIaZzJ/po9q+1k2tFXwF0Rd1rcy7is586teVNRm0Y6G/Ws9PMv0UyECXsyjLTg5Ke5
eNWAPPHErclKtna97PFrWGgjR5Js0mNb9iZLtHVfkgU8+CanyZOLc+5KHfUzZ8qlSZcQoZv0
6NXe2ZNfv6FCiZIxatgoSX1hUFaPMYQgVMg9xpwDDTjAAYQQdsABhRZy4AKGGLbgAocc9uAC
iD34MGKJPixxzXbdcecdN+KFl0VqqWWBXlzn0OVOfIXIVwgid+mFHxv6TLLPfv75BuAYpQhn
oIKuxPLYYygsNGWDDhYT4TEVaskMhspw2AyYIXJmYonYnXlii9+V9iJ4p71pDnpy/spF5yA6
ypdXnrPplZ+QQI2RyT9j/PfbKIYSmFhTjy10gnLHRZkQQ8oxp8SDD0ZYYQMXWthCB5162GGH
PrQwKommlnlmD92pyuJ34i1xmpsxxnianDnmGF9ddbUxHxx74sWTkMLqNwmg/Q2KZCeGEcik
gSg4CumzrjR6glSUXonphBVu62m3oH5bKqmkojoiiktkt4Sr6XIHK3dXvDmrnOpdQWeuufpa
Hxs37dkIv/n9lBvAgCI7qCf/LSsggcxF+Wy1japA7WKNUmqphJhuWuGnnm7oYQvi9jBuDyWK
fKKqJ57L7rrppvsueW++S+O89dq7I6++3jxbzsH25Kd+/oAGWnAnhCJM4GELN8roYsc92vBx
FF/aQAMcYDp11S1MfXXHHX7o8agih0iyqiSfu7KqK698RXctw/xurfTSa2+uPvKqM7/+9gxw
3gMP9R+hhRbN7NEQU0v4CSs8fBzElFYatcVTazo1hRp+mrXHHofYAsgkisy5yGSLfXbosI7e
dtsxxwE33PbyGgev+vqqb+yNpDEs3vwASkYmfQs9KNGBH03to402fILwEz8tdfIcQF41B1k7
X7nlloNMfeedf4692WenXXr3qH8fN+v75lV37G30mTfAuQOte9C+/z5c4fLPjxXyUS/ffP5Y
Qy/99JlnXj3rcQ57oiMd6br3/jbwxUd8+GqDA2Gns2GdL316Q8N/2keo/4DhUPBrEv0+WD/k
4U95+XueCfvnsQACcIBi6wESVKWDJcQQCduDFQLflrrW6VCHdCOfA82HhvNN0HYW/AnfyLA7
Qm3QMGDooAdBOL/FMe5+JNSfCfknPZD9L4A6EFkXu/hCGYqRhkug4RWQwD0beu9dvLqC+HhI
tx/qLIjoSwMFczco3SVxWWRglsIoBcUPSpFxy6ui/pznPBZIT5EtUGQPWPDIHnzRi148lw5i
OMN0kRGNsELju6rwSTbSqwp0iWPrcobK2KVhNnScYPpyB0sLJrFgS1zWF6QYSPoNsgEMiNoG
GvBL/g4wgAMbICYHWEDMFmzgaopkpDMj2QIdZG6SXwSjCzFZxmwuoQo29OQVQOnGcJ7Sjad0
YDn1NRvasYF2aLBjO/MWSzz2DYm966M9CQQGXJ6ABLkk3CB7ycvkFdOYUxuoMpl50EYqVJrR
hKQOHCpJSYLxktfMJg05yU1QajSUoGwDKUnpwDjK8Ye0awPt3PnOVxYRiSwtmAZH0UQnGigD
J8gACWxK05vuk6YWqOlNB1mpXv5yqMA0ZjE3sMykKrSZS5WmUx9J0aheUgdImOFFLbrNrG60
o+EUaTlDSlIH0tGOrnzn+mDZUnres48wvaUU+TmCwum0USbgpwmoBdRe/upVmMYc5lGPSUxk
ClaZzSxsQy8ZzakqdqIvRIJjy3jGyG71m26sQhsqK1Kw6muVY6XjO90ZT7QOap73bGJMB0lT
npqgp3clAQZ0ilPXAlUJex0mAzbgV6QSE6mEPSYLNmBYFrDgocNV5CWHu1iqKvexzHXsGTOq
0SpI95seBat1TZpOIXYWpWVQnyxZCt4vrBWfQIUr4Xqa05zedZ8hlCID9PreoeoWqcX8bVJ/
W1jh6re4D+2vfxVbVce60LHORUIV0Dhd6Wq0upa17HVXuU4hpsGOFP4JaFeK1rSW9gunRe0J
LJCBEdj0tSeoQKNM3NMK0HS2tI0vMG+bW/oi/hW/wMXvfm/MX+T+95IBJjBzD/xcAydYugx2
oIOxi90Jm/SzTCaDHZ2MxO+qdYNgIAOVOTxb1+5UpxYwAU4/7NMSs/i98YUxUm8rYxnbuMY4
Jm5/U/DQGwB4uVT1sYHvrOA8E7nBYF2ln026znZOuMlpyF0Zogxella5yhxudD6BOmIti5if
XXYtCVa72vb+k8xmRnOaabxmHOv3BiyAMwtIrQM5y5nHdbbzgfF8YD17lM9toIID/0zhCVeY
wk62YKGlDN4q27OJfXx0eWMb6dciW6cVYHGLy4xb+npazcCt8QZSIFxsa7vUOsA2qVV9yRsE
uNWuhrWe95yGKuDa/qRKHrS729nr7iZ63lYeAxiofG+3AtXE/AZzT7sMcEz31NnPJnO0p70B
DQBX4RpgQcNTANxtS/zUcP52qi9ZBB1k3M4EjrWQ80yFKtha3epOsp/dnetC21He3T00GVyO
xEVb2cqmdfa/PyzinGfg5v8WMcFpu4DbLgC3DE+40Y3+24Y//NqlLrW2U3ADb0P94qveeMaL
4Fisx7oI0kVCyEMuco/aOt0nZ7euz46G7qr85d+F+cxl7miCAxzFrwXxCOZeYps2m+BBZ8DQ
GaABwAPe6EXXAMQPf+0UPPzpKZB6t8F9g42LO+sExjrXvS5dsH9d3SGfMBXODvp3qh3K/ix/
+bxlfu/Uy53uJLDAa1VMAthXAOAZ+DnQ/e73DQx96Azv/bU1oPTDK77xxCd+1FUN7iKIW9yW
RwLWqWBgrnN9850XeRrGDnpdt7MME2456ZHo9rfTPN/GZjHA71731+t9xBaIve2VsICgB34B
GuA9/RMOfPwH3/DDL77/j498cnZ1V+d8BQh9B1gF0/d1VPB5nHd92dd9K5d2aXBoFchSLod6
i3ZvtmcBs7d+d7d+FnB3Hbhz7xd08Ud/gHd/wJd/LKh4wDd8/Md/xQeAUHcDAniDSBB5Bdh8
0peADChyQMiAD/h52cd9Ksd9h1ZoLmeBVlYGGah6Pzd3FtCB/lU4e+h3fhbwfvAXf35Xf19I
fywohoYHg2TYeDNofDZ4g2u4fFgXeUUAh14Hh1RQBF9XhwtIhLpWhBQYgdz3ckv4ck0YBjE3
flH4c7MXcCn2YRjQgbFHhYy4hVxIfyj4hZU4hmU4fBeQAiWQAppIg2q4hsoninEIh6X4g3LI
gKmoinnIh3yYhH9oekyIRIP4dqm3ge9nhbk4exVwU7PHiHcXiZI4iWB4iSxYAsCniZqoAce4
ic14fKDIhqL4hqXofHRojaqYitf3eZ93hElIgS33jYEYi8I2iGAQBhoYibuoi+uojsEojPFX
ifR3AcioAfNYj524jMnYeJy4iQDI/oaRB5ClKJB1OIfXiI1DOAVpkJBlQAVJ6JBlUIER+XJg
cGjleI40F4xVuFrqeHfqyIu76I5cqAD1N5IjeQHySI/zqJL4yIklwI/8SANQVwL/KI1wOI2l
SId3eIepmJAJyY0N6YoOKY4QOZEVaWUXeYvpuI6M6JG5GJJKoADxN5L0F5XzaJL1iJUXoJX5
qIwtmQIxeQMzeYM0EIoBOZAEaY13OAUMuJZsqZBBCZHfCJFzWYEUaZfmOH4hyY57CZJPuQBR
CZgaUJL1qAAqqZUqWQLJ6JLNyIlhOZZrSAPKF5mjOJBEUIdEQAVToJZs2ZNvOQUPSZexOIhP
+IQWmZTB/tiUqbmOT4kKgHmShVmShnmYs6mVx7iYLTmTM/mVN0CWvCmZRWCZwQmcdIiZdbiW
x5mZmamQZfCZckmXdDmIYVAG0UkG52iOrLmL2dmB2lkB2smaremaC3ABsDme5UmbiemSmuiS
nBiT7cmb71kEkXkDRPCGlgmHlkkFmKmfyXmcCtmTzPmcdEmR01md1WmOB/qd3bmdC6qgDZqd
3wmeCiCh5FmYtHme6nmbLumYZMmh70mflhmZwqmZ+7mWRHCcU4CiAPqZAPqc0kma0Xmg5wih
FhAANNqBBjB7NTp7CFCFPCoBEBqhsCmh5Umes4meF7Cei0kDuUkDHRqZZAmi/sAppcGZn/k5
BZiJoif6mVsaoC4qnWEQnWCKoBDanbuoo2ZqARJQATgqARaAAEAapEJKpBRgoUiKpOi5nl+5
pLzZpHz6ofM5pUQQnFeqmVmamVnKnFzKol76omIqpnBaowGQnTh6pgmgoAjQpnAap4V5ABfQ
qQpAp3Ram3aapC65pDPZp036pERAA4LaqoIKnCYKnIRKq1maoorKqGA6nec4ndcJp7tIqR3Y
ppiaAGrKppaqqa15AArQqcvarBQAqloZqnhaqiWwpNeqqnz6pLEaq7Bqot9qq+HKpVIAkbr6
pWLaq2GQrJIqqZRaAcWKABNQATUqAQhQAfWarKng/qzM6qnR2qmiqpUiQKqliq2q2qSs2qoJ
K6gLC67gKq6fSa7kGgZT8KW7eq7qmq9rOq85urH1urHxCrL5qq/MegAlC63/egHTiqQUUK3X
aq0Gq6qsKrMMS7O0aqK2KgUoGrHTabHmCqYiqwTturE4iqPFarT1irRAq6/OegAU0LQpC7Us
y7IlIAIuWbWm+rIve7AKO7MMe6UOe6U5K7ZlkLMTGwZScLE/q7TsSqMby65uq7E4qrRL27TP
SgGhmrIlwLIXcLUuOQPWqrUwy7U0u7Bha6JDoLNTILYUS7ESC6aPO7dB27aRSqMTALKWi7QI
EACRS7dOG6rTKrVUK7pV/ksDIrCkMwCzCCuzryqoQ3C4h6uzi1u2UoC2aHu2ahu57Kq784qp
AcCulGq5nKsKJuu5KXu3eku1fCu6VHu6TYq6z0sDQxC90UsEruu61UsEUnC42iu23du4t4ux
wuu7NBqp7AqyAVCvvjuvwusLnnu3d5uyIsCyVUu/pmu/pUsDqNuk0suqrjsD2Iu9risFiIu4
tKu4tIvAt8u+qbC76msA6OvA7eq7C9y+73u38qu38isC9Cu6f6u/MwC9MyC91lu9JKy9Q8C9
BYzAtHu2FMzA4+u7Mcy7MSwB6ru5LlzBF0wBGFy/9+vBISy9/yvEATwE1pvCtIvCCIzDqqC7
rkLruwZQwzMcw0v8C++rwRuMxVQrAjOwxc8LwvkrxEPwv0VcxCU8wCiMxkpMxS8cw20cAJob
AA8cAJY7wWtcxRq8w1i8xfbLxV4sxGEsxiVMxmmMwnbsC208rzTsxopsyE2hx4/cxyD8xSAs
xpU8yGQ8wI18EIvsu3DcyTXcxprMHBscyV0sySJMyZZcxKKcFZzsym7MygQ3A7FMy7Vsy7eM
y7msy7vMy73sy/kaCAA7
}

proc colordial_create {win {cmd ""}} {
    global env cdInfo

    frame $win -class Colordial

    canvas $win.dial
    pack $win.dial -side bottom

    label $win.label -text "Color:"
    pack $win.label -side left

    frame $win.sample -width 15 -height 15
    pack $win.sample -expand yes -fill both -padx 4 -pady 4

    $win.dial create image 0 0 -anchor nw -image colordial-wheel
    $win.dial create oval 0 0 0 0 -fill black -tags hsval
    $win.dial create line 0 0 0 0 -width 4 -fill black -tags bval

    $win.dial configure -width [image width colordial-wheel] \
        -height [image height colordial-wheel]

    $win.dial bind hsval <B1-Motion> \
        "colordial_set_hs $win %x %y"
    $win.dial bind bval <B1-Motion> \
        "colordial_set_b $win %y"

    set cdInfo($win-hue) 0
    set cdInfo($win-saturation) 0
    set cdInfo($win-brightness) 1
    set cdInfo($win-command) $cmd

    colordial_refresh $win
    return $win
}

proc colordial_set_b {win y} {
    global cdInfo

    set bright [expr (145-$y)/140.0]
    if {$bright < 0} {
        set bright 0
    } elseif {$bright > 1} {
        set bright 1
    }
    set cdInfo($win-brightness) $bright
    colordial_refresh $win
}

proc colordial_set_hs {win x y} {
    global cdInfo

    set hs [colordial_xy2hs $x $y]
    set hue [lindex $hs 0]
    set sat [lindex $hs 1]

    if {$sat > 1} {
        set sat 1
    }
    set cdInfo($win-hue) $hue
    set cdInfo($win-saturation) $sat

    colordial_refresh $win
}

proc colordial_refresh {win} {
    global cdInfo

    set angle $cdInfo($win-hue)
    set length $cdInfo($win-saturation)
    set x0 [expr 75 + cos($angle)*$length*70]
    set y0 [expr 75 - sin($angle)*$length*70]

    $win.dial coords hsval \
        [expr $x0-4] [expr $y0-4] \
        [expr $x0+4] [expr $y0+4]

    set bright $cdInfo($win-brightness)
    set y0 [expr 145-$bright*140]

    $win.dial coords bval 154 $y0 176 $y0

    $win.sample configure -background [colordial_get $win]

    if {$cdInfo($win-command) != ""} {
        set cmd [percent_subst %v $cdInfo($win-command) [colordial_get $win]]
        uplevel #0 $cmd
    }
}

proc colordial_get {win} {
    global cdInfo

    set h $cdInfo($win-hue)
    set s $cdInfo($win-saturation)
    set v $cdInfo($win-brightness)
    return [colordial_hsb2rgb $h $s $v]
}

proc colordial_xy2hs {x0 y0} {
    set wd 150
    set ht 150
    set margin 5

    set x [expr $x0 - $wd/2]
    set y [expr $ht/2 - $y0]
    if {$x != 0} {
        set angle [expr atan($y/double($x))]
        if {$x < 0} {
            set angle [expr $angle+3.14159]
        } elseif {$y < 0} {
            set angle [expr $angle+6.28318]
        }
        set dx [expr 0.5*cos($angle)*($wd-2*$margin)]
        set dy [expr 0.5*sin($angle)*($ht-2*$margin)]
        set len [expr sqrt($dx*$dx+$dy*$dy)]
        set hue [expr $angle/3.14159*180]
        set sat [expr sqrt($x*$x+$y*$y)/$len]
    } elseif {$y > 0} {
        set hue 90
        set len [expr 0.5*($ht-2*$margin)]
        set sat [expr $y/$len]
    } else {
        set hue 270
        set len [expr 0.5*($ht-2*$margin)]
        set sat [expr -$y/$len]
    }
    set hue [expr $hue*3.14159/180.0]

    return [list $hue $sat]
}

proc colordial_hsb2rgb {h s v} {
    if {$s == 0} {
        set v [expr round(65535*$v)]
        set r $v
        set g $v
        set b $v
    } else {
        if {$h >= 6.28318} {set h [expr $h-6.28318]}
        set h [expr $h/1.0472]
        set f [expr $h-floor($h)]
        set p [expr round(65535*$v*(1.0-$s))]
        set q [expr round(65535*$v*(1.0-$s*$f))]
        set t [expr round(65535*$v*(1.0-$s*(1.0-$f)))]
        set v [expr round(65535*$v)]

        switch [expr int($h)] {
            0 {set r $v; set g $t; set b $p}
            1 {set r $q; set g $v; set b $p}
            2 {set r $p; set g $v; set b $t}
            3 {set r $p; set g $q; set b $v}
            4 {set r $t; set g $p; set b $v}
            5 {set r $v; set g $p; set b $q}
        }
    }
    return [format "#%.4x%.4x%.4x" $r $g $b]
}

# ----------------------------------------------------------------------

proc dialog_create {class {win "auto"}} {
    if {$win == "auto"} {
        set count 0
        set win ".dialog[incr count]"
        while {[winfo exists $win]} {
            set win ".dialog[incr count]"
        }
    }
    frame $win -class $class -borderwidth 4 -relief raised

    frame $win.info
    pack $win.info -expand yes -fill both -padx 4 -pady 4

    frame $win.sep -height 2 -borderwidth 1 -relief sunken
    pack $win.sep -fill x -pady 4

    frame $win.controls
    pack $win.controls -fill x -padx 4 -pady 4

    return $win
}

proc dialog_info {win} {
    return "$win.info"
}

proc dialog_controls {win} {
    return "$win.controls"
}

proc dialog_lock {win} {
    frame .lock -background white
    place .lock -x 0 -y 0 -relwidth 1 -relheight 1
    raise .lock

    place $win -in .lock -x 20 -y 20
    raise $win
}

proc dialog_unlock {win} {
    place forget $win
    destroy .lock
}

# ----------------------------------------------------------------------
option add *Notice*dismiss.text "Dismiss" widgetDefault

proc notice_show {mesg {icon "info"}} {
    set top [dialog_create Notice]

    set info [dialog_info $top]
    label $info.icon -bitmap $icon
    pack $info.icon -side left -padx 8 -pady 8
    label $info.mesg -text $mesg -wraplength 4i
    pack $info.mesg -side right -expand yes -fill both -padx 8 -pady 8

    set cntls [dialog_controls $top]
    button $cntls.dismiss -command "destroy $top"
    pack $cntls.dismiss -pady 4

    place $top -x 20 -y 20
    raise $top

    focus $cntls.dismiss
    return $top
}

# ----------------------------------------------------------------------
option add *Textdisplay*text.wrap word widgetDefault
option add *Textdisplay*text.background white widgetDefault
option add *Textdisplay*text.width 50 widgetDefault
option add *Textdisplay*text.height 10 widgetDefault

proc textdisplay_create {{title "Text Display"}} {
    set top [dialog_create Textdisplay]

    set info [dialog_info $top]
    scrollbar $info.sbar -command "$info.text yview"
    pack $info.sbar -side right -fill y
    text $info.text -wrap word -yscrollcommand "$info.sbar set"
    pack $info.text -side left -expand yes -fill both

    set cntls [dialog_controls $top]
    button $cntls.dismiss -text "Dismiss" -command "destroy $top"
    pack $cntls.dismiss -pady 4
    focus $cntls.dismiss

    $info.text configure -state disabled

    $info.text tag configure normal -spacing1 6p \
        -font -*-helvetica-medium-r-normal--*-120-*

    $info.text tag configure heading -spacing1 0.2i \
        -font -*-helvetica-bold-r-normal--*-120-*

    $info.text tag configure bold \
        -font -*-helvetica-bold-r-normal--*-120-*

    $info.text tag configure italic \
        -font -*-helvetica-medium-o-normal--*-120-*

    $info.text tag configure typewriter -wrap none \
        -font -*-courier-medium-r-normal--*-120-*

    place $top -x 20 -y 20
    raise $top

    return $top
}

proc textdisplay_file {top fname} {
    set info [dialog_info $top]
    set fid [open $fname r]
    set contents [read $fid]
    close $fid
    $info.text configure -state normal
    $info.text delete 1.0 end
    $info.text insert end $contents "typewriter"
    $info.text configure -state disabled
}

proc textdisplay_clear {top} {
    set info [dialog_info $top]
    $info.text configure -state normal
    $info.text delete 1.0 end
    $info.text configure -state disabled
}

proc textdisplay_append {top mesg {tag "normal"}} {
    set info [dialog_info $top]
    $info.text configure -state normal
    $info.text insert end $mesg $tag
    $info.text configure -state disabled
}

# ----------------------------------------------------------------------
option add *Notebook.borderWidth 2 widgetDefault
option add *Notebook.relief sunken widgetDefault

proc notebook_create {win} {
    global nbInfo

    frame $win -class Notebook
    pack propagate $win 0

    set nbInfo($win-count) 0
    set nbInfo($win-pages) ""
    set nbInfo($win-current) ""
    return $win
}

proc notebook_page {win name} {
    global nbInfo

    set page "$win.page[incr nbInfo($win-count)]"
    lappend nbInfo($win-pages) $page
    set nbInfo($win-page-$name) $page

    frame $page

    if {$nbInfo($win-count) == 1} {
        after idle [list notebook_display $win $name]
    }
    return $page
}

proc notebook_display {win name} {
    global nbInfo

    set page ""
    if {[info exists nbInfo($win-page-$name)]} {
        set page $nbInfo($win-page-$name)
    } elseif {[winfo exists $win.page$name]} {
        set page $win.page$name
    }
    if {$page == ""} {
        error "bad notebook page \"$name\""
    }

    notebook_fix_size $win

    if {$nbInfo($win-current) != ""} {
        pack forget $nbInfo($win-current)
    }
    pack $page -expand yes -fill both
    set nbInfo($win-current) $page
}

proc notebook_fix_size {win} {
    global nbInfo

    update idletasks

    set maxw 0
    set maxh 0
    foreach page $nbInfo($win-pages) {
        set w [winfo reqwidth $page]
        if {$w > $maxw} {
            set maxw $w
        }
        set h [winfo reqheight $page]
        if {$h > $maxh} {
            set maxh $h
        }
    }
    set bd [$win cget -borderwidth]
    set maxw [expr $maxw+2*$bd]
    set maxh [expr $maxh+2*$bd]
    $win configure -width $maxw -height $maxh
}

# ----------------------------------------------------------------------
option add *Tabnotebook.tabs.background #666666 widgetDefault
option add *Tabnotebook.margin 6 widgetDefault
option add *Tabnotebook.tabColor #a6a6a6 widgetDefault
option add *Tabnotebook.activeTabColor #d9d9d9 widgetDefault
option add *Tabnotebook.tabFont \
    -*-helvetica-bold-r-normal--*-120-* widgetDefault

proc tabnotebook_create {win} {
    global tnInfo

    frame $win -class Tabnotebook
    canvas $win.tabs -highlightthickness 0
    pack $win.tabs -fill x

    notebook_create $win.notebook
    pack $win.notebook -expand yes -fill both

    set tnInfo($win-tabs) ""
    set tnInfo($win-current) ""
    set tnInfo($win-pending) ""
    return $win
}

proc tabnotebook_page {win name} {
    global tnInfo

    set page [notebook_page $win.notebook $name]
    lappend tnInfo($win-tabs) $name

    if {$tnInfo($win-pending) == ""} {
        set id [after idle [list tabnotebook_refresh $win]]
        set tnInfo($win-pending) $id
    }
    return $page
}

proc tabnotebook_refresh {win} {
    global tnInfo

    $win.tabs delete all

    set margin [option get $win margin Margin]
    set color [option get $win tabColor Color]
    set font [option get $win tabFont Font]
    set x 2
    set maxh 0

    foreach name $tnInfo($win-tabs) {
        set id [$win.tabs create text \
            [expr $x+$margin+2] [expr -0.5*$margin] \
            -anchor sw -text $name -font $font \
            -tags [list $name]]

        set bbox [$win.tabs bbox $id]
        set wd [expr [lindex $bbox 2]-[lindex $bbox 0]]
        set ht [expr [lindex $bbox 3]-[lindex $bbox 1]]
        if {$ht > $maxh} {
            set maxh $ht
        }

        $win.tabs create polygon 0 0  $x 0 \
            [expr $x+$margin] [expr -$ht-$margin] \
            [expr $x+$margin+$wd] [expr -$ht-$margin] \
            [expr $x+$wd+2*$margin] 0 \
            2000 0  2000 10  0 10 \
            -outline black -fill $color \
            -tags [list $name tab tab-$name]

        $win.tabs raise $id

        $win.tabs bind $name <ButtonPress-1> \
            [list tabnotebook_display $win $name]

        set x [expr $x+$wd+2*$margin]
    }
    set height [expr $maxh+2*$margin]
    $win.tabs move all 0 $height

    $win.tabs configure -width $x -height [expr $height+4]

    if {$tnInfo($win-current) != ""} {
        tabnotebook_display $win $tnInfo($win-current)
    } else {
        tabnotebook_display $win [lindex $tnInfo($win-tabs) 0]
    }
    set tnInfo($win-pending) ""
}

proc tabnotebook_display {win name} {
    global tnInfo

    notebook_display $win.notebook $name

    set normal [option get $win tabColor Color]
    $win.tabs itemconfigure tab -fill $normal

    set active [option get $win activeTabColor Color]
    $win.tabs itemconfigure tab-$name -fill $active
    $win.tabs raise $name

    set tnInfo($win-current) $name
}

# ----------------------------------------------------------------------
option add *Calendar.dateBackground white widgetDefault
option add *Calendar.dateForeground black widgetDefault
option add *Calendar.selectColor red widgetDefault
option add *Calendar.selectThickness 3 widgetDefault

option add *Calendar.titleFont \
    -*-helvetica-bold-o-normal--*-180-* widgetDefault
option add *Calendar.dateFont \
    -*-helvetica-medium-r-normal--*-100-* widgetDefault

image create bitmap calendar-back -data {
#define back_width 16
#define back_height 16
static unsigned char back_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x30, 0xe0, 0x38, 0xf0, 0x3c,
   0xf8, 0x3e, 0xfc, 0x3f, 0xfc, 0x3f, 0xf8, 0x3e, 0xf0, 0x3c, 0xe0, 0x38,
   0xc0, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
}
image create bitmap calendar-fwd -data {
#define fwd_width 16
#define fwd_height 16
static unsigned char fwd_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c, 0x03, 0x1c, 0x07, 0x3c, 0x0f,
   0x7c, 0x1f, 0xfc, 0x3f, 0xfc, 0x3f, 0x7c, 0x1f, 0x3c, 0x0f, 0x1c, 0x07,
   0x0c, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
}

proc calendar_create {win {date "now"}} {
    global calInfo

    if {$date == "now"} {
        set time [clock seconds]
    } else {
        set time [clock scan $date]
    }
    set calInfo($win-time) $time
    set calInfo($win-selected) ""
    set calInfo($win-selectCmd) ""
    set calInfo($win-decorateVar) ""

    frame $win -class Calendar
    canvas $win.cal -width 3i -height 2i
    pack $win.cal -expand yes -fill both

    button $win.cal.back -image calendar-back \
        -command "calendar_change $win -1"

    button $win.cal.fwd -image calendar-fwd \
        -command "calendar_change $win +1"

    bind $win.cal <Configure> "calendar_redraw $win"

    return $win
}

proc calendar_change {win delta} {
    global calInfo

    set dir [expr ($delta > 0) ? 1 : -1]
    set month [clock format $calInfo($win-time) -format "%m"]
    set month [string trimleft $month 0]
    set year [clock format $calInfo($win-time) -format "%Y"]

    for {set i 0} {$i < abs($delta)} {incr i} {
        incr month $dir
        if {$month < 1} {
            set month 12
            incr year -1
        } elseif {$month > 12} {
            set month 1
            incr year 1
        }
    }
    set calInfo($win-time) [clock scan "$month/1/$year"]

    calendar_redraw $win
}

proc calendar_redraw {win} {
    global calInfo

    if {$calInfo($win-decorateVar) != ""} {
        upvar #0 $calInfo($win-decorateVar) decorate
    }

    $win.cal delete all

    set time $calInfo($win-time)
    set wmax [winfo width $win.cal]
    set hmax [winfo height $win.cal]

    $win.cal create window 3 3 -anchor nw \
        -window $win.cal.back
    $win.cal create window [expr $wmax-3] 3 -anchor ne \
        -window $win.cal.fwd
    set bottom [lindex [$win.cal bbox all] 3]

    set font [option get $win titleFont Font]
    set title [clock format $time -format "%B %Y"]
    $win.cal create text [expr $wmax/2] $bottom -anchor s \
        -text $title -font $font

    incr bottom 3
    $win.cal create line 0 $bottom $wmax $bottom -width 2
    incr bottom 3

    set font [option get $win dateFont Font]
    set bg [option get $win dateBackground Background]
    set fg [option get $win dateForeground Foreground]
    set current ""

    set layout [calendar_layout $time]
    set weeks [expr [lindex $layout end]+1]

    foreach {day date dcol wrow} $layout {
        set x0 [expr $dcol*($wmax-7)/7+3]
        set y0 [expr $wrow*($hmax-$bottom-4)/$weeks+$bottom]
        set x1 [expr ($dcol+1)*($wmax-7)/7+3]
        set y1 [expr ($wrow+1)*($hmax-$bottom-4)/$weeks+$bottom]

        if {$date == $calInfo($win-selected)} {
            set current $date
        }

        $win.cal create rectangle $x0 $y0 $x1 $y1 \
            -outline $fg -fill $bg

        $win.cal create text [expr $x0+4] [expr $y0+2] \
            -anchor nw -text "$day" -fill $fg -font $font

        $win.cal create image [expr $x1-2] [expr $y1-2] \
            -anchor se -tags [list $date-image]

        if {[info exists decorate($date)]} {
            $win.cal itemconfigure $date-image \
                -image $decorate($date)
        }

        $win.cal create rectangle $x0 $y0 $x1 $y1 \
            -outline "" -fill "" \
            -tags [list $date-sensor all-sensor]

        $win.cal bind $date-sensor <ButtonPress-1> \
            "calendar_select $win $date"
    }

    if {$current != ""} {
        set color [option get $win selectColor Foreground]
        set width [option get $win selectThickness Thickness]

        $win.cal itemconfigure $current-sensor \
            -outline $color -width $width

        $win.cal raise $current-sensor

    } elseif {$calInfo($win-selected) == ""} {
        set date [clock format $time -format "%m/%d/%Y"]
        calendar_select $win $date
    }
}

proc calendar_layout {time} {
    set month [clock format $time -format "%m"]
    set year  [clock format $time -format "%Y"]

    foreach lastday {31 30 29 28} {
        if {[catch {clock scan "$month/$lastday/$year"}] == 0} {
            break
        }
    }
    set seconds [clock scan "$month/1/$year"]
    set firstday [clock format $seconds -format %w]
    set weeks [expr ceil(double($lastday+$firstday)/7)]

    set rlist ""
    for {set day 1} {$day <= $lastday} {incr day} {
        set seconds [clock scan "$month/$day/$year"]
        set date [clock format $seconds -format "%m/%d/%Y"]
        set daycol [clock format $seconds -format %w]
        set weekrow [expr ($firstday+$day-1)/7]
        lappend rlist $day $date $daycol $weekrow
    }
    return $rlist
}

proc calendar_select_cmd {win cmd} {
    global calInfo

    if {![info exists calInfo($win-selectCmd)]} {
        error "bad calendar name \"$win\""
    }
    set calInfo($win-selectCmd) $cmd
}

proc calendar_select {win date} {
    global calInfo
    set time [clock scan $date]
    set date [clock format $time -format "%m/%d/%Y"]

    set calInfo($win-selected) $date

    set current [clock format $calInfo($win-time) \
        -format "%m %Y"]
    set selected [clock format $time -format "%m %Y"]

    if {$current == $selected} {
        set fg [option get $win dateForeground Foreground]
        $win.cal itemconfigure all-sensor \
            -outline "" -width 1

        set color [option get $win selectColor Foreground]
        set width [option get $win selectThickness Thickness]
        $win.cal itemconfigure $date-sensor \
            -outline $color -width $width
        $win.cal raise $date-sensor
    } else {
        set calInfo($win-time) $time
        calendar_redraw $win
    }

    if {[string trim $calInfo($win-selectCmd)] != ""} {
        set cmd $calInfo($win-selectCmd)
        set cmd [percent_subst %d $cmd $date]
        uplevel #0 $cmd
    }
}

proc calendar_get {win} {
    global calInfo
    return $calInfo($win-selected)
}

proc calendar_decorate_with {win decorateVar} {
    global calInfo

    if {![info exists calInfo($win-decorateVar)]} {
        error "bad calendar name \"$win\""
    }
    set calInfo($win-decorateVar) $decorateVar
    calendar_redraw $win

    global $decorateVar
    trace variable $decorateVar wu "calendar_decorate $win"
}

proc calendar_decorate {win name1 name2 op} {
    upvar #0 $name1 decorate

    if {[info exists decorate($name2)]} {
        set imh $decorate($name2)
    } else {
        set imh ""
    }
    $win.cal itemconfigure $name2-image -image $imh
}

# ----------------------------------------------------------------------
if {[string match *color [winfo screenvisual .]]} {
    option add *Appointment.stripeBackground LightGray widgetDefault
    option add *Appointment.stripeForeground black widgetDefault
    option add *Appointment.conflictBackground red widgetDefault
    option add *Appointment.conflictForeground white widgetDefault
} else {
    option add *Appointment.stripeBackground white widgetDefault
    option add *Appointment.stripeForeground black widgetDefault
    option add *Appointment.conflictBackground black widgetDefault
    option add *Appointment.conflictForeground white widgetDefault
}

option add *Appointment.text.width 30 widgetDefault
option add *Appointment.text.height 15 widgetDefault

option add *Appointment.titleFont \
    -*-helvetica-bold-o-normal--*-140-* widgetDefault
option add *Appointment.dateFont \
    -*-helvetica-bold-r-normal--*-120-* widgetDefault
option add *Appointment.hourFont \
    -*-helvetica-bold-r-normal--*-100-* widgetDefault
option add *Appointment.commentFont \
    -*-helvetica-medium-r-normal--*-100-* widgetDefault

set appInfo(alarm-on) [image create photo -data {
R0lGODdhDAAMAKEAAP///wAAAP/nZZqKPCwAAAAADAAMAAACH4SPaRF6IURTMEpqb6pxIq49
Wfcw5rkM6hCp3ok6SgEAOw==
}]

set appInfo(alarm-off) [image create photo -data {
R0lGODdhDAAMAKEAAP///7Kystvb24KCgiwAAAAADAAMAAACH4SPaRF6IURTMEpqb6pxIq49
Wfcw5rkM6mCo3ok6SgEAOw==
}]

proc appointment_create {win} {
    frame $win -class Appointment

    scrollbar $win.sbar -command "$win.text yview"
    pack $win.sbar -side right -fill y

    text $win.text -background white -wrap word \
        -cursor center_ptr -tabs {2c right 2.4c left} \
        -yscrollcommand "$win.sbar set"
    pack $win.text -side left -expand yes -fill both

    #
    # Set up tags for the various text styles...
    #
    $win.text tag configure title \
        -font [option get $win titleFont Font]

    $win.text tag configure date \
        -font [option get $win dateFont Font]

    $win.text tag configure hour \
        -font [option get $win hourFont Font]

    $win.text tag configure comment \
        -lmargin1 2.4c -lmargin2 2.4c \
        -font [option get $win commentFont Font]

    $win.text tag configure stripe \
        -background [option get $win stripeBackground Background] \
        -foreground [option get $win stripeForeground Foreground]

    $win.text tag configure space -spacing1 5

    #
    # Set up bindings to handle appointment editing...
    #
    set btags [bindtags $win.text]
    set i [lsearch $btags Text]
    if {$i >= 0} {
        set btags [lreplace $btags $i $i]
    }
    bindtags $win.text $btags

    bind $win.text <KeyPress> {appointment_insert %W %A}
    bind $win.text <Control-KeyPress-h> {appointment_backspace %W}
    bind $win.text <KeyPress-BackSpace> {appointment_backspace %W}
    bind $win.text <KeyPress-Delete> {appointment_backspace %W}
    bind $win.text <KeyPress-Tab> {appointment_next %W; break}

    #
    # Bind to the "comment" fields to let the user position
    # the cursor...
    #
    $win.text tag bind comment <ButtonPress-1> {
        focus %W
        %W mark set insert @%x,%y
    }

    return $win
}

proc appointment_load {win date scheduleVar} {
    upvar $scheduleVar schedule

    $win.text delete 1.0 end
    $win.text insert end "Appointments\n" title

    set time [clock scan $date]
    set day [clock format $time -format "%B %d, %Y"]
    $win.text insert end "$day\n\n" date

    set timeSlots [array names schedule]
    set timeSlots [lsort -command appointment_cmp $timeSlots]

    foreach slot $timeSlots {
        appointment_load_slot $win $slot $schedule($slot) $timeSlots
    }

    set range [$win.text tag nextrange comment 1.0]
    if {$range != ""} {
        set index [lindex $range 0]
        $win.text mark set insert $index
    }
    focus $win.text
}

proc appointment_load_slot {win slot appmt allSlots} {
    if {[string match "*:00*" $slot]} {
        set htags "hour space"
    } else {
        set htags "hour"
    }
    $win.text insert end "\t$slot\t" $htags

    appointment_load_bell $win $slot $appmt

    set pos [lsearch $allSlots $slot]
    if {$pos % 2 != 0} {
        set ctags "comment stripe"
    } else {
        set ctags "comment"
    }
    set mesg [lindex $appmt 1]
    $win.text insert end "$mesg\n" $ctags
}

proc appointment_load_bell {win slot appmt} {
    global appInfo

    set name "$win.text.bell$slot"
    label $name -borderwidth 0
    bind $name <ButtonPress-1> \
        "appointment_toggle $win $name $slot"

    set alarm [lindex $appmt 0]
    if {$alarm} {
        set appInfo($win-$slot) 1
        $name configure -image $appInfo(alarm-on)
    } else {
        set appInfo($win-$slot) 0
        $name configure -image $appInfo(alarm-off)
    }
    $win.text window create end -window $name
}

proc appointment_get {win scheduleVar} {
    global appInfo
    upvar $scheduleVar schedule

    set range [$win.text tag nextrange comment 1.0]
    while {$range != ""} {
        set pos [lindex $range 0]
        set nextpos [lindex $range 1]
        set comment [string trim [eval $win.text get $range]]

        set range [$win.text tag prevrange hour $pos]
        if {$range != ""} {
            set slot [string trim [eval $win.text get $range]]
            set schedule($slot) [list $appInfo($win-$slot) $comment]
        }
        set range [$win.text tag nextrange comment $nextpos+1char]
    }
}

proc appointment_cmp {val1 val2} {

    set pattern {([0-1]?[0-9]):([0-9][0-9])(am|AM|pm|PM)}
    if {![regexp $pattern $val1 all hour1 min1 div1]} {
        error "bad time string \"$val1\""
    }
    if {![regexp $pattern $val2 all hour2 min2 div2]} {
        error "bad time string \"$val2\""
    }

    array set parts { am 1 AM 1 pm 2 PM 2 }

    if {$parts($div1) < $parts($div2)} {
        return -1
    } elseif {$parts($div1) > $parts($div2)} {
        return +1
    }

    if {$hour1 == 12} { set hour1 0 }
    if {$hour2 == 12} { set hour2 0 }

    if {$hour1 < $hour2} {
        return -1
    } elseif {$hour1 > $hour2} {
        return +1
    }

    if {$min1 < $min2} {
        return -1
    } elseif {$min1 > $min2} {
        return +1
    }
    return 0
}

proc appointment_toggle {win label slot} {
    global appInfo

    if {$appInfo($win-$slot)} {
        set appInfo($win-$slot) 0
        $label configure -image $appInfo(alarm-off)
    } else {
        set appInfo($win-$slot) 1
        $label configure -image $appInfo(alarm-on)
    }
}

proc appointment_insert {twin c} {
    set tags [$twin tag names insert]
    if {$c == "\r" || $c == "\n"} {
        $twin insert insert "\n" $tags
    } elseif {[scan $c {%[ -~]} dummy] == 1} {
        $twin insert insert $c $tags
    }
}

proc appointment_backspace {twin} {
    set tags [$twin tag names insert-1char]
    if {[lsearch $tags "comment"] >= 0} {
        $twin delete insert-1char
    }
}

proc appointment_next {twin} {
    set range [$twin tag nextrange hour insert]
    if {$range != ""} {
        set index [lindex $range 0]
        set range [$twin tag nextrange comment $index]
        set index [lindex $range 0]
        $twin mark set insert $index
    } else {
        set range [$twin tag nextrange comment 1.0]
        set index [lindex $range 0]
        $twin mark set insert $index
    }
    $twin see insert
}

proc appointment_conflict {win date scheduleVar} {
    upvar $scheduleVar schedule

    $win.text configure -state normal
    $win.text delete 1.0 end
    $win.text insert end "Appointments\n" title

    $win.text tag configure conflict -lmargin2 2.4c \
        -font [option get $win commentFont Font] \
        -background [option get $win conflictBackground Background] \
        -foreground [option get $win conflictForeground Foreground]

    set time [clock scan $date]
    set day [clock format $time -format "%B %d, %Y"]
    $win.text insert end "$day\n\n" date

    set count 0
    set timeSlots [array names schedule]
    set timeSlots [lsort -command appointment_cmp $timeSlots]
    set state "disabled"

    foreach slot $timeSlots {
        if {[string match "*:00*" $slot]} {
            set htags "hour space"
        } else {
            set htags "hour"
        }
        $win.text insert end "\t$slot\t" $htags

        if {$schedule($slot) == ""} {
            if {$count % 2 != 0} {
                set ctags "comment stripe"
            } else {
                set ctags "comment"
            }
        } else {
            set ctags "conflict"
        }

        if {$schedule($slot) == ""} {
            set state "normal"
            appointment_load_bell $win $slot {0 ""}
            $win.text insert end "\n" $ctags
        } else {
            $win.text insert end "$schedule($slot)\n" $ctags
        }
        incr count
    }
    $win.text configure -state $state

    set range [$win.text tag nextrange comment 1.0]
    if {$range != ""} {
        set index [lindex $range 0]
        $win.text mark set insert $index
    }
    focus $win.text
}

# ----------------------------------------------------------------------
set timeSlots {}
foreach hour {8 9 10 11} {
    foreach min {00am 30am} {
        lappend timeSlots "$hour:$min"
    }
}
foreach hour {12 1 2 3 4 5 6 7} {
    foreach min {00pm 30pm} {
        lappend timeSlots "$hour:$min"
    }
}

proc esec_list_add {var args} {
    upvar $var list
    foreach value $args {
        if {[info exists list]} {
            if {[lsearch $list $value] < 0} {
                lappend list $value
            }
        } else {
            set list $value
        }
    }
}
proc esec_list_del {var args} {
    upvar $var list

    foreach value $args {
        if {[info exists list]} {
            set i [lsearch $list $value]
            if {$i >= 0} {
                set list [lreplace $list $i $i]
            }
        }
    }
}

proc esec_error {mesg} {
    set win [notice_show "FATAL ERROR:\n$mesg\n\nShutting down..." error]
    set cntls [dialog_controls $win]
    $cntls.dismiss configure -command {dialog_unlock; exit}
    dialog_lock $win
}

proc esec_exit {} {
    esec_save
    exit
}

proc esec_send_appointment {date time alarm comments} {
    global env appointments decorations

    if {$comments == ""} {
        set alarm 0
    }
    set new [list $alarm $comments]

    if {([info exists appointments($date-$time)] &&
         $appointments($date-$time) != $new) ||
         $comments != ""} {

        set appointments($date-$time) $new
        if {$comments != ""} {
            esec_list_add appointments($date) $time
            set decorations($date) "pencil-image"
        } else {
            esec_list_del appointments($date) $time
            if {$appointments($date) == ""} {
                set decorations($date) ""
            }
        }
        esec_client_send \
            appointment $env(USER) $date $time $alarm $comments
    }
}

proc esec_receive_appointment {date time alarm comments} {
    global appointments decorations

    if {$date == [calendar_get .current]} {
        appointment_get .page schedule
        set schedule($time) [list $alarm $comments]
        appointment_load .page $date schedule
    }

    set appointments($date-$time) [list $alarm $comments]

    if {[string trim $comments] != ""} {
        esec_list_add appointments($date) $time
        set decorations($date) "pencil-image"
    } else {
        esec_list_del appointments($date) $time
        if {$appointments($date) == ""} {
            set decorations($date) ""
        }
    }
}

proc esec_save {} {
    global env currentDate appointments decorations

    appointment_get .page schedule

    foreach time [array names schedule] {
        set alarm [lindex $schedule($time) 0]
        set comments [lindex $schedule($time) 1]

        esec_send_appointment $currentDate $time $alarm $comments
    }
}

proc esec_load {date} {
    global timeSlots currentDate appointments

    foreach time $timeSlots {
        if {[info exists appointments($date-$time)]} {
            set schedule($time) $appointments($date-$time)
        } else {
            set schedule($time) [list "off" ""]
        }
    }
    appointment_load .page $date schedule
    set currentDate $date
}

proc esec_view {when} {
    switch -- $when {
        today {
            set date [clock format [clock seconds] -format "%m/%d/%Y"]
            calendar_select .current $date
        }
        +6months {
            set time [clock scan [calendar_get .current]]
            set time [expr $time+60*60*24*7*26]
            set date [clock format $time -format "%m/%d/%Y"]
            calendar_select .current $date
        }
        -6months {
            set time [clock scan [calendar_get .current]]
            set time [expr $time-60*60*24*7*26]
            set date [clock format $time -format "%m/%d/%Y"]
            calendar_select .current $date
        }
    }
}

proc esec_check {} {
    global appointments

    set now [clock seconds]
    set date [clock format $now -format "%m/%d/%Y"]

    if {[info exists appointments($date)]} {
        foreach slot $appointments($date) {
            set alarm [lindex $appointments($date-$slot) 0]
            set mesg  [lindex $appointments($date-$slot) 1]

            if {$alarm} {
                set time [clock scan "$date $slot"]
                set points ""
                if {$time-$now > 0 && $time-$now < 60*30} {
                    lappend points 30min
                }
                if {$time-$now > 0 && $time-$now < 60*15} {
                    lappend points 15min
                }
                if {abs($time-$now) < 60*2} {
                    lappend points onTime
                }

                if {$points != ""} {
                    esec_alarm $date $slot $points $mesg
                }
            }
        }
    }

    after 120000 esec_check
}

proc esec_alarm {date slot points mesg} {
    global prefs alarms

    switch -- $prefs(alarm-when) {
        "At appointed time" {esec_list_del points 30min 15min}
        "15 minutes before" {esec_list_del points 30min onTime}
        "30 minutes before" {esec_list_del points 15min onTime}
        "All of the above"  {}
    }
    foreach time $points {
        if {![info exists alarms($date-$slot-$time)]} {
            set alarms($date-$slot-$time) 1

            switch -- $prefs(alarm-how) {
                "Visual Flash" {
                    frame .flash
                    place .flash -x 0 -y 0 -relwidth 1 -relheight 1
                    for {set i 0} {$i < 3} {incr i} {
                        .flash configure -background black
                        update
                        after 150
                        .flash configure -background white
                        update
                        after 150
                    }
                    destroy .flash
                }
                "Pop-up reminder" {
                    notice_show "REMINDER:\n$date\n\n$slot - $mesg"
                }
                "Both" {
                    notice_show "REMINDER:\n$date\n\n$slot - $mesg"
                    frame .flash
                    place .flash -x 0 -y 0 -relwidth 1 -relheight 1
                    for {set i 0} {$i < 3} {incr i} {
                        .flash configure -background black
                        update
                        after 150
                        .flash configure -background white
                        update
                        after 150
                    }
                    destroy .flash
                }
            }
        }
    }
}

proc esec_receive_conflicts {args} {
    global env timeSlots currentDate prefs consultStatus conflictInfo

    foreach time $timeSlots {
        set conflicts($time) ""
    }
    array set conflicts $args
    set win [dialog_info .consult]
    appointment_conflict $win.page $currentDate conflicts

    dialog_lock .consult
}

proc esec_conflicts {status} {
    global env timeSlots currentDate prefs consultStatus conflictInfo userlist

    set win [dialog_info .consult]
    switch $status {
        updateAll {
            appointment_get $win.page schedule

            esec_list_add userlist $env(USER)
            foreach user $userlist {
                foreach slot [array names schedule] {
                    set alarm [lindex $schedule($slot) 0]
                    set comments [lindex $schedule($slot) 1]
                    if {$comments != ""} {
                        if {$user == $env(USER)} {
                            esec_send_appointment $currentDate $slot $alarm $comments
                        } else {
                            esec_client_send \
                                appointment $user $currentDate $slot $alarm $comments
                        }
                    }
                }
            }
            esec_load $currentDate
        }
        update {
            appointment_get $win.page schedule
            foreach slot [array names schedule] {
                set alarm [lindex $schedule($slot) 0]
                set comments [lindex $schedule($slot) 1]
                if {$comments != ""} {
                    esec_send_appointment $currentDate $slot $alarm $comments
                }
            }
            esec_load $currentDate
        }
        cancel {
            # do nothing
        }
    }
}

# ----------------------------------------------------------------------
# ABOUT WINDOW
# ----------------------------------------------------------------------
frame .about -borderwidth 4 -relief raised

button .about.ok -text "Dismiss" -command {place forget .about}
pack .about.ok -side bottom -pady 8

label .about.info -text "http://www.awl.com/cp/efftcl/efftcl.html"
pack .about.info -side bottom -fill x
catch {.about.info configure -font -*-helvetica-medium-r-normal--*-100-*}

label .about.logo -image esec-logo
pack .about.logo -side left -padx 8 -pady 8

label .about.explain -text "Calendar and\nAppointment Manager"
pack .about.explain -fill x -padx 8 -pady 8
catch {.about.explain configure -font -*-helvetica-bold-o-normal--*-140-*}

label .about.authors -text "Mark Harrison\nMichael McLennan"
pack .about.authors -fill x -pady 8
catch {.about.authors configure -font -*-helvetica-medium-r-normal--*-120-*}

# ----------------------------------------------------------------------
# HELP WINDOW
# ----------------------------------------------------------------------
set helpInfo ""
proc esec_help {} {
    global helpInfo

    if {[winfo exists $helpInfo]} {
        raise $helpInfo
    } else {
        set helpInfo [textdisplay_create "Electric Secretary: Help"]
        textdisplay_append $helpInfo "Electric Secretary:\n" bold
        textdisplay_append $helpInfo "Calendar and Appointment Manager\n" bold
        textdisplay_append $helpInfo {This application acts as a calendar and appointment manager.  To view the appointments for a particular date, dial up the month by clicking on the arrow buttons, and click on the date with the left mouse button.  Appointments for that date will be loaded into the appointment editor.
To edit existing appointments or add new ones, simply click on the appointment editor and type in a message.  Click on the "bell" symbol to activate an alarm for each appointment.
}
        textdisplay_append $helpInfo "Preferences\n" heading
        textdisplay_append $helpInfo {Select the "Preferences..." button to customize this application.  You can change colors, alarm characteristics, etc.  You can also establish work groups with other users, so that you can consult their schedules for conflicts.
}
        textdisplay_append $helpInfo "Consult\n" heading
        textdisplay_append $helpInfo {Before making an appointment, you might want to check for conflicts with your co-workers.  You can create groups of co-workers using the "Preferences..." dialog.  Having done this, you can select a day on the calendar, and select a group from the "Consult..." button.  This will bring up a window showing any conflicts for that day.  You can add appointments to this page, and save them on your own calendar by selecting "Update", or send them to everyone's calendar using "Update All".
}
    }
}

# ----------------------------------------------------------------------
# CONSULT
# ----------------------------------------------------------------------
frame .consultlist -borderwidth 4 -relief raised
frame .consultlist.groups
pack .consultlist.groups -expand yes -fill both -padx 4 -pady 4
scrollbar .consultlist.groups.sbar -orient vertical \
    -command {.consultlist.groups.lbox yview}
pack .consultlist.groups.sbar -side right -fill y
listbox .consultlist.groups.lbox -width 30 -height 5 \
    -yscrollcommand {.consultlist.groups.sbar set}
pack .consultlist.groups.lbox -side left -expand yes -fill both

frame .consultlist.sep -height 2 -borderwidth 1 -relief sunken
pack .consultlist.sep -fill x -pady 8

frame .consultlist.cntls
pack .consultlist.cntls -fill x -padx 4 -pady 4
button .consultlist.cntls.ok -text "OK" -command {
    set i [.consultlist.groups.lbox curselection]
    if {$i != ""} {
        set gname [.consultlist.groups.lbox get $i]
        foreach group $prefs(group-list) {
            if {[lindex [split $group :] 0] == $gname} {
                break
            }
        }
        set userlist [lindex [split $group :] 1]

        esec_client_send \
            consult $currentDate $userlist "conflicts %users"
    }
    place forget .consultlist
}
pack .consultlist.cntls.ok -side left -expand yes
button .consultlist.cntls.cancel -text "Cancel" -command {
    place forget .consultlist
}
pack .consultlist.cntls.cancel -side left -expand yes

# ----------------------------------------------------------------------
# PREFERENCES
# ----------------------------------------------------------------------
frame .prefs -borderwidth 4 -relief raised

tabnotebook_create .prefs.pages
pack .prefs.pages -expand yes -fill both

set prefs(colors) [tabnotebook_page .prefs.pages "Colors"]

proc esec_prefs_color_select {current} {
    global prefs
    foreach choice {calbg calfg calselect} {
        $prefs(colors).$choice configure -relief raised
    }
    $prefs(colors).$current configure -relief sunken
    set prefs(colors-current) $current
}

label $prefs(colors).calbgl -text "Calendar Background:"
frame $prefs(colors).calbg -width 20 -height 20 \
    -borderwidth 2 -relief raised
bind $prefs(colors).calbg <ButtonPress> {esec_prefs_color_select calbg}
grid $prefs(colors).calbgl $prefs(colors).calbg -pady 4

label $prefs(colors).calfgl -text "Calendar Foreground:"
frame $prefs(colors).calfg -width 20 -height 20 \
    -borderwidth 2 -relief raised
bind $prefs(colors).calfg <ButtonPress> {esec_prefs_color_select calfg}
grid $prefs(colors).calfgl $prefs(colors).calfg -pady 4

label $prefs(colors).calselectl -text "Selected Date:"
frame $prefs(colors).calselect -width 20 -height 20 \
    -borderwidth 2 -relief raised
bind $prefs(colors).calselect <ButtonPress> {esec_prefs_color_select calselect}
grid $prefs(colors).calselectl $prefs(colors).calselect -pady 4

grid configure $prefs(colors).calbgl \
    $prefs(colors).calfgl \
    $prefs(colors).calselectl -sticky e
grid configure $prefs(colors).calbg \
    $prefs(colors).calfg \
    $prefs(colors).calselect -sticky w
grid columnconfigure $prefs(colors) 1 -weight 1
grid rowconfigure $prefs(colors) 3 -weight 1

esec_prefs_color_select calbg

colordial_create $prefs(colors).dial {
    $prefs(colors).$prefs(colors-current) configure -background %v
}
grid $prefs(colors).dial -row 0 -column 2 -rowspan 4 -padx 8 -pady 8


set prefs(alarms) [tabnotebook_page .prefs.pages "Alarms"]
radiobox_create $prefs(alarms).when "Signal..."
pack $prefs(alarms).when -side left -anchor n -padx 4 -pady 4

radiobox_add $prefs(alarms).when "At appointed time"
radiobox_add $prefs(alarms).when "15 minutes before"
radiobox_add $prefs(alarms).when "30 minutes before"
radiobox_add $prefs(alarms).when "All of the above"

radiobox_create $prefs(alarms).how "Using..."
pack $prefs(alarms).how -side left -anchor n -padx 4 -pady 4

radiobox_add $prefs(alarms).how "Visual Flash"
radiobox_add $prefs(alarms).how "Pop-up reminder"
radiobox_add $prefs(alarms).how "Both"


set prefs(groups) [tabnotebook_page .prefs.pages "Groups"]
button $prefs(groups).del -text "Delete" -command esec_prefs_group_del

frame $prefs(groups).list
scrollbar $prefs(groups).list.sbar \
    -command "$prefs(groups).list.lbox yview"
pack $prefs(groups).list.sbar -side right -fill y
listbox $prefs(groups).list.lbox -width 30 -height 5 \
    -yscrollcommand "$prefs(groups).list.sbar set"
pack $prefs(groups).list.lbox -side left -expand yes -fill both

button $prefs(groups).add -text "Add" -command esec_prefs_group_add

frame $prefs(groups).new
label $prefs(groups).new.gnamel -text "Group Name:"
entry $prefs(groups).new.gname

label $prefs(groups).new.gmeml -text "Group Members:"
entry $prefs(groups).new.gmem

grid $prefs(groups).new.gnamel $prefs(groups).new.gname -sticky ew
grid $prefs(groups).new.gmeml  $prefs(groups).new.gmem  -sticky ew
grid configure $prefs(groups).new.gnamel \
    $prefs(groups).new.gmeml -sticky e
grid columnconfigure $prefs(groups).new 1 -weight 1

grid $prefs(groups).del $prefs(groups).list -sticky ew -padx 4 -pady 4
grid $prefs(groups).add $prefs(groups).new  -sticky ew -padx 4 -pady 4
grid columnconfigure $prefs(groups) 1 -weight 1

frame .prefs.sep -height 2 -borderwidth 1 -relief sunken
pack .prefs.sep -fill x -padx 4 -pady 4

frame .prefs.cntls
pack .prefs.cntls -fill x

button .prefs.cntls.ok -text "Apply" -command {esec_prefs_save}
pack .prefs.cntls.ok -side left -expand yes -pady 8

button .prefs.cntls.cancel -text "Cancel" -command {esec_prefs_cancel}
pack .prefs.cntls.cancel -side left -expand yes -pady 8

set prefs(colors-bg)     "white"
set prefs(colors-fg)     "black"
set prefs(colors-select) "red"

set prefs(alarm-when)    "All of the above"
set prefs(alarm-how)     "Both"

set prefs(group-list)    ""

proc esec_prefs_get {} {
    global prefs

    set prefs(colors-bg)     [$prefs(colors).calbg cget -background]
    set prefs(colors-fg)     [$prefs(colors).calfg cget -background]
    set prefs(colors-select) [$prefs(colors).calselect cget -background]

    set prefs(alarm-when)    [radiobox_get $prefs(alarms).when]
    set prefs(alarm-how)     [radiobox_get $prefs(alarms).how]

    set prefs(group-list) $prefs(group-pending)
}

proc esec_prefs_put {} {
    global prefs

    $prefs(colors).calbg configure -background $prefs(colors-bg)
    $prefs(colors).calfg configure -background $prefs(colors-fg)
    $prefs(colors).calselect configure -background $prefs(colors-select)

    radiobox_select $prefs(alarms).when $prefs(alarm-when)
    radiobox_select $prefs(alarms).how $prefs(alarm-how)

    set prefs(group-pending) $prefs(group-list)
    $prefs(groups).list.lbox delete 0 end
    eval $prefs(groups).list.lbox insert 0 [lsort $prefs(group-list)]
}

proc esec_prefs_apply {} {
    global prefs

    option add *Calendar.dateBackground $prefs(colors-bg)
    option add *Calendar.dateForeground $prefs(colors-fg)
    option add *Calendar.selectColor $prefs(colors-select)
    if {[winfo viewable .current]} {
        calendar_redraw .current
    }

    .consultlist.groups.lbox delete 0 end
    foreach group [lsort $prefs(group-list)] {
        set info [split $group :]
        set gname [lindex $info 0]
        .consultlist.groups.lbox insert end $gname
    }
    catch {.consultlist.groups.lbox selection set 0}
}

proc esec_prefs_save {} {
    global prefs

    esec_prefs_get
    esec_prefs_apply

    place forget .prefs
}

proc esec_prefs_cancel {} {
    global prefs

    esec_prefs_put
    place forget .prefs
}

proc esec_prefs_group_add {} {
    global prefs

    set gname [$prefs(groups).new.gname get]
    if {[string trim $gname] == ""} {
        notice_show "Cannot add group:\nMissing group name" error
        return
    }
    set gmem [$prefs(groups).new.gmem get]
    if {[string trim $gmem] == ""} {
        notice_show "Cannot add group:\nMissing group members" error
        return
    }

    regsub {:} $gname "" gname
    for {set i 0} {$i < [llength $prefs(group-pending)]} {incr i} {
        if {[string match "$gname: *" [lindex $prefs(group-pending) $i]]} {
            break
        }
    }
    if {$i < [llength $prefs(group-pending)]} {
        set prefs(group-pending) [lreplace $prefs(group-pending) $i $i "$gname: $gmem"]
    } else {
        lappend prefs(group-pending) "$gname: $gmem"
    }

    $prefs(groups).list.lbox delete 0 end
    eval $prefs(groups).list.lbox insert 0 [lsort $prefs(group-pending)]

    $prefs(groups).new.gname delete 0 end
    $prefs(groups).new.gmem delete 0 end
}

proc esec_prefs_group_del {} {
    global prefs

    foreach n [$prefs(groups).list.lbox curselection] {
        set val [$prefs(groups).list.lbox get $n]
        set i [lsearch $prefs(group-pending) $val]
        set prefs(group-pending) [lreplace $prefs(group-pending) $i $i]
    }
    $prefs(groups).list.lbox delete 0 end
    eval $prefs(groups).list.lbox insert 0 [lsort $prefs(group-pending)]
}

# ----------------------------------------------------------------------
# CONSULT WINDOW
# ----------------------------------------------------------------------
dialog_create Consult .consult

set win [dialog_info .consult]
appointment_create $win.page
pack $win.page -expand yes -fill both

set win [dialog_controls .consult]

button $win.updateAll -text "Update All" -command {
    dialog_unlock .consult
    esec_conflicts updateAll
}
pack $win.updateAll -side left -expand yes

button $win.update -text "Update" -command {
    dialog_unlock .consult
    esec_conflicts update
}
pack $win.update -side left -expand yes

button $win.cancel -text "Cancel" -command {
    dialog_unlock .consult
    esec_conflicts cancel
}
pack $win.cancel -side left -expand yes

focus $win.updateAll

# ----------------------------------------------------------------------
# MAIN MENU
# ----------------------------------------------------------------------
frame .mbar -borderwidth 1 -relief raised
pack .mbar -fill x

button .mbar.prefs -text "Preferences..." -command {
    place .prefs -x 20 -y 20
    raise .prefs
    focus .prefs.cntls.ok
}
pack .mbar.prefs -side left

button .mbar.consult -text "Consult..." -command {
    place .consultlist -x 20 -y 20
    raise .consultlist
}
pack .mbar.consult -side left

button .mbar.help -text "Help..." -command esec_help
pack .mbar.help -side right

button .mbar.about -text "About..." -command {
    place .about -x 20 -y 20
    raise .about
    focus .about.ok
}
pack .mbar.about -side right

# ----------------------------------------------------------------------
# MAIN WINDOW
# ----------------------------------------------------------------------
calendar_create .current
calendar_select_cmd .current {esec_save; esec_load %d}
pack .current -side left -expand yes -fill both -padx 4 -pady 4

appointment_create .page
pack .page -side right -expand yes -fill both -pady 4

calendar_decorate_with .current decorations

# ----------------------------------------------------------------------
# LOAD PREFERENCES
# ----------------------------------------------------------------------
set prefsParser [interp create -safe]
$prefsParser alias user esec_prefs_cmd_user
$prefsParser alias colors esec_prefs_cmd_colors
$prefsParser alias alarms esec_prefs_cmd_alarms
$prefsParser alias groups esec_prefs_cmd_groups

proc esec_prefs_cmd_user {name} {
    global env
    set env(USER) $name
}

proc esec_prefs_cmd_colors {bg fg select} {
    global prefs
    set prefs(colors-bg) $bg
    set prefs(colors-fg) $fg
    set prefs(colors-select) $select
}

proc esec_prefs_cmd_alarms {when how} {
    global prefs
    set prefs(alarm-when) $when
    set prefs(alarm-how) $how
}

proc esec_prefs_cmd_groups {glist} {
    global prefs
    set prefs(group-list) $glist
}

esec_prefs_put

# ----------------------------------------------------------------------
# SERVER CONNECTION
# ----------------------------------------------------------------------
package require Safesock

set server $env(SERVER)
set port 8823

if {[info exists embed_args(host)]} {
    set server $embed_args(host)
}
if {[info exists embed_args(port)]} {
    set port $embed_args(port)
}

set clientBuffer ""
set clientParser [interp create -safe]
$clientParser alias receive esec_receive_appointment
$clientParser alias conflicts esec_receive_conflicts

proc esec_client_handle {sid} {
    global clientBuffer clientParser

    if {[gets $sid response] < 0} {
        catch {close $sid}
        esec_error "Lost connection to server"
    } else {
        append clientBuffer $response "\n"
        if {[info complete $clientBuffer]} {
            set cmd $clientBuffer
            set clientBuffer ""
            if {[catch {$clientParser eval $cmd} err] != 0} {
                notice_show "ERROR: $err\nwhile executing:\n$cmd" error
            }
        }
    }
}

if {[catch {socket $server $port} sid] != 0} {
    esec_error "Cannot connect to server"
}
fileevent $sid readable "esec_client_handle $sid"
fconfigure $sid -buffering line
set clientServer $sid

proc esec_client_send {args} {
    global clientServer
    puts $clientServer $args
}

# ----------------------------------------------------------------------
# LOAD APPOINTMENTS...
# ----------------------------------------------------------------------

if {![info exists env(USER)]} {
    frame .logname -borderwidth 4 -relief raised
    label .logname.info -wraplength 3i -text "Enter your login name or some other unique name that will identify your calendar:"
    pack .logname.info -fill x -padx 4
    entry .logname.entry
    bind .logname.entry <KeyPress-Return> {.logname.ok invoke}
    pack .logname.entry -fill x -padx 4
    frame .logname.sep -height 2 -borderwidth 1 -relief sunken
    pack .logname.sep -fill x -pady 8
    button .logname.ok -text "OK" -command {
        dialog_unlock .logname
        set env(USER) [.logname.entry get]

        esec_client_send notify $env(USER) {
            receive {%date} {%time} {%alarm} {%comments}
        } {
        }
    }
    pack .logname.ok -pady 8

    dialog_lock .logname
} else {
    esec_client_send notify $env(USER) {
        receive {%date} {%time} {%alarm} {%comments}
    } {
    }
}

esec_check
