# ----------------------------------------------------------------------
#  DEMO: math server 1, brute force parsing
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

while {[gets stdin request] != -1} {
    set cmd [lindex $request 0]
    switch -- $cmd {
        add {
            if {[llength $request] == 3} {
                set parm1 [lindex $request 1]
                set parm2 [lindex $request 2]
                set result [expr $parm1 + $parm2]
                puts $result
            } else {
                puts "error: add should have 2 parameters"
            }
        }
        subtract {
            if {[llength $request] == 3} {
                set parm1 [lindex $request 1]
                set parm2 [lindex $request 2]
                set result [expr $parm1 - $parm2]
                puts $result
            } else {
                puts "error: subtract should have 2 parameters"
            }
        }
        default {
            puts "error: unknown command: $cmd"
        }
    }
}
