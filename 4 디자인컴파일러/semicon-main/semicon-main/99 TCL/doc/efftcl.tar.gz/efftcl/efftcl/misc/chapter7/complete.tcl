# ----------------------------------------------------------------------
#  DEMO: command complete processing
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# You can continue to interact with the process while the
# event loop waits for input on the pipe:

proc prompt {} {
    puts -nonewline "% "
    flush stdout
}

proc process_cmdline {} {
    global buffer
    if {[gets stdin line] < 0} {
        exit
    } else {
        append buffer $line "\n"
        if {[info complete $buffer]} {
            set cmd $buffer
            set buffer ""
            catch {uplevel #0 $cmd} result
            puts $result
            prompt
        }
    }
}
fileevent stdin readable process_cmdline

prompt
vwait enter-mainloop

## The "info complete" stuff lets you type multi-line commands.
## The "uplevel" executes the command at global scope.
## The "catch" catches any errors.
