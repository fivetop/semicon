# ----------------------------------------------------------------------
#  EXAMPLE: read-only text display
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Textdisplay*text.wrap word widgetDefault
option add *Textdisplay*text.background white widgetDefault
option add *Textdisplay*text.width 60 widgetDefault
option add *Textdisplay*text.height 15 widgetDefault

proc textdisplay_create {{title "Text Display"}} {
    set top [dialog_create Textdisplay]
    wm title $top $title

    set info [dialog_info $top]
    scrollbar $info.sbar -command "$info.text yview"
    pack $info.sbar -side right -fill y
    text $info.text -wrap word -yscrollcommand "$info.sbar set"
    pack $info.text -side left -expand yes -fill both

    set cntls [dialog_controls $top]
    button $cntls.dismiss -text "Dismiss" -command "destroy $top"
    pack $cntls.dismiss -pady 4
    focus $cntls.dismiss

    $info.text configure -state disabled

    $info.text tag configure normal -spacing1 6p \
        -font -*-helvetica-medium-r-normal--*-120-*

    $info.text tag configure heading -spacing1 0.2i \
        -font -*-helvetica-bold-r-normal--*-120-*

    $info.text tag configure bold \
        -font -*-helvetica-bold-r-normal--*-120-*

    $info.text tag configure italic \
        -font -*-helvetica-medium-o-normal--*-120-*

    $info.text tag configure typewriter -wrap none \
        -font -*-courier-medium-r-normal--*-120-*

    return $top
}

proc textdisplay_file {top fname} {
    set info [dialog_info $top]
    set fid [open $fname r]
    set contents [read $fid]
    close $fid
    $info.text configure -state normal
    $info.text delete 1.0 end
    $info.text insert end $contents "typewriter"
    $info.text configure -state disabled
}

proc textdisplay_clear {top} {
    set info [dialog_info $top]
    $info.text configure -state normal
    $info.text delete 1.0 end
    $info.text configure -state disabled
}

proc textdisplay_append {top mesg {tag "normal"}} {
    set info [dialog_info $top]
    $info.text configure -state normal
    $info.text insert end $mesg $tag
    $info.text configure -state disabled
}
