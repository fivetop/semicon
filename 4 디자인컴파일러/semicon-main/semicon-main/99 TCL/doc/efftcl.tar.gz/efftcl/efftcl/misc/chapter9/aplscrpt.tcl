# ----------------------------------------------------------------------
#  EXAMPLE: exec'ing programs on the Mac with AppleScript
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
catch {console hide}

package require Tclapplescript

button .open -text "Open HTML File..." \
    -command {open_html [tk_getOpenFile]}
pack .open -padx 6 -pady 6

proc open_html {file} {
    set script {
        tell application "Internet Explorer 3.0"
            open(file "%s")
            Activate -1
        end tell
    }
    AppleScript execute [format $script $file]
}
