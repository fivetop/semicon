# ----------------------------------------------------------------------
#  EXAMPLE: package initialization file
#
#  This file is executed when you use "package require Efftcl" to
#  load the Efftcl library package.  It sets up the EFFTCL_LIBRARY
#  environment variable to point to the directory where the package
#  resides.  Also, it adds the package to the auto_path variable
#  so the procedures are available for auto-loading.
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

package provide Efftcl 1.0

set efftcl_version 1.0
set env(EFFTCL_LIBRARY) [file dirname [info script]]
lappend auto_path [file join $env(EFFTCL_LIBRARY) scripts]
