#!/bin/sh
# ----------------------------------------------------------------------
#  EXAMPLE: fake "bc" program
#
#  This version of "bc" is completely Tcl-based.  It doesn't have
#  infinite precision, but it is better than nothing if the
#  user doesn't have "bc".
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set parser [interp create -safe]

fconfigure stdout -buffering line
fconfigure stdin -blocking 0
while {![eof stdin]} {
    if {[gets stdin line] >= 0} {
        if {[catch {$parser eval [list expr $line]} result] == 0} {
            puts $result
        } else {
            puts "ERROR: $result"
        }
    } else {
        after 100
    }
}
