# ----------------------------------------------------------------------
#  EXAMPLE: adding tags to control text style
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7 -background white \
    -font -*-helvetica-medium-r-normal--*-120-*
pack .t

.t insert end {Emergency Instructions
In case of a nuclear meltdown, engage
the Emergency Core Coolant System (ECCS)
and rotate the Flow Control knob fully
clockwise.}

.t tag add "heading" 1.0 {1.0 lineend}
.t tag configure "heading" -spacing1 0.1i -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag add "body" 2.0 end
.t tag configure "body" -lmargin1 0.2i

.t tag add "emphasis" 3.4 3.33
.t tag add "emphasis" 4.15 4.28
.t tag configure "emphasis" -foreground red \
    -underline yes
