# ----------------------------------------------------------------------
#  EXAMPLE: sketchpad program with an old-style menu bar
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

# ----------------------------------------------------------------------
# RESOURCES
# ----------------------------------------------------------------------
option add *sketchpad.background white startupFile
option add *style*background mediumSlateBlue startupFile
option add *style*highlightBackground mediumSlateBlue startupFile

wm title . "sketch"

# ----------------------------------------------------------------------
# MENU BAR
# ----------------------------------------------------------------------
frame .mbar -borderwidth 1 -relief raised
pack .mbar -fill x

menubutton .mbar.file -text "File" -menu .mbar.file.m
pack .mbar.file -side left

menu .mbar.file.m
.mbar.file.m add command -label "Exit" -command exit

menubutton .mbar.edit -text "Edit" -menu .mbar.edit.m
pack .mbar.edit -side left

menu .mbar.edit.m
.mbar.edit.m add command -label "Clear" -command {
    .sketchpad delete all
}

# ----------------------------------------------------------------------
# STYLE FRAME
# ----------------------------------------------------------------------
frame .style -borderwidth 1 -relief sunken
pack .style -fill x

set imh [image create bitmap -foreground black -background white \
    -file [file join $env(EFFTCL_LIBRARY) images pen.xbm] \
    -maskfile [file join $env(EFFTCL_LIBRARY) images penm.xbm]]

colormenu_create .style.color -image $imh
pack .style.color -side left -padx 4 -pady 4
balloonhelp_for .style.color {Pen Color:
Selects the drawing color for the canvas}

label .style.readout -text ""
pack .style.readout -side right
balloonhelp_for .style.readout {Pen Location:
Shows the location of the pointer on the drawing canvas (in inches)}

proc sketch_coords {x y} {
    set size [winfo fpixels .sketchpad 1i]
    set x [expr $x/$size]
    set y [expr $y/$size]
    .style.readout configure -text [format "x: %6.2fi  y: %6.2fi" $x $y]
}

# ----------------------------------------------------------------------
# BINDINGS
# ----------------------------------------------------------------------
canvas .sketchpad
pack .sketchpad -expand yes -fill both
balloonhelp_for .sketchpad {Drawing Canvas:
Click and drag with the left mouse button to draw in this area}

bind .sketchpad <Motion> {sketch_coords %x %y}

bind .sketchpad <ButtonPress-1> {sketch_box_add %x %y}
bind .sketchpad <B1-Motion>     {sketch_box_add %x %y}

proc sketch_box_add {x y} {
    set x0 [expr $x-3]
    set x1 [expr $x+3]
    set y0 [expr $y-3]
    set y1 [expr $y+3]
    set color [colormenu_get .style.color]

    .sketchpad create rectangle $x0 $y0 $x1 $y1 \
        -outline "" -fill $color
}
