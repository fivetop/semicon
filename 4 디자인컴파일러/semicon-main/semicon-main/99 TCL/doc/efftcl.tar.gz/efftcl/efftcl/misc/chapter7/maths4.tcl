# ----------------------------------------------------------------------
#  DEMO: math server 4, asynchronous with pre-defined callbacks
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set parser [interp create -safe]

$parser eval {
    proc add {x y} {
        return [list show_result [expr $x+$y]]
    }
    proc subtract {x y} {
        return [list show_result [expr $x-$y]]
    }
}

proc back_handler {parser} {
    if {[gets stdin request] < 0} {
        exit
    } elseif {[catch {$parser eval $request} result] == 0} {
        puts $result
    } else {
        puts [list error_result $result]
    }
}

fileevent stdin readable "back_handler $parser"
vwait enter-mainloop
