pack [canvas .c]

bind .c <ButtonPress-1>   {puts "click %x %y"}
bind .c <B1-Motion>       {puts "drag %x %y"}
bind .c <ButtonRelease-1> {puts "drop %x %y"}
