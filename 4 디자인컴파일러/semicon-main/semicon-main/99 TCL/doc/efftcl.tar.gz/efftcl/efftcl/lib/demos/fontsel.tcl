# ----------------------------------------------------------------------
#  DEMO: change font with font_select
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

button .b -text "Change Font" -command {
    set options [font_select "Change Font"]
    if {$options != ""} {
        .b configure -font $options
    }
}
pack .b
