# ----------------------------------------------------------------------
#  DEMO: simple notebook that can dial up pages
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

notebook_create .nb
pack .nb -side bottom -expand yes -fill both -padx 4 -pady 4

set p1 [notebook_page .nb "Colors"]

label $p1.calbgl -text "Calendar Background:"
colormenu_create $p1.calbg -text "   "
grid $p1.calbgl $p1.calbg -pady 4
colormenu_select $p1.calbg white

label $p1.calfgl -text "Calendar Foreground:"
colormenu_create $p1.calfg -text "   "
grid $p1.calfgl $p1.calfg -pady 4
colormenu_select $p1.calfg blue

label $p1.calselectl -text "Selected Date:"
colormenu_create $p1.calselect -text "   "
grid $p1.calselectl $p1.calselect -pady 4
colormenu_select $p1.calselect red

grid configure $p1.calbgl $p1.calfgl $p1.calselectl -sticky e
grid configure $p1.calbg $p1.calfg $p1.calselect -sticky w
grid columnconfigure $p1 1 -weight 1


set p2 [notebook_page .nb "Alarms"]
radiobox_create $p2.when "Signal..."
pack $p2.when -side left -anchor n -padx 4 -pady 4

radiobox_add $p2.when "At appointed time"
radiobox_add $p2.when "15 minutes before"
radiobox_add $p2.when "30 minutes before"
radiobox_add $p2.when "All of the above"

radiobox_create $p2.how "Using..."
pack $p2.how -side left -anchor n -padx 4 -pady 4

radiobox_add $p2.how "Audible beep"
radiobox_add $p2.how "Pop-up reminder"
radiobox_add $p2.how "Both"


set p3 [notebook_page .nb "Groups"]
button $p3.del -text "Delete"
balloonhelp_for $p3.del {Delete Group:
Select a group in the list and click here to delete it}

frame $p3.list
scrollbar $p3.list.sbar \
    -command "$p3.list.lbox yview"
pack $p3.list.sbar -side right -fill y
listbox $p3.list.lbox -width 30 -height 5 \
    -yscrollcommand "$p3.list.sbar set"
pack $p3.list.lbox -side left -expand yes -fill both

balloonhelp_for $p3.list.lbox {Group List:
Current list of all collaboration groups}

button $p3.add -text "Add"
balloonhelp_for $p3.add {Add Group:
Fill in group name and member list and click here to create group}

frame $p3.new
label $p3.new.gnamel -text "Group Name:"
entry $p3.new.gname
balloonhelp_for $p3.new.gname {Group Name:
Describes new group}

label $p3.new.gmeml -text "Group Members:"
entry $p3.new.gmem
balloonhelp_for $p3.new.gmem {Group Members:
List of login names for people in this group}

grid $p3.new.gnamel $p3.new.gname -sticky ew
grid $p3.new.gmeml  $p3.new.gmem  -sticky ew
grid configure $p3.new.gnamel $p3.new.gmeml -sticky e
grid columnconfigure $p3.new 1 -weight 1

grid $p3.del $p3.list -sticky ew -padx 4 -pady 4
grid $p3.add $p3.new  -sticky ew -padx 4 -pady 4
grid columnconfigure $p3 1 -weight 1

radiobox_create .controls
pack .controls -side top -fill x -padx 4 -pady 4

radiobox_add .controls "Colors" {notebook_display .nb "Colors"}
radiobox_add .controls "Alarms" {notebook_display .nb "Alarms"}
radiobox_add .controls "Groups" {notebook_display .nb "Groups"}
