# ----------------------------------------------------------------------
#  EXAMPLE: use the canvas to build a scrollable form
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
#  USAGE:  scrollform_create <win>
#
#  Creates an empty scrollform assembly.  The interior frame for this
#  form can be found by calling "scrollform_interior".  Widgets packed
#  into the interior can be scrolled in the vertical direction.
# ----------------------------------------------------------------------
proc scrollform_create {win} {

    frame $win -class Scrollform

    scrollbar $win.sbar -command "$win.vport yview"
    pack $win.sbar -side right -fill y 

    canvas $win.vport -yscrollcommand "$win.sbar set"
    pack $win.vport -side left -fill both -expand true

    frame $win.vport.form
    $win.vport create window 0 0 -anchor nw -window $win.vport.form

    bind $win.vport.form <Configure> "scrollform_resize $win"

    return $win
}

# ----------------------------------------------------------------------
#  USAGE:  scrollform_resize <win>
#
#  Used internally to handle size changes in the form area within
#  a scrollform assembly.  Updates the canvas to recognize the new
#  scrolling area.
# ----------------------------------------------------------------------
proc scrollform_resize {win} {
    set bbox [$win.vport bbox all]
    set wid [winfo width $win.vport.form]
    $win.vport configure -width $wid \
        -scrollregion $bbox -yscrollincrement 0.1i
}

# ----------------------------------------------------------------------
#  USAGE:  scrollform_interior <win>
#
#  Returns the name of the interior frame that represents the
#  body of the scrollform.  Widgets should be packed in this
#  frame to build the form.
# ----------------------------------------------------------------------
proc scrollform_interior {win} {
    return "$win.vport.form"
}
