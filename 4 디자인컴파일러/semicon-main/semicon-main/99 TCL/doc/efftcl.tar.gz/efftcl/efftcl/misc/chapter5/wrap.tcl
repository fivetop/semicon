# ----------------------------------------------------------------------
#  EXAMPLE: handling line wrap
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

text .t -width 40 -height 7 -background white
pack .t

.t tag configure "heading" -spacing1 10 -spacing3 5 \
    -font -*-helvetica-bold-r-normal--*-120-*

.t tag configure "body" \
    -font -*-helvetica-medium-r-normal--*-120-*

.t tag configure "emphasis" -foreground red

proc heading {mesg} {
    .t insert end $mesg heading
}
proc body {mesg} {
    .t insert end $mesg body
}

heading "Emergency Instructions\n"
body "In case of a nuclear meltdown, "
body "engage the Emergency Core Coolant "
body "System (ECCS) and rotate the Flow "
body "Control knob fully clockwise."

toplevel .cntl
button .cntl.continue -text "Continue" -command {set continue 1}
pack .cntl.continue

.t configure -wrap none
tkwait variable continue

.t configure -wrap char
tkwait variable continue

.t configure -wrap word
tkwait variable continue

exit
