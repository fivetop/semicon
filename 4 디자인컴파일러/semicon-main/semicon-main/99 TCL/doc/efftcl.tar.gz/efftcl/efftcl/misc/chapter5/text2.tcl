# ----------------------------------------------------------------------
#  EXAMPLE: indexing text within a text widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Text.selectBackground #808080

text .t -width 40 -height 7
pack .t

.t insert end {Emergency Instructions
In case of a nuclear meltdown, engage
the Emergency Core Coolant System (ECCS)
and rotate the Flow Control knob fully
clockwise.}

focus .t
toplevel .cntl
button .cntl.cont -text "Continue" -command {set continue 1}
pack .cntl.cont -padx 4 -pady 4

# ----------------------------------------------------------------------
proc command {cmd} {
    puts "% $cmd"
    puts "[uplevel #0 $cmd]"
}

# get some text:
command {.t get 2.21 2.29}

vwait continue

# replace some text:
command {.t delete 2.21 2.29}
command {.t insert 2.21 "accident"}

# get all of the text:
command {.t get 1.0 end}

# get all of the text:
command {.t get 1.0 "end - 1 char"}

# get all of the text:
command {.t get 1.0 "end - 5 chars - 2 lines"}

# convert a symbolic name to an index:
command {set index [.t index "end - 1 char"]}
command {set lines [lindex [split $index .] 0]}

vwait continue

# use the insertion cursor:
.t tag remove sel 1.0 end
.t mark set insert 3.6

command {.t get insert}
command {.t get "insert wordstart" "insert wordend"}
command {.t get "insert linestart" "insert lineend"}

vwait continue

# get the current selection:
.t tag remove sel 1.0 end
.t tag add sel 2.13 2.20
.t mark set insert 2.20

command {.t get sel.first sel.last}
command {.t get "sel.first - 2 chars" "sel.last lineend"}

vwait continue

exit
