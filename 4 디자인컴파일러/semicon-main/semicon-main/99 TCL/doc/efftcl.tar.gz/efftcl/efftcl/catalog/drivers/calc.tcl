# ----------------------------------------------------------------------
#  Driver for "calc" example when invoked from the catalog
#
#  Checks to see whether "bc" is on the command path, and if not,
#  automatically substitutes the fake "bc" program from the
#  "fixes" directory.
#
#  This program should be invoked in the same directory context
#  as the "catalog.tcl" script.
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
#  USAGE: find_tclsh
#
#  This procedure returns the appropriate "tclsh" program for the
#  current "wish".  If tclsh is not found, it returns the null string.
# ----------------------------------------------------------------------
proc find_tclsh {} {
    global tcl_version

    set bin [file dirname [info nameofexecutable]]
    set best [glob -nocomplain [file join $bin tclsh$tcl_version]]
    if {$best != ""} {
        return $best
    }
    set best [glob -nocomplain [file join $bin tclsh]]
    if {$best != ""} {
        return $best
    }
    set any [glob -nocomplain [file join $bin tclsh*]]
    set best [lindex [lsort $any] end]
    return $best
}

# ----------------------------------------------------------------------
wm withdraw .
auto_load tk_messageBox

set tclsh [find_tclsh]
rename open tcl_open
proc open {args} [format {
    return [tcl_open "%s" "r+"]
} [list "|" $tclsh [file join fixes bc.tcl]]]

if {[catch {open "| bc" "r+"} fid] == 0} {

    catch {close $fid}    ;# success with demo!

    tk_messageBox -icon warning -message "Using the demo program \"efftcl/fixes/bc.tcl\" instead of the real \"bc\" program.  This version doesn't have infinite precision, but it will perform simple calculations."
} else {
    tk_messageBox -icon error -message "Can't run demo \"bc\" program.\nNeed to have tclsh installed in the same directory as wish."
    exit
}

# Now, load the real "calc" application...
# ----------------------------------------------------------------------
source [file join apps calc]
update
wm deiconify .
