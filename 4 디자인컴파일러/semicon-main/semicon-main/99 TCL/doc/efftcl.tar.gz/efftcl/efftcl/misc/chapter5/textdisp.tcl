#!/bin/sh
# ----------------------------------------------------------------------
#  DEMO: read-only text display
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# /bin/sh interprets this part, but wish ignores it...
#\
exec wish "$0" "$@"

# The rest of this is interpreted by wish...
# ----------------------------------------------------------------------
package require Efftcl

set win [textdisplay_create "Notice"]
textdisplay_append $win "Emergency Instructions\n" heading
textdisplay_append $win "In case of a nuclear meltdown, engage the Emergency Core Coolant System and rotate the Flow Control knob fully clockwise.  Then open the primary release value and vent excess pressure through the Exhaust Relief System (ERS) to the atmosphere.\n"
textdisplay_append $win "Emergency Contacts\n" heading
textdisplay_append $win "Notify the person on duty at each of the following stations:\n"
textdisplay_append $win " \273 Security"
textdisplay_append $win " x2351\n" italic
textdisplay_append $win " \273 Disaster relief "
textdisplay_append $win " x2217\n" italic
textdisplay_append $win " \273 Board of trustees "
textdisplay_append $win " x2100\n" italic
