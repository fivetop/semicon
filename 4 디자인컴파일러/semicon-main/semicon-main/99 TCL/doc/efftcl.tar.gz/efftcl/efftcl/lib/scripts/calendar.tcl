# ----------------------------------------------------------------------
#  EXAMPLE: calendar widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

option add *Calendar.dateBackground white widgetDefault
option add *Calendar.dateForeground black widgetDefault
option add *Calendar.selectColor red widgetDefault
option add *Calendar.selectThickness 3 widgetDefault

option add *Calendar.titleFont \
    -*-helvetica-bold-o-normal--*-180-* widgetDefault
option add *Calendar.dateFont \
    -*-helvetica-medium-r-normal--*-100-* widgetDefault

# ----------------------------------------------------------------------
#  USAGE:  calendar_create <win> ?<date>?
#
#  Creates a canvas to represent a calendar and sets it up to
#  display the month containing the specified <date>.  If a <date>
#  string is not specified, the current month is displayed.
#  <decorateVar> is specified, it is treated as an array with
#  date strings like "04/05/1996" as indices.  If a particular
#  date exists within the array, its value is treated as the name
#  of an image, which is displayed on the calendar as a decoration.
# ----------------------------------------------------------------------
proc calendar_create {win {date "now"}} {
    global calInfo env

    if {$date == "now"} {
        set time [clock seconds]
    } else {
        set time [clock scan $date]
    }
    set calInfo($win-time) $time
    set calInfo($win-selected) ""
    set calInfo($win-selectCmd) ""
    set calInfo($win-decorateVar) ""

    frame $win -class Calendar
    canvas $win.cal -width 3i -height 2i
    pack $win.cal -expand yes -fill both

    button $win.cal.back \
        -bitmap @[file join $env(EFFTCL_LIBRARY) images back.xbm] \
        -command "calendar_change $win -1"
    balloonhelp_for $win.cal.back {Previous Month}

    button $win.cal.fwd \
        -bitmap @[file join $env(EFFTCL_LIBRARY) images fwd.xbm] \
        -command "calendar_change $win +1"
    balloonhelp_for $win.cal.fwd {Next Month}

    bind $win.cal <Configure> "calendar_redraw $win"

    return $win
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_change <win> <delta>
#
#  Changes the current month displayed on the calendar <win>, moving
#  forward or backward by <delta> months.
# ----------------------------------------------------------------------
proc calendar_change {win delta} {
    global calInfo

    set dir [expr ($delta > 0) ? 1 : -1]
    set month [clock format $calInfo($win-time) -format "%m"]
    set month [string trimleft $month 0]
    set year [clock format $calInfo($win-time) -format "%Y"]

    for {set i 0} {$i < abs($delta)} {incr i} {
        incr month $dir
        if {$month < 1} {
            set month 12
            incr year -1
        } elseif {$month > 12} {
            set month 1
            incr year 1
        }
    }
    set calInfo($win-time) [clock scan "$month/1/$year"]

    calendar_redraw $win
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_redraw <win>
#
#  Used internally to redraw the calendar whenever it changes size.
# ----------------------------------------------------------------------
proc calendar_redraw {win} {
    global calInfo

    if {$calInfo($win-decorateVar) != ""} {
        upvar #0 $calInfo($win-decorateVar) decorate
    }

    $win.cal delete all

    set time $calInfo($win-time)
    set wmax [winfo width $win.cal]
    set hmax [winfo height $win.cal]

    $win.cal create window 3 3 -anchor nw \
        -window $win.cal.back
    $win.cal create window [expr $wmax-3] 3 -anchor ne \
        -window $win.cal.fwd
    set bottom [lindex [$win.cal bbox all] 3]

    set font [option get $win titleFont Font]
    set title [clock format $time -format "%B %Y"]
    $win.cal create text [expr $wmax/2] $bottom -anchor s \
        -text $title -font $font

    incr bottom 3
    $win.cal create line 0 $bottom $wmax $bottom -width 2
    incr bottom 3

    set font [option get $win dateFont Font]
    set bg [option get $win dateBackground Background]
    set fg [option get $win dateForeground Foreground]
    set current ""

    set layout [calendar_layout $time]
    set weeks [expr [lindex $layout end]+1]

    foreach {day date dcol wrow} $layout {
        set x0 [expr $dcol*($wmax-7)/7+3]
        set y0 [expr $wrow*($hmax-$bottom-4)/$weeks+$bottom]
        set x1 [expr ($dcol+1)*($wmax-7)/7+3]
        set y1 [expr ($wrow+1)*($hmax-$bottom-4)/$weeks+$bottom]

        if {$date == $calInfo($win-selected)} {
            set current $date
        }

        $win.cal create rectangle $x0 $y0 $x1 $y1 \
            -outline $fg -fill $bg

        $win.cal create text [expr $x0+4] [expr $y0+2] \
            -anchor nw -text "$day" -fill $fg -font $font

        $win.cal create image [expr $x1-2] [expr $y1-2] \
            -anchor se -tags [list $date-image]

        if {[info exists decorate($date)]} {
            $win.cal itemconfigure $date-image \
                -image $decorate($date)
        }

        $win.cal create rectangle $x0 $y0 $x1 $y1 \
            -outline "" -fill "" \
            -tags [list $date-sensor all-sensor]

        $win.cal bind $date-sensor <ButtonPress-1> \
            [list calendar_select $win $date]
    }

    if {$current != ""} {
        set color [option get $win selectColor Foreground]
        set width [option get $win selectThickness Thickness]

        $win.cal itemconfigure $current-sensor \
            -outline $color -width $width

        $win.cal raise $current-sensor

    } elseif {$calInfo($win-selected) == ""} {
        set date [clock format $time -format "%m/%d/%Y"]
        calendar_select $win $date
    }
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_layout <time>
#
#  Used internally whenever the calendar is redrawn.  Finds the month
#  containing a <time> in seconds, and returns a list for all of the
#  days in that month.  The list looks like this:
#
#    {day1 date1 c1 r1  day2 date2 c2 r2  day3 date3 c3 r3 ...}
#
#  where dayN is a day number like 1,2,3,..., dateN is the date for
#  dayN, and cN,rN are the column/row indices for the square
#  containing that date.
# ----------------------------------------------------------------------
proc calendar_layout {time} {
    set month [clock format $time -format "%m"]
    set year  [clock format $time -format "%Y"]

    foreach lastday {31 30 29 28} {
        if {[catch {clock scan "$month/$lastday/$year"}] == 0} {
            break
        }
    }
    set seconds [clock scan "$month/1/$year"]
    set firstday [clock format $seconds -format %w]
    set weeks [expr ceil(double($lastday+$firstday)/7)]

    set rlist ""
    for {set day 1} {$day <= $lastday} {incr day} {
        set seconds [clock scan "$month/$day/$year"]
        set date [clock format $seconds -format "%m/%d/%Y"]
        set daycol [clock format $seconds -format %w]
        set weekrow [expr ($firstday+$day-1)/7]
        lappend rlist $day $date $daycol $weekrow
    }
    return $rlist
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_select_cmd <win> <command>
#
#  Sets the selection <command> for the calendar <win>.  When the
#  user selects a date on the calendar, the date is substituted in
#  place of "%d" in this command, and the command is executed.
# ----------------------------------------------------------------------
proc calendar_select_cmd {win cmd} {
    global calInfo

    if {![info exists calInfo($win-selectCmd)]} {
        error "bad calendar name \"$win\""
    }
    set calInfo($win-selectCmd) $cmd
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_select <win> <date>
#
#  Selects the current <date> on the calendar <win>.  Highlights
#  the date on the calendar, and executes the command associated
#  with the calendar, with the selected date substituted in place
#  of "%d".
# ----------------------------------------------------------------------
proc calendar_select {win date} {
    global calInfo
    set time [clock scan $date]
    set date [clock format $time -format "%m/%d/%Y"]

    set calInfo($win-selected) $date

    set current [clock format $calInfo($win-time) \
        -format "%m %Y"]
    set selected [clock format $time -format "%m %Y"]

    if {$current == $selected} {
        set fg [option get $win dateForeground Foreground]
        $win.cal itemconfigure all-sensor \
            -outline "" -width 1

        set color [option get $win selectColor Foreground]
        set width [option get $win selectThickness Thickness]
        $win.cal itemconfigure $date-sensor \
            -outline $color -width $width
        $win.cal raise $date-sensor
    } else {
        set calInfo($win-time) $time
        calendar_redraw $win
    }

    if {[string trim $calInfo($win-selectCmd)] != ""} {
        set cmd $calInfo($win-selectCmd)
        set cmd [percent_subst %d $cmd $date]
        uplevel #0 $cmd
    }
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_get <win>
#
#  Returns the current <date> for the calendar <win>.
# ----------------------------------------------------------------------
proc calendar_get {win} {
    global calInfo
    return $calInfo($win-selected)
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_decorate_with <win> <var>
#
#  Assigns a decoration variable <var> to the calendar <win>.  This
#  variable is an array with date strings like "04/05/1996" as indices.
#  If a particular date exists within the array, its value is treated
#  as the name of an image, which is displayed on the calendar as a
#  decoration.
# ----------------------------------------------------------------------
proc calendar_decorate_with {win decorateVar} {
    global calInfo

    if {![info exists calInfo($win-decorateVar)]} {
        error "bad calendar name \"$win\""
    }
    set calInfo($win-decorateVar) $decorateVar
    calendar_redraw $win

    global $decorateVar
    trace variable $decorateVar wu "calendar_decorate $win"
}

# ----------------------------------------------------------------------
#  USAGE:  calendar_decorate <win> <name1> <name2> <op>
#
#  Used internally to fix the calendar whenever its "decorateVar"
#  changes.  This procedure is triggered as part of a "write" or
#  "unset" trace.  <name1> is the name of the variable, <name2>
#  is the date being modified or deleted.  <op> is "w" for "write"
#  or "u" for "unset".
# ----------------------------------------------------------------------
proc calendar_decorate {win name1 name2 op} {
    upvar #0 $name1 decorate

    if {[info exists decorate($name2)]} {
        set imh $decorate($name2)
    } else {
        set imh ""
    }
    $win.cal itemconfigure $name2-image -image $imh
}
