# ----------------------------------------------------------------------
#  DEMO: use the canvas to build a scrollable form
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Entry.background white startupFile

label .title -text "Enter Information in the form below:"
pack .title -anchor w

scrollform_create .sform
pack .sform -expand yes -fill both

set form [scrollform_interior .sform]

set counter 0
foreach field {
    "Name:"       "Address:"         "City, State:"
    "Phone:"      "FAX:"             "E-mail:"
    "-"
    "SSN:"        "Birthdate:"       "Marital Status:"
    "-"
    "Employer:"   "Occupation:"      "Annual Income:"
    "-"
    "Emergency Contact:"  "Phone:"
} {
    set line "$form.line[incr counter]"
    if {$field == "-"} {
        frame $line -height 2 -borderwidth 1 -relief sunken
        pack $line -fill x -padx 4 -pady 4
    } else {
        frame $line
        label $line.label -text $field -width 20 -anchor e
        pack $line.label -side left
        entry $line.info
        pack $line.info -fill x
        pack $line -side top -fill x
    }
}
