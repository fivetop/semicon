# ----------------------------------------------------------------------
#  EXAMPLE: working around problems with "regsub"
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
#  USAGE:  percent_subst <%pattern> <string> <subst>
#
#  This command is a "safe" version of regsub, for substituting
#  each occurance of <%pattern> in <string> with <subst>.  The
#  usual Tcl "regsub" command does the same thing, but also
#  converts characters like "&" and "\0", "\1", etc. that may
#  be present in the <subst> string.
#
#  Returns <string> with <subst> substituted in place of each
#  <%pattern>.
# ----------------------------------------------------------------------
proc percent_subst {percent string subst} {
    if {![string match %* $percent]} {
        error "bad pattern \"$percent\": should be %something"
    }
    regsub -all {\\|&} $subst {\\\0} subst
    regsub -all $percent $string $subst string
    return $string
}
