# ----------------------------------------------------------------------
#  DEMO: introductory placard with animation
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

placard_create {
    package require Efftcl

    set images {}
    set counter 0
    for {set i 1} {$i <= 9} {incr i} {
        set file [file join $env(EFFTCL_LIBRARY) images esec$i.gif]
        set imh [image create photo -file $file]
        label .l$i -image $imh
        lappend images $imh
    }

    label .info -text "http://www.awl.com/cp/efftcl/efftcl.html"
    pack .info -side bottom -fill x
    catch {.info configure -font -*-helvetica-medium-r-normal--*-100-*}

    label .movie -image [lindex $images 0]
    pack .movie -side left -padx 8 -pady 8

    label .title -text "Calendar and\nAppointment Manager"
    pack .title -fill x -padx 8 -pady 8
    catch {.title configure -font -*-helvetica-bold-o-normal--*-140-*}

    label .status -text "Connecting to server..."
    pack .status -fill x -pady 8
    catch {.status configure -font -*-helvetica-medium-r-normal--*-120-*}

    animate_start 100 $images ".movie configure -image %v"
    update
}

#
# Set up the main program...
# ----------------------------------------------------------------------
label .main -text "Main Program Window"
pack .main
button .quit -text "Quit" -command exit
pack .quit
after 6000

#
# Take down the placard and put up the main window...
# ----------------------------------------------------------------------
placard_destroy
