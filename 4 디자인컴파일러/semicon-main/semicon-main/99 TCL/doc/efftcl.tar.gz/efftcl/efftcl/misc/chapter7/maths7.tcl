# ----------------------------------------------------------------------
#  DEMO: math server 7, using sockets
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set parser [interp create -safe]
$parser eval {
    proc percent_subst {percent string subst} {
        if {![string match %* $percent]} {
            error "bad pattern \"$percent\": should be %something"
        }
        regsub -all {\\|&} $subst {\\\0} subst
        regsub -all $percent $string $subst string
        return $string
    }
}

$parser eval {
    proc add {x y cmd} {
        set num [expr $x+$y]
        set response [percent_subst %v $cmd $num]
        return $response
    }
    proc subtract {x y cmd} {
        set num [expr $x-$y]
        set response [percent_subst %v $cmd $num]
        return $response
    }
}

proc server_accept {cid addr port} {
    fileevent $cid readable "server_handle $cid"
    fconfigure $cid -buffering line
}

proc server_handle {cid} {
    global parser buffer

    if {[gets $cid request] < 0} {
        close $cid
    } else {
        append buffer $request "\n"
        if {[info complete $buffer]} {
            set request $buffer
            set buffer ""
            if {[catch {$parser eval $request} result] == 0} {
                puts $cid $result
            } else {
                puts $cid [list error_result $result]
            }
        }
    }
}

socket -server server_accept 9001
vwait enter-mainloop
