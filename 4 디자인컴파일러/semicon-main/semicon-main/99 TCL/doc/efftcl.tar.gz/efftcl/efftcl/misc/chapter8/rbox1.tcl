# ----------------------------------------------------------------------
#  DEMO: box of mutually-exclusive choices
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

frame .rbox
pack .rbox -padx 4 -pady 4

label .rbox.title -text "Installation Options:"
pack .rbox.title -side top -anchor w

frame .rbox.border -borderwidth 2 -relief groove
pack .rbox.border -expand yes -fill both

radiobutton .rbox.border.rb1 -text "Full install" \
    -variable current -value "Full install"
pack .rbox.border.rb1 -side top -anchor w

radiobutton .rbox.border.rb2 -text "Demo only" \
    -variable current -value "Demo only"
pack .rbox.border.rb2 -side top -anchor w

radiobutton .rbox.border.rb3 -text "Data files" \
    -variable current -value "Data files"
pack .rbox.border.rb3 -side top -anchor w

.rbox.border.rb1 invoke
