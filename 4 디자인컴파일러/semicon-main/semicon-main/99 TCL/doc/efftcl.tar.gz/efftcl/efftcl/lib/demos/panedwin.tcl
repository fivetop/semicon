# ----------------------------------------------------------------------
#  DEMO: simple panedwindow facility
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

option add *Listbox.background white startupFile

panedwindow_create .pw 3i 4i
pack .pw -expand yes -fill both

frame .pw.pane1.dirs
pack .pw.pane1.dirs -expand yes -fill both -padx 4 -pady 10
label .pw.pane1.dirs.lab -text "Directories:"
pack .pw.pane1.dirs.lab -anchor w
scrollbar .pw.pane1.dirs.sbar \
    -command {.pw.pane1.dirs.list yview}
pack .pw.pane1.dirs.sbar -side right -fill y
listbox .pw.pane1.dirs.list -selectmode single \
    -yscrollcommand {.pw.pane1.dirs.sbar set}
pack .pw.pane1.dirs.list -side left -expand yes -fill both

frame .pw.pane2.files
pack .pw.pane2.files -expand yes -fill both -padx 4 -pady 10
label .pw.pane2.files.lab -text "Files:"
pack .pw.pane2.files.lab -anchor w
scrollbar .pw.pane2.files.sbar \
    -command {.pw.pane2.files.list yview}
pack .pw.pane2.files.sbar -side right -fill y
listbox .pw.pane2.files.list -selectmode single \
    -yscrollcommand {.pw.pane2.files.sbar set}
pack .pw.pane2.files.list -side left -expand yes -fill both

bind .pw.pane1.dirs.list <Double-ButtonPress-1> {
    set num [.pw.pane1.dirs.list curselection]
    if {$num != ""} {
        load_dir [.pw.pane1.dirs.list get $num]
    }
    break
}

# ----------------------------------------------------------------------
# Load up files and directories...
# ----------------------------------------------------------------------
proc load_dir {dir} {
    .pw.pane1.dirs.list delete 0 end
    .pw.pane2.files.list delete 0 end

    cd $dir
    .pw.pane1.dirs.list insert end ".."
    foreach file [lsort [glob -nocomplain *]] {
        if {[file isdirectory $file]} {
            .pw.pane1.dirs.list insert end "$file/"
        } else {
            .pw.pane2.files.list insert end "$file"
        }
    }
}

load_dir $env(HOME)
