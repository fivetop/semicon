# ----------------------------------------------------------------------
#  RELEASE CATALOG
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
option add *Radiobutton.selectColor ForestGreen startupFile
option add *Checkbutton.selectColor ForestGreen startupFile
option add *Entry.background white startupFile
option add *Text.background white startupFile
option add *topics.hbox.width 25 startupFile
option add *topics.hbox.height 30 startupFile

if {![file isdirectory [file join lib scripts]]} {
    cd [file dirname [info script]]
}
set env(TCLLIBPATH) lib  ;# for other programs we exec
set auto_path [linsert $auto_path 0 lib]
package require Efftcl

email_bug_reports mmclennan@lucent.com

# Check for the proper version of wish...
# ----------------------------------------------------------------------
wm withdraw .

if {$tk_version < 4.1} {
    set ok [confirm_ask "Some of the examples in this book require wish4.1 or beyond.  You are currently running an older version of wish ($tk_version).\n\nContinue with the catalog?"]
    if {!$ok} {
        exit
    }
}

# ----------------------------------------------------------------------
# HIERLIST LIBRARY
# Use this customized version instead of the one in the Efftcl
# library.  This version supports a callback for element selections.
# ----------------------------------------------------------------------
option add *Hierlist.activeColor gray widgetDefault
option add *Hierlist.indent 15 widgetDefault
option add *Hierlist.hbox.background white widgetDefault
option add *Hierlist.hbox.width 40 widgetDefault
option add *Hierlist.hbox.height 10 widgetDefault
option add *Hierlist.hbox.cursor center_ptr widgetDefault
option add *Hierlist.hbox.font \
    -*-lucida-medium-r-normal-sans-*-120-* widgetDefault

set hierInfo(sideArrow) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images side.gif]]

set hierInfo(downArrow) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images down.gif]]

proc hierlist_create {win {cmd ""}} {
    global hierInfo

    set hierInfo($win-pending) ""
    set hierInfo($win-selected) ""
    set hierInfo($win-command) $cmd

    set counter 0
    while {1} {
        set var "hierData#[incr counter]"
        upvar #0 $var data
        if {![info exists data]} {
            break
        }
    }
    set hierInfo($win-data) $var
    set data(root-label) ""
    set data(root-children) ""

    frame $win -class Hierlist
    scrollbar $win.sbar -command "$win.hbox yview"
    pack $win.sbar -side right -fill y
    text $win.hbox -wrap none -takefocus 0 \
        -yscrollcommand "$win.sbar set"
    pack $win.hbox -side left -expand yes -fill both

    set tabsize [option get $win indent Indent]
    set tabsize [winfo pixels $win $tabsize]
    set tabs "15"
    for {set i 1} {$i < 20} {incr i} {
        lappend tabs [expr $i*$tabsize+15]
    }
    $win.hbox configure -tabs $tabs

    set btags [bindtags $win.hbox]
    set i [lsearch $btags Text]
    if {$i >= 0} {
        set btags [lreplace $btags $i $i]
    }
    bindtags $win.hbox $btags

    bind $win <Destroy> "hierlist_destroy $win"
    return $win
}

proc hierlist_destroy {win} {
    global hierInfo

    if {[info exists hierInfo($win-data)]} {
        set var $hierInfo($win-data)
        upvar #0 $var data
        unset data
        unset hierInfo($win-data)
    }
}

proc hierlist_display {win info} {
    hierlist_data $win $info
    hierlist_redraw $win eventually
}

proc hierlist_redraw {win {when "now"}} {
    global hierInfo

    if {$when == "eventually"} {
        if {$hierInfo($win-pending) == ""} {
            set hierInfo($win-pending) [after idle [list hierlist_redraw $win]]
        }
        return
    }
    set hierInfo($win-pending) ""
    set hierInfo($win-selected) ""

    $win.hbox delete 1.0 end
    $win.hbox mark set "root:start" 1.0
    $win.hbox mark gravity "root:start" left
    hierlist_insert $win "root"
}

proc hierlist_insert {win node} {
    global hierInfo

    set var $hierInfo($win-data)
    upvar #0 $var data

    set indent ""
    foreach digit [split $node "-"] {
        append indent "\t"
    }

    $win.hbox mark set pos "$node:start"

    set nodes [lsort -command "hierlist_data_cmp $var" $data($node-children)]
    foreach subnode $nodes {
        if {$data($subnode-children) != ""} {
            set arrow "$win.hbox.arrow-$subnode"
            label $arrow -image $hierInfo(sideArrow) \
                -borderwidth 0
            bind $arrow <ButtonPress-1> \
                "hierlist_expand $win $subnode"
            $win.hbox window create pos -window $arrow
        }
        $win.hbox insert pos \
            "$indent$data($subnode-label)\n" $subnode

        $win.hbox tag bind $subnode <ButtonPress-1> \
            [list hierlist_select $win $subnode]

        $win.hbox tag configure $subnode -background ""
        $win.hbox mark set "$subnode:start" pos
        $win.hbox mark gravity "$subnode:start" left
    }
    $win.hbox mark set "$node:end" pos
}

proc hierlist_expand {win node} {
    global hierInfo

    set arrow "$win.hbox.arrow-$node"
    set image [$arrow cget -image]

    if {$image == $hierInfo(sideArrow)} {
        $arrow configure -image $hierInfo(downArrow)
        bind $arrow <ButtonPress-1> \
            "hierlist_collapse $win $node"

        hierlist_insert $win $node
    }
}

proc hierlist_collapse {win node} {
    global hierInfo

    set arrow "$win.hbox.arrow-$node"
    set image [$arrow cget -image]

    if {$image == $hierInfo(downArrow)} {
        $arrow configure -image $hierInfo(sideArrow)
        bind $arrow <ButtonPress-1> \
            "hierlist_expand $win $node"

        $win.hbox delete "$node:start" "$node:end"
    }
}

proc hierlist_expand_all {win {node ""} {recurs ""}} {
    global hierInfo

    upvar #0 $hierInfo($win-data) data
    if {$node == ""} {
        set node "root"
        set recurs "all"
    }

    foreach subnode $data($node-children) {
        if {[llength $data($subnode-children)] > 0} {
            hierlist_expand $win $subnode
        }
        if {$recurs == "all"} {
            hierlist_expand_all $win $subnode $recurs
        }
    }
}

proc hierlist_select {win node} {
    global hierInfo

    if {$hierInfo($win-selected) != ""} {
        $win.hbox tag configure $hierInfo($win-selected) -background ""
    }

    set activebg [option get $win activeColor Color]
    $win.hbox tag configure $node -background $activebg
    set hierInfo($win-selected) $node

    if {$hierInfo($win-command) != ""} {
        uplevel #0 $hierInfo($win-command) $node
    }
}

proc hierlist_data {win info} {
    global hierInfo

    set var $hierInfo($win-data)
    upvar #0 $var data
    unset data

    hierlist_data_add $var root "" $info
}

proc hierlist_data_add {var node label info} {
    upvar #0 $var data

    set data($node-label) $label
    set data($node-children) ""

    set num 0
    foreach rec $info {
        set subnode "$node-[incr num]"
        lappend data($node-children) $subnode

        set sublabel [lindex $rec 0]
        set subinfo [lindex $rec 1]

        hierlist_data_add $var $subnode $sublabel $subinfo
    }
}

proc hierlist_data_cmp {var node1 node2} {
    upvar #0 $var data
    return [string compare $data($node1-label) $data($node2-label)]
}

proc hierlist_add {win path} {
    global hierInfo

    set var $hierInfo($win-data)
    upvar #0 $var data

    set node "root"
    foreach name $path {
        set found 0
        set num 0
        foreach subnode $data($node-children) {
            incr num
            if {$data($subnode-label) == $name} {
                set found 1
                break
            }
        }
        if {!$found} {
            set subnode "$node-$num"
            set data($subnode-label) $name
            set data($subnode-children) ""
            lappend data($node-children) $subnode
        }
        set node $subnode
    }
    hierlist_redraw $win eventually

    return $node
}

proc hierlist_selected {win} {
    global hierInfo
    return $hierInfo($win-selected)
}

proc hierlist_node {win path} {
    global hierInfo

    set var $hierInfo($win-data)
    upvar #0 $var data

    set node "root"
    foreach name $path {
        set found 0
        set num 0
        foreach subnode $data($node-children) {
            incr num
            if {$data($subnode-label) == $name} {
                set found 1
                break
            }
        }
        if {!$found} {
            return ""
        }
        set node $subnode
    }
    return $node
}

# ----------------------------------------------------------------------
# TOPIC FILES
# ----------------------------------------------------------------------
set topicParser [interp create -safe]
$topicParser alias topic topic_cmd_topic

proc topic_cmd_topic {hier lib demo html} {
    global topicInfo

    set node [hierlist_add .topics $hier]
    set topicInfo($node-lib) [string trim $lib]
    set topicInfo($node-demo) [string trim $demo]
    set topicInfo($node-html) $html
}

proc topic_show {node} {
    global topicInfo components

    if {[info exists topicInfo($node-html)]} {
        html_show $components(html) $topicInfo($node-html)
        code_show $components(demoCode) $topicInfo($node-demo)
        code_show $components(libCode) $topicInfo($node-lib)
        code_hilite_procs $topicInfo($node-lib) \
            $components(demoCode) $components(libCode)
    } else {
        html_clear $components(html)
        code_show $components(demoCode) ""
        code_show $components(libCode) ""
    }
}

# ----------------------------------------------------------------------
# HTML PARSING
# ----------------------------------------------------------------------
set htmlParser [interp create -safe]
$htmlParser alias initialize html_cmd_init
$htmlParser alias finalize html_cmd_finalize

$htmlParser alias html list
$htmlParser alias /html list
$htmlParser alias head list
$htmlParser alias /head list
$htmlParser alias title list
$htmlParser alias /title list
$htmlParser alias body list
$htmlParser alias /body list

$htmlParser alias h1 html_cmd_h1
$htmlParser alias /h1 html_cmd_/h1
$htmlParser alias h2 html_cmd_h2
$htmlParser alias /h2 html_cmd_/h2
$htmlParser alias h3 html_cmd_h3
$htmlParser alias /h3 html_cmd_/h3

$htmlParser alias br html_cmd_br
$htmlParser alias p html_cmd_p
$htmlParser alias /p html_cmd_/p
$htmlParser alias center html_cmd_center
$htmlParser alias /center html_cmd_/center
$htmlParser alias blockquote html_cmd_blockquote
$htmlParser alias /blockquote html_cmd_/blockquote
$htmlParser alias pre html_cmd_pre
$htmlParser alias /pre html_cmd_/pre

$htmlParser alias b html_cmd_b
$htmlParser alias /b html_cmd_/font
$htmlParser alias strong html_cmd_b
$htmlParser alias /strong html_cmd_/font
$htmlParser alias i html_cmd_i
$htmlParser alias /i html_cmd_/font
$htmlParser alias em html_cmd_i
$htmlParser alias /em html_cmd_/font
$htmlParser alias code html_cmd_code
$htmlParser alias /code html_cmd_/font
$htmlParser alias meta html_cmd_meta
$htmlParser alias /meta html_cmd_/font

$htmlParser alias ul html_cmd_ul
$htmlParser alias /ul html_cmd_/ul
$htmlParser alias li html_cmd_li
$htmlParser alias img html_cmd_img
$htmlParser alias wish html_cmd_wish

# ----------------------------------------------------------------------
# USAGE:  html_show <textWidget> <html>
#
# Loads a file of HTML info into a text widget.
# ----------------------------------------------------------------------
proc html_show {twin html} {
    global htmlParser

    $twin configure -cursor watch; update

    #
    # Convert braces to \&bl and \&br, to get them out of the way.
    # Convert the HTML tags <..> into a series of Tcl commands.
    #
    regsub -all {\{} $html "\\&bl;" html
    regsub -all {\}} $html "\\&br;" html

    set cmds "initialize $twin \{$html\}\nfinalize $twin"
    regsub -all "<(\[^ \n>\]+) *(\[^\n>\]*)>" $cmds \
        "\}\n\\1 $twin \{\\2\} \{" cmds

    set status [catch {$htmlParser eval $cmds} result]

    $twin configure -cursor ""

    if {$status != 0} {
        notice_show "Can't load HTML:\n$result"
    }
}

# ----------------------------------------------------------------------
# USAGE:  html_clear <textWidget>
#
# Clears an HTML text area.
# ----------------------------------------------------------------------
proc html_clear {twin} {
    $twin configure -state normal
    $twin delete 1.0 end
    $twin configure -state disabled
}

# ----------------------------------------------------------------------
# USAGE:  html_args <arglist> <arrayName>
#
# Parses an HTML argument list like "bgcolor=#ffffff link=#ff0000"
# and saves the results in the array <arrayName> in the calling
# scope.
# ----------------------------------------------------------------------
proc html_args {arglist avar} {
    upvar $avar values
    catch {unset values}

    set rest $arglist

    while {[regexp {^ *([^ ]*"[^"]*"|[^ "]*)( +.*|$)} $rest all word rest]} {
        if {[regexp {([^=]+)=(.*)} $word all key val]} {
            set values($key) [string trim $val \"]
        } else {
            set values($word) 1
        }
        if {[string trim $rest] == ""} {
            break
        }
    }
    if {[regexp {([^=]+)=(.*)} $rest all key val]} {
        set values($key) [string trim $val \"]
    } elseif {[string trim $rest] != ""} {
        set values($rest) 1
    }
}

# ----------------------------------------------------------------------
# USAGE:  html_insert <win> <mesg>
#
# Inserts some <mesg> text into the text widget <win>.  Uses the tag
# at the top of the current context stack.  Automatically converts
# characters like "&lt;", "&gt;", "&br;", "&bl;" etc. to the proper
# ASCII characters.
# ----------------------------------------------------------------------
proc html_insert {win mesg} {
    global html_settings

    regsub -all "\r" $mesg "" mesg
    regsub -all "&lt;?" $mesg "<" mesg
    regsub -all "&gt;?" $mesg ">" mesg
    regsub -all "&amp;?" $mesg "\\&" mesg
    regsub -all "&bl;?" $mesg "\{" mesg
    regsub -all "&br;?" $mesg "\}" mesg
    while {[regexp "&#(\[0-9\]+);?" $mesg match num]} {
        regsub -all $match $mesg [format "%c" $num] mesg
    }

    set preformat [lindex $html_settings(preformat) end]
    if {$preformat} {
        $win insert end $mesg $html_settings(context)
    } elseif {[string trim $mesg] != ""} {
        regsub -all "\n+" $mesg " " mesg
        regsub -all {(^|[^.:]) +} $mesg "\\1 " mesg

        if {[string match "\[ \t\n\]" [$win get end-2char]]} {
            set mesg [string trimleft $mesg]
        }
        set pos [$win index end-1char]
        $win insert end $mesg $html_settings(context)
        if {$html_settings(paragraph) != ""} {
            $win tag add $html_settings(paragraph) $pos
        }
        set html_settings(paragraph) ""
    }
}

# ----------------------------------------------------------------------
# USAGE:  html_break <win> ?force? ?paragraph? ?heading?
#
# Inserts a line break into the HTML text in widget <win>.  If there
# is already a newline at the end of the text, then another newline
# is not inserted unless the "force" argument is specified.
# ----------------------------------------------------------------------
proc html_break {win args} {
    global html_settings

    set force 0
    set paragraph ""
    foreach flag $args {
        switch -- $flag {
            force {
                set force 1
            }
            paragraph - heading {
                set paragraph $flag
            }
            default {
                error "bad flag \"$flag\": should be force, heading, or paragraph"
            }
        }
    }

    if {[$win get end-2char] != "\n" || $force} {
        $win insert end "\n" $html_settings(context)
    }
    if {$paragraph != ""} {
        set html_settings(paragraph) $paragraph
    }
}

# ----------------------------------------------------------------------
# USAGE:  html_font_change <win> <fontname> <fontstyle> <fontsize>
#
# Installs a font change onto the current context stack.  If any
# of the parameters like <fontname> are "", the current value is
# kept.
# ----------------------------------------------------------------------
proc html_font_change {win fontname fontstyle fontsize} {
    global html_settings html_counter

    if {$fontname == ""} {
        set fontname [lindex $html_settings(fontname) end]
    }
    if {$fontstyle == ""} {
        set fontstyle [lindex $html_settings(fontstyle) end]
    }
    if {$fontsize == ""} {
        set fontsize [lindex $html_settings(fontsize) end]
    } elseif {[string match {[-+]*} $fontsize]} {
        set del [expr $fontsize*10]
        set fontsize [expr [lindex $html_settings(fontsize) end]+$del]
    } else {
        set fontsize [expr $fontsize*10]
    }
    lappend html_settings(fontname) $fontname
    lappend html_settings(fontstyle) $fontstyle
    lappend html_settings(fontsize) $fontsize

    set name "font[incr html_counter]"

    $win tag configure $name \
        -font -*-$fontname-$fontstyle-normal--*-$fontsize-*

    html_context_add $name
}

# ----------------------------------------------------------------------
# USAGE:  html_font_resume <win>
#
# Removes a font change from the current context stack.  Usually
# called to set things back after a html_font_change operation.
# ----------------------------------------------------------------------
proc html_font_resume {win} {
    global html_settings
    set html_settings(fontname) [lreplace $html_settings(fontname) end end]
    set html_settings(fontstyle) [lreplace $html_settings(fontstyle) end end]
    set html_settings(fontsize) [lreplace $html_settings(fontsize) end end]
    html_context_remove font*
}

# ----------------------------------------------------------------------
# USAGE:  html_margin_change <win> <lmargin> <loffset> <rmargin>
#
# Installs a margin change onto the current context stack.  If any
# of the parameters like <lmargin> are "", the current value is
# kept.
# ----------------------------------------------------------------------
proc html_margin_change {win lmargin loffset rmargin} {
    global html_settings html_counter

    if {$lmargin == ""} {
        set lmargin [lindex $html_settings(lmargin) end]
    } elseif {[string match {[-+]*} $lmargin]} {
        set lmargin [expr [lindex $html_settings(lmargin) end]+$lmargin]
    }
    if {$rmargin == ""} {
        set rmargin [lindex $html_settings(rmargin) end]
    } elseif {[string match {[-+]*} $rmargin]} {
        set rmargin [expr [lindex $html_settings(rmargin) end]+$rmargin]
    }
    if {$loffset == ""} {
        set loffset 0
    }
    lappend html_settings(lmargin) $lmargin
    lappend html_settings(rmargin) $rmargin

    set name "margin[incr html_counter]"

    $win tag configure $name -lmargin1 $lmargin \
        -lmargin2 [expr $lmargin+$loffset] -rmargin $rmargin

    html_context_add $name
}

# ----------------------------------------------------------------------
# USAGE:  html_margin_resume <win>
#
# Removes a margin change from the current context stack.  Usually
# called to set things back after a html_margin_change operation.
# ----------------------------------------------------------------------
proc html_margin_resume {win} {
    global html_settings
    set html_settings(lmargin) [lreplace $html_settings(lmargin) end end]
    set html_settings(rmargin) [lreplace $html_settings(rmargin) end end]
    html_context_remove margin*
    html_break $win
}

# ----------------------------------------------------------------------
# USAGE:  html_context_add <name>
#
# Adds the tag <name> to the current context stack.
# ----------------------------------------------------------------------
proc html_context_add {name} {
    global html_settings
    lappend html_settings(context) $name
}

# ----------------------------------------------------------------------
# USAGE:  html_context_remove <pattern>
#
# Looks for a tag matching the <pattern> at the end of the current
# context stack, and if it is found, removes it.
# ----------------------------------------------------------------------
proc html_context_remove {pattern} {
    global html_settings
    set name [lindex $html_settings(context) end]
    if {[string match $pattern $name]} {
        set html_settings(context) [lreplace $html_settings(context) end end]
        return 1
    }
    return 0
}

# ----------------------------------------------------------------------
proc html_cmd_init {win mesg} {
    global html_counter html_settings

    set html_counter 0
    set html_settings(paragraph) "paragraph"
    set html_settings(context) normal
    set html_settings(preformat) 0
    set html_settings(lmargin) 5
    set html_settings(rmargin) 5
    set html_settings(fontname) helvetica
    set html_settings(fontstyle) medium-r
    set html_settings(fontsize) 120

    $win configure -state normal -wrap word
    $win delete 1.0 end

    $win tag configure normal -foreground black \
        -font -*-helvetica-medium-r-normal--*-120-* \
        -justify left -lmargin1 5 -lmargin2 5 -rmargin 5

    $win tag configure heading -spacing1 10 -spacing3 3
    $win tag configure paragraph -spacing1 8
    $win tag configure center -justify center

    html_insert $win $mesg
}

proc html_cmd_finalize {win} {
    $win configure -state disabled
}

proc html_cmd_h1 {win arglist mesg} {
    html_break $win heading
    html_font_change $win helvetica bold-r 18
    html_insert $win $mesg
}
proc html_cmd_/h1 {win arglist mesg} {
    html_font_resume $win
    html_break $win
    html_insert $win $mesg
}

proc html_cmd_h2 {win arglist mesg} {
    html_break $win heading
    html_font_change $win helvetica bold-r 14
    html_insert $win $mesg
}
proc html_cmd_/h2 {win arglist mesg} {
    html_font_resume $win
    html_break $win
    html_insert $win $mesg
}

proc html_cmd_h3 {win arglist mesg} {
    html_break $win heading
    html_font_change $win helvetica bold-o 12
    html_insert $win $mesg
}
proc html_cmd_/h3 {win arglist mesg} {
    html_font_resume $win
    html_break $win
    html_insert $win $mesg
}

proc html_cmd_br {win arglist mesg} {
    html_break $win force
    html_insert $win $mesg
}

proc html_cmd_p {win arglist mesg} {
    html_break $win force paragraph
    html_insert $win $mesg
}
proc html_cmd_/p {win arglist mesg} {
    html_insert $win $mesg
}

proc html_cmd_center {win arglist mesg} {
    html_context_add center
    html_insert $win "$mesg"
}
proc html_cmd_/center {win arglist mesg} {
    html_context_remove center
    html_insert $win $mesg
}

proc html_cmd_blockquote {win arglist mesg} {
    html_break $win
    html_margin_change $win +20 0 +0
    html_insert $win $mesg
}
proc html_cmd_/blockquote {win arglist mesg} {
    html_margin_resume $win
    html_break $win
    html_insert $win $mesg
}

proc html_cmd_pre {win arglist mesg} {
    global html_settings

    html_break $win
    lappend html_settings(preformat) 1
    html_font_change $win courier medium-r 10
    html_insert $win $mesg
}
proc html_cmd_/pre {win arglist mesg} {
    global html_settings

    html_font_resume $win
    set html_settings(preformat) [lreplace $html_settings(preformat) end end]
    html_break $win
    html_insert $win $mesg
}

proc html_cmd_b {win arglist mesg} {
    html_font_change $win "" bold-r ""
    html_insert $win $mesg
}
proc html_cmd_i {win arglist mesg} {
    html_font_change $win "" medium-o ""
    html_insert $win $mesg
}
proc html_cmd_code {win arglist mesg} {
    html_font_change $win courier "" ""
    html_insert $win $mesg
}
proc html_cmd_meta {win arglist mesg} {
    html_font_change $win courier "medium-o" ""
    html_insert $win $mesg
}
proc html_cmd_/font {win arglist mesg} {
    html_font_resume $win
    html_insert $win $mesg
}

proc html_cmd_ul {win arglist mesg} {
    global html_list
    lappend html_list(bullets) [format "%c" 187]
    lappend html_list(counts) 0
    html_margin_change $win +20 10 +0
    html_insert $win $mesg
}
proc html_cmd_/ul {win arglist mesg} {
    global html_list
    set html_list(bullets) [lreplace $html_list(bullets) end end]
    set html_list(counts)  [lreplace $html_list(counts) end end]
    html_margin_resume $win
    html_break $win paragraph
    html_insert $win $mesg
}
proc html_cmd_li {win arglist mesg} {
    global html_list html_settings

    set bullet [lindex $html_list(bullets) end]
    set count [lindex $html_list(counts) end]
    set html_list(counts) [lreplace $html_list(counts) end end [incr count]]
    regsub {#} $bullet $count bullet

    html_break $win paragraph
    html_insert $win "$bullet "
    html_insert $win $mesg
}

proc html_cmd_img {win arglist mesg} {
    global html_settings html_counter html_images

    html_args $arglist keys

    set imh ""
    if {[info exists keys(src)]} {
        if {[info exists html_images($keys(src))]} {
            set imh $html_images($keys(src))
        } elseif {[file readable $keys(src)]} {
            set imh [image create photo -file $keys(src)]
            set html_images($keys(src)) $imh
        }
    }
    if {$imh != ""} {
        set name "$win.image[incr html_counter]"
        set cmd "label $name -image $imh -borderwidth 0"
        set opts ""
        if {[info exists keys(align)]} {
            lappend opts -align $keys(align)
        }
        eval $win window create end -create [list $cmd] $opts
        foreach tag $html_settings(context) {
            $win tag add $tag end-2char end-1char
        }
        if {$html_settings(paragraph) != ""} {
            $win tag add $html_settings(paragraph) end-2char
        }
        set html_settings(paragraph) ""

    } elseif {[info exists keys(alt)]} {
        html_insert $win "<<$keys(alt)>>"
    } else {
        set name "$win.image[incr html_counter]"
        set cmd "label $name -bitmap question -borderwidth 0"
        $win window create end -create $cmd
        foreach tag $html_settings(context) {
            $win tag add $tag end-2char end-1char
        }
    }
    html_insert $win $mesg
}

proc html_cmd_wish {win arglist mesg} {
    global html_settings html_counter html_images

    html_args $arglist keys

    if {![info exists keys(label)]} {
        set keys(label) "Run Demo..."
    }
    if {[info exists keys(file)]} {
        set file [split $keys(file) "/"]
        set file [eval file join $file]
        set name "$win.button[incr html_counter]"
        set cmd [list button $name \
            -text $keys(label) -command "demo_run $keys(file)"]
        $win window create end -create $cmd
        foreach tag $html_settings(context) {
            $win tag add $tag end-2char end-1char
        }
        if {$html_settings(paragraph) != ""} {
            $win tag add $html_settings(paragraph) end-2char
        }
        set html_settings(paragraph) ""
    }
    html_insert $win $mesg
}

# ----------------------------------------------------------------------
# RUN DEMOS
# ----------------------------------------------------------------------
if {$tcl_platform(platform) == "macintosh"} {
    proc demo_run {file} {
        tk_messageBox -icon error -message "Can't \"exec\" programs on the Macintosh.  You'll have to start this demo by hand.  Start up the \"wish\" program and source in the following file:\n  $file"
    }
} else {
    proc demo_run {file} {
        if {[catch {exec [info nameofexecutable] $file &} result] != 0} {
            notice_show "Can't run demo:\n$result"
        }
    }
}

# ----------------------------------------------------------------------
# CODE DISPLAY
# ----------------------------------------------------------------------
proc code_show {win file} {
    $win configure -state normal
    $win delete 1.0 end

    if {$file != ""} {
        set file [eval file join $file]
        set cmd {
            set fid [open $file "r"]
            set code [read $fid]
            close $fid
        }
        if {[catch $cmd result] == 0} {
            $win insert 1.0 $code
        } else {
            $win insert 1.0 "Can't load file \"$file\"\n($result)"
        }
    }
    $win configure -state disabled
}

proc code_hilite_procs {file args} {
    global libProcs libParser

    if {$file == ""} {
        return
    }

    set file [eval file join $file]
    set cmd {
        set fid [open $file "r"]
        set code [read $fid]
        close $fid
        regsub -all "\\$" $code "\\\\$" code
    }

    set libProcs ""
    if {[catch $cmd] == 0 && [catch {$libParser eval $code}] == 0} {
        foreach name $libProcs {
            set len [string length $name]

            foreach twin $args {
                set index 1.0
                while {1} {
                    set index [$twin search $name $index end]
                    if {$index == ""} {
                        break
                    }
                    $twin tag add bold $index $index+${len}chars
                    set index "$index+${len}chars"
                }
            }
        }
    }
}

set libParser [interp create -safe]
$libParser eval {
    proc unknown {args} { # do nothing }
}
$libParser alias proc code_cmd_proc

proc code_cmd_proc {name arglist body} {
    global libProcs
    lappend libProcs $name
}

# ----------------------------------------------------------------------
# MAIN WINDOW
# ----------------------------------------------------------------------
wm title . "Effective Tcl/Tk Programming"

tabnotebook_create .pages
pack .pages -side right -expand yes -fill both -padx 6 -pady 6

set win [tabnotebook_page .pages "Overview"]
text $win.text -width 50 -height 15 -wrap word -state disabled \
    -yscrollcommand "$win.sbar set"
pack $win.text -side left -expand yes -fill both
scrollbar $win.sbar -orient vertical -command "$win.text yview"
pack $win.sbar -side right -fill y
set components(html) $win.text

set win [tabnotebook_page .pages "Demo Code"]
text $win.text -width 50 -height 15 -wrap none -state disabled \
    -xscrollcommand "$win.xsbar set" -yscrollcommand "$win.ysbar set" \
    -font -*-courier-medium-r-normal-*-*-120-*
$win.text tag configure bold -font -*-courier-bold-r-normal-*-*-120-*
grid $win.text -row 0 -column 0 -sticky nsew
scrollbar $win.ysbar -orient vertical -command "$win.text yview"
grid $win.ysbar -row 0 -column 1 -sticky ns
scrollbar $win.xsbar -orient horizontal -command "$win.text xview"
grid $win.xsbar -row 1 -column 0 -sticky ew
grid rowconfigure $win 0 -weight 1
grid columnconfigure $win 0 -weight 1
set components(demoCode) $win.text

set win [tabnotebook_page .pages "Library Code"]
text $win.text -width 50 -height 15 -wrap none -state disabled \
    -xscrollcommand "$win.xsbar set" -yscrollcommand "$win.ysbar set" \
    -font -*-courier-medium-r-normal-*-*-120-*
$win.text tag configure bold -font -*-courier-bold-r-normal-*-*-120-*
grid $win.text -row 0 -column 0 -sticky nsew
scrollbar $win.ysbar -orient vertical -command "$win.text yview"
grid $win.ysbar -row 0 -column 1 -sticky ns
scrollbar $win.xsbar -orient horizontal -command "$win.text xview"
grid $win.xsbar -row 1 -column 0 -sticky ew
grid rowconfigure $win 0 -weight 1
grid columnconfigure $win 0 -weight 1
set components(libCode) $win.text

hierlist_create .topics topic_show
pack .topics -side left -fill y -padx 4 -pady 4

# ----------------------------------------------------------------------
# Load all topic descriptions...
# ----------------------------------------------------------------------
set cmd {
    set fid [open $file "r"]
    set info [read $fid]
    close $fid
    $topicParser eval $info
}

foreach file [glob -nocomplain [file join catalog *.cat]] {
    if {[catch $cmd result] != 0} {
        notice_show "Can't load topic \"[file tail $file]\"\n($result)"
    }
}

update
wm deiconify .

hierlist_expand_all .topics

set node [hierlist_node .topics "0verview"]
if {$node != ""} {
    hierlist_select .topics $node
}
