# ----------------------------------------------------------------------
#  EXAMPLE: handle platform-specific stuff
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

proc open_html {file} {
    global tcl_platform

    switch $tcl_platform(platform) {
        unix {
            set cmd "exec netscape -remote \"openFile($file)\""
            if {[catch $cmd] != 0} {
                exec netscape &
                while {[catch $cmd] != 0} {
                    after 500
                }
            }
        }
        windows {
            set cmd [list exec netscape $file &]
            if {[catch $cmd] != 0} {
                set prog [tk_getOpenFile -title "Where is Netscape?"]
                if {$prog != ""} {
                    exec $prog $file &
                }
            }
        }
        macintosh {
            package require Tclapplescript

            set script {
                tell application "Internet Explorer 3.0"
                    open(file "%s")
                    Activate -1
                end tell
            }
            AppleScript execute [format $script $file]
        }
    }
}

open_html [tk_getOpenFile]
