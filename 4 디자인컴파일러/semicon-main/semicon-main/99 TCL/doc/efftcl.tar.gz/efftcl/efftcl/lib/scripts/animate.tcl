# ----------------------------------------------------------------------
#  EXAMPLE: use "after" to do animation
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set anInfo(counter) 0

# ----------------------------------------------------------------------
#  USAGE:  animate_start <delay> <values> <command>
#
#  This starts an animation sequence.  The given <command> is
#  evaluated at regular intervals of <delay> ms.  Each time, a
#  different value from the <values> list is substituted into
#  the "%v" field in the <command>.  When the <values> list is
#  exhausted, animation starts again with the first element.
#  Returns an identifier which can be passed to animate_stop
#  to terminate the animation.
# ----------------------------------------------------------------------
proc animate_start {delay vlist command} {
    global anInfo

    set id "animate[incr anInfo(counter)]"

    set anInfo($id-delay) $delay
    set anInfo($id-vlist) $vlist
    set anInfo($id-command) $command
    set anInfo($id-pos) 0
    set anInfo($id-pending) [after $delay "animate_handle $id"]

    return $id
}

# ----------------------------------------------------------------------
#  USAGE:  animate_handle <id>
#
#  Used internally to handle the various frames of an animation.
#  Executes the animation command with the current value substituted
#  into the "%v" field, then bumps the position to the next value
#  and schedules another call to this procedure.
# ----------------------------------------------------------------------
proc animate_handle {id} {
    global anInfo

    if {[info exists anInfo($id-pending)]} {
        set pos $anInfo($id-pos)
        set val [lindex $anInfo($id-vlist) $pos]
        set cmd [percent_subst %v $anInfo($id-command) $val]
        uplevel #0 $cmd

        if {[incr pos] >= [llength $anInfo($id-vlist)]} {
            set pos 0
        }
        set anInfo($id-pos) $pos

        set anInfo($id-pending) [after $anInfo($id-delay) "animate_handle $id"]
    }
}

# ----------------------------------------------------------------------
#  USAGE:  animate_stop <id>
#
#  Terminates an animation previously started by animate_start.
#  If the <id> is not recognized, this command does nothing.
# ----------------------------------------------------------------------
proc animate_stop {id} {
    global anInfo

    if {[info exists anInfo($id-pending)]} {
        after cancel $anInfo($id-pending)
        unset anInfo($id-delay)
        unset anInfo($id-vlist)
        unset anInfo($id-command)
        unset anInfo($id-pos)
        unset anInfo($id-pending)
    }
}
