# ----------------------------------------------------------------------
# EXAMPLE:  using "break" to interrupt event processing
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

label .prompt -text "Phone Number:"
pack .prompt -side left
entry .phone
pack .phone -side left

bind .phone <KeyPress> {
    if {![regexp "\[0-9\]|-|\b" "%A"]} {
        bell
        break
    }
}
