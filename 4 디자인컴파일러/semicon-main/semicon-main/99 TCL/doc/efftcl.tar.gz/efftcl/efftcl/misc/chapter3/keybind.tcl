# ----------------------------------------------------------------------
#  DEMO: simple way to find out keysyms
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

label .msg -width 30 -text "Press any key"
pack .msg

bind .msg <Key> {.msg configure -text "keysym = %K"}
focus .msg
