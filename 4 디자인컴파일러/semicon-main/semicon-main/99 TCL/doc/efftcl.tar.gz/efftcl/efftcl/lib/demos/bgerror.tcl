# ----------------------------------------------------------------------
#  DEMO: handling background errors with "bgerror"
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
package require Efftcl

email_bug_reports efftcl-bugs@aw.com

button .error -text "Generate Error" -command {error "this is an error!"}
pack .error
