# ----------------------------------------------------------------------
#  EXAMPLE: toplevel window
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

update

toplevel .notice -class Notice
set x [expr [winfo rootx .]+50]
set y [expr [winfo rooty .]+50]
wm geometry .notice "+$x+$y"

frame .notice.info
pack .notice.info -expand yes -fill both -padx 2 -pady 2
label .notice.info.icon -bitmap error
pack .notice.info.icon -side left -padx 8 -pady 8
label .notice.info.mesg -text "File not found"
pack .notice.info.mesg -side right -padx 8 -pady 8

frame .notice.sep -height 2 -borderwidth 1 -relief sunken
pack .notice.sep -fill x -pady 4

button .notice.dismiss -text "Dismiss" -command {destroy .notice}
pack .notice.dismiss -pady 4


wm title .notice "Application: Notice"
wm group .notice .

focus .notice.dismiss
