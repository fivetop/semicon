# ----------------------------------------------------------------------
#  EXAMPLE: simple toolbar with mutually-exclusive tools
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

proc toolbar_create {win {origin "top"} {command ""}} {
    global tbInfo

    frame $win -class Toolbar

    set tbInfo($win-current) ""
    set tbInfo($win-origin) $origin
    set tbInfo($win-command) $command
    return $win
}

proc toolbar_add {win tool image} {
    global tbInfo

    set label "$win.tool-$tool"
    label $label -borderwidth 2 -relief raised -image $image
    pack $label -side $tbInfo($win-origin) -fill both

    bind $label <ButtonPress-1> [list toolbar_select $win $tool]

    if {[llength [pack slaves $win]] == 1} {
        after idle [list toolbar_select $win $tool]
    }
    return $label
}

proc toolbar_select {win tool} {
    global tbInfo

    if {$tbInfo($win-current) != ""} {
        set label "$win.tool-$tbInfo($win-current)"
        $label configure -relief raised
    }
    set label "$win.tool-$tool"
    $label configure -relief sunken

    set tbInfo($win-current) $tool

    if {$tbInfo($win-command) != ""} {
        set cmd [percent_subst %t $tbInfo($win-command) $tool]
        uplevel #0 $cmd
    }
}

proc toolbar_get {win} {
    global tbInfo
    return $tbInfo($win-current)
}
