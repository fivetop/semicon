# ----------------------------------------------------------------------
#  Driver for Electric Secretary example when invoked from the catalog
#
#  Checks to see if the Electric Secretary program is already
#  running.  If not, it executes the Electric Secretary server,
#  and the starts up the client.
#
#  This program should be invoked in the same directory context
#  as the "catalog.tcl" script.
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

# ----------------------------------------------------------------------
#  USAGE: find_tclsh
#
#  This procedure returns the appropriate "tclsh" program for the
#  current "wish".  If tclsh is not found, it returns the null string.
# ----------------------------------------------------------------------
proc find_tclsh {} {
    global tcl_version

    set bin [file dirname [info nameofexecutable]]
    set best [glob -nocomplain [file join $bin tclsh$tcl_version]]
    if {$best != ""} {
        return $best
    }
    set best [glob -nocomplain [file join $bin tclsh]]
    if {$best != ""} {
        return $best
    }
    set any [glob -nocomplain [file join $bin tclsh*]]
    set best [lindex [lsort $any] end]
    return $best
}

# ----------------------------------------------------------------------
wm withdraw .
auto_load tk_messageBox

if {![info exists env(ESEC_HOST)]} {
    set env(ESEC_HOST) localhost
}
if {![info exists env(ESEC_PORT)]} {
    set env(ESEC_PORT) 8823
}

set okay 0

if {[catch {socket $env(ESEC_HOST) $env(ESEC_PORT)} sid] == 0} {
    catch {close $sid}   ;# success!
    set okay 1
} else {
    set tclsh [find_tclsh]

    tk_messageBox -icon info -message "Starting the Electric Secretary appointment server..."

    catch {exec $tclsh [file join apps elserver] &}

    for {set i 0} {$i < 10} {incr i} {
        if {[catch {socket $env(ESEC_HOST) $env(ESEC_PORT)} sid] == 0} {
            catch {close $sid}   ;# success!
            set okay 1
        }
        after 500
    }
}

if {!$okay} {
    tk_messageBox -icon error -message "Can't start the Electric Secretary appointment server.\nAborting..."
    exit
}

# Now, load the real "electric" application...
# ----------------------------------------------------------------------
source [file join apps electric]
update
wm deiconify .
