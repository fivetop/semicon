# ----------------------------------------------------------------------
#  EXAMPLE: appointment schedule widget
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

if {[string match *color [winfo screenvisual .]]} {
    option add *Appointment.stripeBackground LightGray widgetDefault
    option add *Appointment.stripeForeground black widgetDefault
    option add *Appointment.conflictBackground red widgetDefault
    option add *Appointment.conflictForeground white widgetDefault
} else {
    option add *Appointment.stripeBackground white widgetDefault
    option add *Appointment.stripeForeground black widgetDefault
    option add *Appointment.conflictBackground black widgetDefault
    option add *Appointment.conflictForeground white widgetDefault
}

option add *Appointment.text.width 40 widgetDefault
option add *Appointment.text.height 20 widgetDefault

option add *Appointment.titleFont \
    -*-helvetica-bold-o-normal--*-140-* widgetDefault
option add *Appointment.dateFont \
    -*-helvetica-bold-r-normal--*-120-* widgetDefault
option add *Appointment.hourFont \
    -*-helvetica-bold-r-normal--*-100-* widgetDefault
option add *Appointment.commentFont \
    -*-helvetica-medium-r-normal--*-100-* widgetDefault

set appInfo(alarm-on) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images bell.gif]]

set appInfo(alarm-off) [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images bell2.gif]]

# ----------------------------------------------------------------------
#  USAGE:  appointment_create <win>
#
#  Creates one page in an appointment book.  This includes a text
#  widget with some special tags and bindings, and a scrollbar.
#  Information is loaded into the page via appointment_load.
# ----------------------------------------------------------------------
proc appointment_create {win} {
    frame $win -class Appointment

    scrollbar $win.sbar -command "$win.text yview"
    pack $win.sbar -side right -fill y

    text $win.text -background white -wrap word \
        -cursor left_ptr -tabs {2c right 2.4c left} \
        -yscrollcommand "$win.sbar set"
    pack $win.text -side left -expand yes -fill both

    #
    # Set up tags for the various text styles...
    #
    $win.text tag configure title \
        -font [option get $win titleFont Font]

    $win.text tag configure date \
        -font [option get $win dateFont Font]

    $win.text tag configure hour \
        -font [option get $win hourFont Font]

    $win.text tag configure comment \
        -lmargin1 2.4c -lmargin2 2.4c \
        -font [option get $win commentFont Font]

    $win.text tag configure stripe \
        -background [option get $win stripeBackground Background] \
        -foreground [option get $win stripeForeground Foreground]

    $win.text tag configure space -spacing1 5

    #
    # Set up bindings to handle appointment editing...
    #
    set btags [bindtags $win.text]
    set i [lsearch $btags Text]
    if {$i >= 0} {
        set btags [lreplace $btags $i $i]
    }
    bindtags $win.text $btags

    bind $win.text <KeyPress> {appointment_insert %W %A}
    bind $win.text <Control-KeyPress-h> {appointment_backspace %W}
    bind $win.text <KeyPress-BackSpace> {appointment_backspace %W}
    bind $win.text <KeyPress-Delete> {appointment_backspace %W}
    bind $win.text <KeyPress-Tab> {appointment_next %W; break}

    #
    # Bind to the "comment" fields to let the user position
    # the cursor...
    #
    $win.text tag bind comment <ButtonPress-1> {
        focus %W
        %W mark set insert @%x,%y
    }

    return $win
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_load <win> <date> <scheduleVar>
#
#  Loads a page in an appointment book with schedule information.
#  <date> is a date string like "4/1/1996" that indicates the date.
#  <scheduleVar> is the name of an array in the calling scope.
#  It contains appointment strings for each of the time slot names.
#  Each time slot has a list with two values in it, an alarm state
#  and a comment string:
#
#      set schedule(8:00am) [list "off" "This is a comment."]
#
# ----------------------------------------------------------------------
proc appointment_load {win date scheduleVar} {
    upvar $scheduleVar schedule

    $win.text delete 1.0 end
    $win.text insert end "Appointments\n" title

    set time [clock scan $date]
    set day [clock format $time -format "%B %d, %Y"]
    $win.text insert end "$day\n\n" date

    set timeSlots [array names schedule]
    set timeSlots [lsort -command appointment_cmp $timeSlots]

    foreach slot $timeSlots {
        appointment_load_slot $win $slot $schedule($slot) $timeSlots
    }

    set range [$win.text tag nextrange comment 1.0]
    if {$range != ""} {
        set index [lindex $range 0]
        $win.text mark set insert $index
    }
    focus $win.text
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_load_slot <win> <slot> <appmt> <allSlots>
#
#  Adds a single line to the appointment book <win>.  Each line
#  represents one time slot.  <slot> contains the hour like "8:00am".
#  <appmt> is a list containing the alarm setting and the comment
#  message.  <allSlots> is a list of all of the slots, in the order
#  that they are displayed on the page.
# ----------------------------------------------------------------------
proc appointment_load_slot {win slot appmt allSlots} {
    if {[string match "*:00*" $slot]} {
        set htags "hour space"
    } else {
        set htags "hour"
    }
    $win.text insert end "\t$slot\t" $htags

    appointment_load_bell $win $slot $appmt

    set pos [lsearch $allSlots $slot]
    if {$pos % 2 != 0} {
        set ctags "comment stripe"
    } else {
        set ctags "comment"
    }
    set mesg [lindex $appmt 1]
    $win.text insert end "$mesg\n" $ctags
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_load_bell <win> <slot> <appointment>
#
#  Adds an alarm bell into the text widget within the appointment
#  window <win>.  <slot> is the time slot (e.g., "8:00am") containing
#  the bell.  <appointment> contains the data for this slot:  the
#  alarm state and the comment message.  If the alarm state is non-zero,
#  then the bell is initially turned on; otherwise, it is off.
# ----------------------------------------------------------------------
proc appointment_load_bell {win slot appmt} {
    global appInfo

    set name "$win.text.bell$slot"
    label $name -borderwidth 0
    bind $name <ButtonPress-1> \
        "appointment_toggle $win $name $slot"

    set alarm [lindex $appmt 0]
    if {$alarm} {
        set appInfo($win-$slot) 1
        $name configure -image $appInfo(alarm-on)
    } else {
        set appInfo($win-$slot) 0
        $name configure -image $appInfo(alarm-off)
    }
    $win.text window create end -window $name
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_get <win> <scheduleVar>
#
#  The information from an appointment book page into an array
#  variable named <scheduleVar> in the calling scope.  This will
#  contain appointment strings for each of the time slot names.
#  Each time slot has a list with two values in it, an alarm state
#  and a comment string:
#
#      set schedule(8:00am) [list "off" "This is a comment."]
#
# ----------------------------------------------------------------------
proc appointment_get {win scheduleVar} {
    global appInfo
    upvar $scheduleVar schedule

    set range [$win.text tag nextrange comment 1.0]
    while {$range != ""} {
        set pos [lindex $range 0]
        set nextpos [lindex $range 1]
        set comment [string trim [eval $win.text get $range]]

        set range [$win.text tag prevrange hour $pos]
        if {$range != ""} {
            set slot [string trim [eval $win.text get $range]]
            set schedule($slot) [list $appInfo($win-$slot) $comment]
        }
        set range [$win.text tag nextrange comment $nextpos+1char]
    }
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_cmp <val1> <val2>
#
#  Used to sort lists of appointment times.  Compares two values
#  like "8:00am" and "12:00pm" and returns:
#
#    -1 ... if val1 < val2
#     0 ... if val1 = val2
#    +1 ... if val1 > val2
# ----------------------------------------------------------------------
proc appointment_cmp {val1 val2} {

    set pattern {([0-1]?[0-9]):([0-9][0-9])(am|AM|pm|PM)}
    if {![regexp $pattern $val1 all hour1 min1 div1]} {
        error "bad time string \"$val1\""
    }
    if {![regexp $pattern $val2 all hour2 min2 div2]} {
        error "bad time string \"$val2\""
    }

    array set parts { am 1 AM 1 pm 2 PM 2 }

    if {$parts($div1) < $parts($div2)} {
        return -1
    } elseif {$parts($div1) > $parts($div2)} {
        return +1
    }

    if {$hour1 == 12} { set hour1 0 }
    if {$hour2 == 12} { set hour2 0 }

    if {$hour1 < $hour2} {
        return -1
    } elseif {$hour1 > $hour2} {
        return +1
    }

    if {$min1 < $min2} {
        return -1
    } elseif {$min1 > $min2} {
        return +1
    }
    return 0
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_toggle <win> <label> <timeslot>
#
#  Used internally to toggle the alarm on/off indicator in <label>
#  when the user clicks on it.  Toggles the alarm associated with
#  <timeslot>, and updates the image to reflect the current state.
# ----------------------------------------------------------------------
proc appointment_toggle {win label slot} {
    global appInfo

    if {$appInfo($win-$slot)} {
        set appInfo($win-$slot) 0
        $label configure -image $appInfo(alarm-off)
    } else {
        set appInfo($win-$slot) 1
        $label configure -image $appInfo(alarm-on)
    }
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_insert <twin> <char>
#
#  Used internally to handle keypresses on the text widget <twin>
#  associated with an appointment page.  Adds a single character
#  <char> at the insertion cursor.
# ----------------------------------------------------------------------
proc appointment_insert {twin c} {
    set tags [$twin tag names insert]
    if {$c == "\r" || $c == "\n"} {
        $twin insert insert "\n" $tags
    } elseif {[scan $c {%[ -~]} dummy] == 1} {
        $twin insert insert $c $tags
    }
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_backspace <twin>
#
#  Used internally to handle the backspace/delete keypresses on the
#  text widget <twin> associated with an appointment page.  Deletes
#  a single character <char> to the left of the insertion cursor.
# ----------------------------------------------------------------------
proc appointment_backspace {twin} {
    set tags [$twin tag names insert-1char]
    if {[lsearch $tags "comment"] >= 0} {
        $twin delete insert-1char
    }
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_next <twin>
#
#  Moves to the next appointment slot on the text widget <twin>.
# ----------------------------------------------------------------------
proc appointment_next {twin} {
    set range [$twin tag nextrange hour insert]
    if {$range != ""} {
        set index [lindex $range 0]
        set range [$twin tag nextrange comment $index]
        set index [lindex $range 0]
        $twin mark set insert $index
    } else {
        set range [$twin tag nextrange comment 1.0]
        set index [lindex $range 0]
        $twin mark set insert $index
    }
    $twin see insert
}

# ----------------------------------------------------------------------
#  USAGE:  appointment_conflict <win> <date> <scheduleVar>
#
#  Loads a page in an appointment book with schedule conflict
#  information.  This is much like "appointment_load", but the
#  conflict areas are not editable.  <date> is a date string like
#  "4/1/1996" that indicates the date.  <scheduleVar> is the name
#  of an array in the calling scope.  It contains appointment
#  strings for time slots with conflicts.
# ----------------------------------------------------------------------
proc appointment_conflict {win date scheduleVar} {
    upvar $scheduleVar schedule

    $win.text configure -state normal
    $win.text delete 1.0 end
    $win.text insert end "Appointments\n" title

    $win.text tag configure conflict -lmargin2 2.4c \
        -font [option get $win commentFont Font] \
        -background [option get $win conflictBackground Background] \
        -foreground [option get $win conflictForeground Foreground]

    set time [clock scan $date]
    set day [clock format $time -format "%B %d, %Y"]
    $win.text insert end "$day\n\n" date

    set count 0
    set timeSlots [array names schedule]
    set timeSlots [lsort -command appointment_cmp $timeSlots]
    set state "disabled"

    foreach slot $timeSlots {
        if {[string match "*:00*" $slot]} {
            set htags "hour space"
        } else {
            set htags "hour"
        }
        $win.text insert end "\t$slot\t" $htags

        if {$schedule($slot) == ""} {
            if {$count % 2 != 0} {
                set ctags "comment stripe"
            } else {
                set ctags "comment"
            }
        } else {
            set ctags "conflict"
        }

        if {$schedule($slot) == ""} {
            set state "normal"
            appointment_load_bell $win $slot {0 ""}
            $win.text insert end "\n" $ctags
        } else {
            $win.text insert end "$schedule($slot)\n" $ctags
        }
        incr count
    }
    $win.text configure -state $state

    set range [$win.text tag nextrange comment 1.0]
    if {$range != ""} {
        set index [lindex $range 0]
        $win.text mark set insert $index
    }
    focus $win.text
}
