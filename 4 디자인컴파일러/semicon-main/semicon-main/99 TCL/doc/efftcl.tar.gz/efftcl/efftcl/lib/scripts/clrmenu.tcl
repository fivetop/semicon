# ----------------------------------------------------------------------
#  EXAMPLE: menu of color choices
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================

set cmInfo(colorSelector) [dialog_create Colormenu]
wm title $cmInfo(colorSelector) "Colormenu:  Add"
wm protocol $cmInfo(colorSelector) WM_DELETE_WINDOW {
    set info [dialog_info $cmInfo(colorSelector)]
    $info.cancel invoke
}
wm withdraw $cmInfo(colorSelector)

set win [dialog_info $cmInfo(colorSelector)]
colordial_create $win.dial
pack $win.dial -expand yes -fill both -padx 4 -pady 4

set win [dialog_controls $cmInfo(colorSelector)]
button $win.ok -text "OK" -command {
    set info [dialog_info $cmInfo(colorSelector)]
    foreach win $cmInfo(all) {
        colormenu_add $win [colordial_get $info.dial]
    }
    wm withdraw $cmInfo(colorSelector)
}
pack $win.ok -side left -expand yes -padx 4

button $win.cancel -text "Cancel" -command {
    wm withdraw $cmInfo(colorSelector)
}
pack $win.cancel -side left -expand yes -padx 4


proc colormenu_create {win args} {
    global cmInfo

    frame $win -class Colormenu
    eval menubutton $win.cb $args
    $win.cb configure -menu $win.cb.clist -borderwidth 2
    pack $win.cb -expand yes -fill both

    menu $win.cb.clist
    $win.cb.clist add command -label "Off" \
        -command [list colormenu_select $win ""]

    $win.cb.clist add command -label "More..." \
        -command {wm deiconify $cmInfo(colorSelector)}

    lappend cmInfo(all) $win
    bind $win <Destroy> "colormenu_destroy $win"

    set cmInfo($win-colors) ""
    set cmInfo($win-current) ""
    set cmInfo($win-command) ""

    colormenu_add $win black
    colormenu_add $win white
    colormenu_add $win red
    colormenu_add $win green
    colormenu_add $win blue
    colormenu_add $win yellow

    colormenu_select $win black

    return $win
}

proc colormenu_destroy {win} {
    global cmInfo

    set i [lsearch $cmInfo(all) $win]
    if {$i >= 0} {
        set cmInfo(all) [lreplace $cmInfo(all) $i $i]
    }
}

proc colormenu_action {win command} {
    global cmInfo
    set cmInfo($win-command) $command
}

proc colormenu_add {win color} {
    global cmInfo

    if {[lsearch $cmInfo($win-colors) $color] < 0} {
        set imh [image create photo -width 40 -height 10]
        $imh put $color -to 0 0 40 10

        set last [$win.cb.clist index end]
        $win.cb.clist insert [expr $last-1] command -image $imh \
            -command [list colormenu_select $win $color]

        lappend cmInfo($win-colors) $color
    }
}

proc colormenu_select {win color} {
    global cmInfo

    if {$color == ""} {
        $win.cb configure -relief flat \
            -background white -activebackground white
    } else {
        $win.cb configure -relief raised \
            -background $color -activebackground $color
    }
    set cmInfo($win-current) $color

    if {$cmInfo($win-command) != ""} {
        set cmd [percent_subst %c $cmInfo($win-command) $color]
        uplevel #0 $cmd
    }
}

proc colormenu_get {win} {
    global cmInfo
    return $cmInfo($win-current)
}
