# ----------------------------------------------------------------------
#  INSTALLATION PROGRAM
# ----------------------------------------------------------------------
#  Effective Tcl/Tk Programming
#    Mark Harrison, AsiaInfo Software Research and Development
#    Michael McLennan, Bell Labs Innovations for Lucent Technologies
#    Addison-Wesley Professional Computing Series
# ======================================================================
#  Copyright (c) 1996-1997  Lucent Technologies Inc. and Mark Harrison
# ======================================================================
option add *selectColor ForestGreen startupFile
option add *Entry.background white startupFile
option add *Checkbutton.font \
    -*-helvetica-medium-r-normal-*-*-120-* startupFile

if {![file isdirectory [file join lib scripts]]} {
    cd [file dirname [info script]]
}
set auto_path [linsert $auto_path 0 lib]
package require Efftcl

email_bug_reports mmclennan@lucent.com

# Check for the proper version of wish...
# ----------------------------------------------------------------------
wm withdraw .

if {$tk_version < 4.1} {
    set ok [confirm_ask "Some of the examples in this book require wish4.1 or beyond.  You are currently running an older version of wish ($tk_version).\n\nContinue with the installation?"]
    if {!$ok} {
        exit
    }

    #
    # Some of the "file" operations don't exist for wish4.1.
    # Simulate them with Unix commands.
    #
    rename file tcl_file
    proc file {option args} {
        switch -- $option {
            copy {
                eval exec cp -rp $args
            }
            delete {
                foreach name $args {
                    if {$name != "-force"} {
                        exec rm -rf $name
                    }
                }
            }
            default {
                return [eval tcl_file $option $args]
            }
        }
    }
}

# ----------------------------------------------------------------------
#  USAGE:  install_lib
#
#  Installs the "Efftcl" package in the library associated with the
#  current "wish" program.
# ----------------------------------------------------------------------
proc install_lib {} {
    global efftcl_version

    set libDir [file dirname [info library]]
    set installDir [file join $libDir efftcl$efftcl_version]

    if {[file exists $installDir]} {
        set mesg "Package \"Efftcl\" is already installed."
        append mesg "\n\nOverwrite?"
        if {![confirm_ask $mesg]} {
            return
        }
        file delete -force $installDir
    }

    file copy lib $installDir
}

# ----------------------------------------------------------------------
#  USAGE:  install_apps <dir>
#
#  Installs the applications in the "apps" directory into the
#  specified directory.
# ----------------------------------------------------------------------
proc install_apps {dir} {
    global tcl_platform

    if {![file isdirectory $dir]} {
        set mesg "Directory $dir does not exist."
        append mesg "\n\nCreate it?"
        if {![confirm_ask $mesg]} {
            return
        }
        file mkdir $dir
    }
    foreach program [glob [file join apps *]] {
        if {![file isdirectory $program]} {
            set contents [fix_app $program [info nameofexecutable]]
            set tail [file tail $program]
            set file [file join $dir $tail]

            switch $tcl_platform(platform) {
                unix {
                    save_app $file $contents
                    exec chmod 755 $file
                }
                windows {
                    save_app $file.tcl $contents
                }
                macintosh {
                    save_app $file $contents
                }
            }
        }
    }
}

# ----------------------------------------------------------------------
#  USAGE:  fix_app <program> <wish>
#
#  Loads the text for an application file <program>, then searches
#  for an "exec wish" statement.  If found, it is replaced with a
#  full path name for the current <wish> executable.
# ----------------------------------------------------------------------
proc fix_app {program wish} {
    set fid [open $program r]
    set contents [read $fid]
    close $fid

    regsub {exec wish \"\$0} $contents "exec $wish \"\$0" contents
    return $contents
}

# ----------------------------------------------------------------------
#  USAGE:  save_app <file> <script>
#
#  Saves the text for an application <script> into a file called
#  <file>.
# ----------------------------------------------------------------------
proc save_app {file script} {
    if {[file exists $file]} {
        set mesg "Program \"$file\" already exists."
        append mesg "\n\nOverwrite?"
        if {![confirm_ask $mesg]} {
            return
        }
    }
    set fid [open $file w]
    puts -nonewline $fid $script
    close $fid
}

# ----------------------------------------------------------------------
# MAIN WINDOW
# ----------------------------------------------------------------------
wm title . "INSTALL"

frame .heading -background white -borderwidth 2 -relief sunken
pack .heading -fill x -padx 8 -pady 8

set imh [image create photo \
    -file [file join $env(EFFTCL_LIBRARY) images atomic2.gif]]
label .heading.icon -background white -image $imh

label .heading.title -background white \
    -text "Effective Tcl/Tk\nProgramming"
catch {.heading.title configure -font -*-helvetica-bold-o-normal--*-180-*}

label .heading.authors -background white \
    -text "Mark Harrison\nMichael McLennan"

label .heading.copyright -background white \
    -text "\251 1996-1997 Lucent Technologies Inc. and Mark Harrison"
catch {.heading.copyright configure -font -*-lucida-medium-r-normal-*-*-100-*}
catch {.heading.copyright configure -font 5x7}

grid .heading.icon -row 0 -column 0 -rowspan 2
grid .heading.title -row 0 -column 1
grid .heading.authors -row 1 -column 1
grid rowconfigure .heading 2 -minsize 0.1i
grid .heading.copyright -row 3 -column 0 -columnspan 2

frame .install
pack .install -fill x -padx 4

label .install.title -text "Install:"
pack .install.title -anchor w

checkbutton .install.lib \
    -text "library package Efftcl (version $efftcl_version)" \
    -variable installLib
pack .install.lib -anchor w

frame .install.apps
pack .install.apps -fill x
checkbutton .install.apps.cb \
    -text "application programs in:" \
    -variable installApps
entry .install.apps.dir
pack .install.apps.cb -side left
pack .install.apps.dir -side left -expand yes -fill x

.install.lib invoke
.install.apps.cb invoke

switch $tcl_platform(platform) {
    unix {
        .install.apps.dir insert 0 "/usr/local/bin"
    }
    windows {
        .install.apps.dir insert 0 "C:/Efftcl"
    }
}

frame .sep -height 2 -borderwidth 1 -relief sunken
pack .sep -fill x -pady 8

frame .control
pack .control -fill x -padx 4 -pady 8
button .control.install -text "INSTALL" -command {
    set cmd {
        if {$installLib} {
            install_lib
        }
        if {$installApps} {
            install_apps [.install.apps.dir get]
        }
    }
    if {[catch $cmd result] != 0} {
        notice_show "Error during installation:\n$result"
    } else {
        set top [notice_show "Installation complete."]
        set cntls [dialog_controls $top]
        $cntls.dismiss configure -command exit
    }
}
pack .control.install -side left -expand yes
button .control.exit -text "Exit" -command exit
pack .control.exit -side left -expand yes

focus .control.install
update
wm deiconify .
