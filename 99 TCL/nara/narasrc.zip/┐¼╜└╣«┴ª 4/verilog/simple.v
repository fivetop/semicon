
module  aa(a, b, c, d);
input a, b;
output c;
inout d;

....;


endmodule;


module bb(a1, a2, a3, a4, a5, a6, a7,a8);
input a1;
input a2;
input a3;
output a4, 
       a5, 
       a6 ;
inout a7;
inout a8;

....

endmodule;
